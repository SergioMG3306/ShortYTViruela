#!/bin/bash
# Instala el motor de los Shorts en las rutas que espera el código (/home/claude/serie, /home/claude/topo).
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /home/claude
cp -r "$HERE/serie" "$HERE/topo" /home/claude/
mkdir -p /usr/share/texmf/fonts/opentype/public/lm && cp "$HERE"/fonts/*.otf /usr/share/texmf/fonts/opentype/public/lm/
pip install --break-system-packages -q numpy scipy opencv-python-headless pillow sherpa-onnx
if [ ! -f /home/claude/topo/voz_model/es_ES-davefx-medium.onnx ]; then
  cd /tmp && curl -sSL -o davefx.tar.bz2 https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/vits-piper-es_ES-davefx-medium.tar.bz2
  tar xjf davefx.tar.bz2 && rm -rf /home/claude/topo/voz_model && mv vits-piper-es_ES-davefx-medium /home/claude/topo/voz_model
fi
ls /home/claude/topo/voz_model
echo "Motor instalado."
