# Motor de los Shorts verticales (Historia en 16 bits)

Proyectos de referencia: `serie/cervantes` (base), `serie/vascos`, `serie/llivia` (el más reciente y completo).
Todo el código usa rutas absolutas `/home/claude/serie/...`; ejecuta `bash setup.sh` antes de nada.

## Flujo por proyecto (copiar `serie/llivia` como plantilla)
1. `narr.txt`: guion con secciones `## Nombre` (una por escena). Frases cortas.
2. `tts_X.py` (copia de `tts_ll.py`): voz Dave (es_ES-davefx, sherpa-onnx). `python3 tts_X.py 0.90 0.6` → `voz.wav` + `timing.json`
   (tiempos de cada frase y palabra). Pronunciaciones con `N.NAMES.update({...})`.
3. `X_scenes.py`: una función por escena `s0(t)…sN(t)` que devuelve la imagen 540×960 (float RGB 0–1); `SC = [s0, …]`.
   - Tiempos SIEMPRE con `tw(frase, 'palabra')`, `st0(frase)`, `st1(frase)` (sin acentos, minúsculas; `nth` para repeticiones).
   - Fronteras de escena `B` = 1 s antes de la primera frase de cada sección (se pueden ajustar en el propio archivo).
   - Texto y tarjetas en la capa de overlay (resolución completa): `ov`, `rect`, `tag`, `header`, `sp` (sellos), `tn` (tecleo).
   - Arte entre y=140 y y=640; subtítulos automáticos en y≈692; cabecera en y 40–130.
4. `X_render.py` (copia de `ll_render.py`): transiciones (`TRANS`, 'wipe'/'dis'), polvo, grano, subtítulos. 
   Pruebas: `python3 t_sc.py 1.0 5.2 …` y `python3 sheet.py cs.jpg 1.0 5.2 …` (hoja de contacto).
5. `X_events.py` → `events.json` (tecleos y sellos para el audio).
6. Audio: `X_audio_head.py` + `X_audio_cues.py` + `X_audio_mix.py` → `X_audio.py` → `*_audio_raw.wav`;
   normalizar a −14 LUFS: `ffmpeg -i raw.wav -af "volume=XdB,alimiter=limit=0.93:level=false" audio.wav` y medir con ebur128.
7. Render: `python3 X_render.py salida.mp4 audio.wav` (2 procesos, ~0,4 s/fotograma).
8. Versión ligera para entregar: `ffmpeg -i v1.mp4 -vf "hqdn3d=2:1.5:3:3" -c:v libx264 -preset medium -crf 25 -pix_fmt yuv420p -c:a aac -b:a 160k -movflags +faststart web.mp4`

## Piezas reutilizables
- `cv_art`: `person` (figuras de época), `galley`, `sea_img`, `waves`, `desk`, `icon`, `x_mark`.
- `vs_art`: `silhouette` (con antorcha), `embers`, `smoke_puffs`, `flag`, `gull`, `woodcut_kb` (grabado a pantalla completa con Ken Burns), `room_candles`, `candle_s`.
- `vs_scenes`: `nao` (barco), `storm_sea`, `parchment`, `stele`, `counter`.
- `ll_map`: mapa con fronteras reales (Natural Earth 10m), relieve procedural, tintes por país, cámara (lon, lat, px/km).
- `ll_scenes`: `photo_kb` (foto a pantalla completa con Ken Burns), `art_text`, documento con lupa, `stop_scene` (lapso día/noche), zoom Europa→pueblo.
- `cv_geomap`/`cv_geo`: mapas Natural Earth 50m, `pulse`, `pin`, `along` (rutas animadas).
