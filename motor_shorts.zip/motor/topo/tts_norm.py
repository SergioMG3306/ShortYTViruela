import re
from num2words import num2words

NAMES = {
 'Wadi': 'Uadi', 'Hammamat': 'Jamamat', 'Willebrord': 'Vílebrord', 'Alkmaar': 'Alkmar', 'Bergen': 'Bérguen', 'Zoom': 'Zum',
 'Landsat': 'Lansat', 'Sputnik': 'Esputnik', 'Marshall': 'Márshal', 'Cassini': 'Casini', 'Lambton': 'Lámbton', 'Harrison': 'Járrison',
 'Cook': 'Cuk', 'Newton': 'Niúton', 'Xiu': 'Chiu', 'Roger': 'Rójer', 'Snellius': 'Snélius', 'Ptolomeo': 'Tolomeo', 'Himalaya': 'Imalaya',
 'GPS': 'ge pe ese', 'H4': 'hache cuatro', 'Nippur': 'Nípur', 'Sorlingas': 'Sorlingas', 'Pisana': 'Pisana', 'Mercator': 'Mercátor',
 'Strabo': 'Estrabón',
 'Thomas': 'Tomás', 'Young': 'Yang', 'Champollion': 'Shampolión', 'Jean-François': 'Yan Fransuá', 'Rosetta': 'Roseta',
}
ROMAN = {'I': 1, 'V': 5, 'X': 10, 'L': 50, 'C': 100}


def roman(s):
    v = 0
    for i, ch in enumerate(s):
        n = ROMAN[ch]
        if i + 1 < len(s) and ROMAN[s[i + 1]] > n:
            v -= n
        else:
            v += n
    return v


def words(n):
    return num2words(n, lang='es')


def speak_tokens(tokens):
    out = []
    for i, tk in enumerate(tokens):
        m = re.match(r'^([¿¡«(—"]*)(.*?)([.,;:?!»)—"]*)$', tk)
        pre, core, post = m.group(1), m.group(2), m.group(3)
        prev = re.sub(r'[^\wÁ-ú]', '', tokens[i - 1]) if i else ''
        nxt = re.sub(r'[^\wÁ-ú]', '', tokens[i + 1]) if i + 1 < len(tokens) else ''
        sp = core
        if core == 'a' and post.startswith('.') and nxt == 'C':
            sp = 'antes de'; post = ''
        elif core == 'C' and post.startswith('.') and prev == 'a':
            sp = 'Cristo'; post = post[1:] if post[1:] or i != len(tokens) - 1 else '.'
        elif re.fullmatch(r'[IVXL]+', core) and core != 'I':
            sp = 'segundo' if (prev == 'Roger' and core == 'II') else ('quinto' if (prev == 'Ptolomeo' and core == 'V') else words(roman(core)))
        elif re.fullmatch(r'\d{1,3}(\.\d{3})+', core):
            sp = words(int(core.replace('.', '')))
        elif re.fullmatch(r'\d+:\d+(\.\d{3})*', core):
            a, b = core.split(':')
            sp = words(int(a)) + ' a ' + words(int(b.replace('.', '')))
        elif re.fullmatch(r'\d+', core):
            sp = words(int(core))
        elif core == '%':
            sp = 'por ciento'
        elif core in NAMES:
            sp = NAMES[core]
        elif core == 'al-Idrisi':
            sp = 'al Idrisi'
        elif core == 'op':
            sp = 'op'
        post = re.sub(r',+', ',', post.replace('—', ','))
        pre = pre.replace('—', ', ').replace('«', '').replace('(', '')
        post = post.replace('»', '').replace(')', '')
        # "—la actual Asuán—," -> pausas
        out.append((pre.replace('¿', '¿').replace('¡', '¡') + sp + post).strip())
    return out
