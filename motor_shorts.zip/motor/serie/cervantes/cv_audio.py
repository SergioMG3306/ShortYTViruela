import sys, json
sys.path.insert(0, '/home/claude/serie/cervantes')
from cv_audio_lib import *
import cv_audio_lib as AL
EV = json.load(open('/home/claude/serie/cervantes/events.json'))
def _e(x): x = np.clip(x, 0, 1); return x * x * (3 - 2 * x)

# ---------- piezas nuevas
def riser(t0, t1, g=0.2, f0=60, f1=420, noise=0.35):
    n = int((t1 - t0) * SR); t = tt(n); x = np.linspace(0, 1, n) ** 2.2; f = f0 + (f1 - f0) * x; ph = 2 * np.pi * np.cumsum(f) / SR
    s = (np.sin(ph) + 0.5 * np.sin(1.5 * ph + 1)) * 0.6 + noise * bp(nz(n), 300, 5000) * x
    add((s * x ** 0.6 * g).astype(np.float32), t0, 0.0, 1.0, 0.25, True)
def reverse_hit(t_hit, dur=0.9, g=0.3):
    n = int(dur * SR); t = tt(n); s = bp(nz(n), 400, 7000) * (np.linspace(0, 1, n) ** 2.5); add((s * g).astype(np.float32), t_hit - dur, 0.0, 1.0, 0.3)
def glitch(t0, t1, g=0.3, dens=60):
    n = int(dens * (t1 - t0))
    for j in range(n):
        tj = t0 + (t1 - t0) * (j / max(n, 1)) ** 0.8 + rng.rand() * 0.01
        add(click(600 + rng.rand() * 5000, 0.004 + 0.01 * rng.rand(), g * (0.5 + 0.5 * rng.rand())), tj, rng.rand() * 1.6 - 0.8)
def sonar(t0, f=1050, g=0.3, dec=2.4, pan=0.0):
    n = int(dec * SR); t = tt(n); s = np.sin(2 * np.pi * f * t) * np.exp(-t * 3.0) * np.minimum(1, t / 0.01) + 0.35 * np.sin(2 * np.pi * f * 1.5 * t) * np.exp(-t * 5.5)
    add((s * g).astype(np.float32), t0, pan, 1.0, 0.7)
def chirp(t0, f0=1200, f1=3200, dur=0.07, g=0.2, pan=0.0):
    n = int(dur * SR); t = tt(n); f = f0 + (f1 - f0) * t / dur; s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.minimum(1, t / 0.004) * np.minimum(1, (dur - t) / 0.01)
    add((s * g).astype(np.float32), t0, pan, 1.0, 0.2)
def step_snd(g=1.0, f=85):
    n = int(0.17 * SR); t = tt(n); s = np.sin(2 * np.pi * np.cumsum(f * (1 + 0.6 * np.exp(-t * 30))) / SR) * np.exp(-t * 22) + 0.45 * bp(nz(n), 300, 2400) * np.exp(-t * 55) + 0.2 * lp(nz(n), 600) * np.exp(-t * 25)
    return (s * g).astype(np.float32)
def stomps(t0, t1, hz, g_fn, v_fn, spread=1.4):
    t = t0
    while t < t1:
        g = g_fn(t); nv = int(max(1, round(v_fn(t))))
        for v in range(nv): add(step_snd(g * (0.55 + 0.45 * rng.rand()), 65 + rng.rand() * 45), t + rng.randn() * 0.014, (rng.rand() - 0.5) * spread, 1.0, 0.10)
        t += 1.0 / hz
def tom(t0, f=95, g=0.5, pan=0.0):
    n = int(0.45 * SR); t = tt(n); s = np.sin(2 * np.pi * np.cumsum(f * (1 + 0.8 * np.exp(-t * 20))) / SR) * np.exp(-t * 9) + 0.3 * bp(nz(n), 400, 2500) * np.exp(-t * 40)
    add((s * g).astype(np.float32), t0, pan, 1.0, 0.3)
def pluck(t0, f, g=0.18, dur=0.5, pan=0.0):
    n = int(dur * SR); t = tt(n); s = (2 * np.abs(2 * ((f * t) % 1) - 1) - 1) * 0.6 + 0.3 * np.sin(2 * np.pi * f * 2 * t); s = lp(s, 2200) * np.exp(-t * 7) * np.minimum(1, t / 0.003)
    add((s * g).astype(np.float32), t0, pan, 1.0, 0.35)
def drip(t0, g=0.14):
    n = int(0.14 * SR); t = tt(n); f = rng.uniform(1100, 2200) * np.exp(-t * rng.uniform(6, 14)); s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 28)
    add((s * g).astype(np.float32), t0, rng.rand() * 1.6 - 0.8, 1.0, 0.3)
def clop(t0, g=0.22, pan=0.0):
    n = int(0.12 * SR); t = tt(n); s = (np.sin(2 * np.pi * 720 * t) * 0.5 + bp(nz(n), 500, 3500) * 0.8) * np.exp(-t * 50)
    add((s * g).astype(np.float32), t0, pan, 1.0, 0.18)
def bird(t0, g=0.06):
    k = rng.randint(2, 5); t_ = t0
    for j in range(k): chirp(t_, rng.uniform(2800, 4200), rng.uniform(3200, 5200), rng.uniform(0.05, 0.10), g, rng.rand() * 1.4 - 0.7); t_ += rng.uniform(0.08, 0.16)

# ---------- máquina de escribir, fotos y sellos
for (text, t0, cps) in EV['tn']:
    typing(t0, len(text), cps, 0.42 if cps >= 14 else 0.38)
for (name, t0, t1) in EV['ph']:
    pan = {'portada.jpg': -0.2, 'retrato.png': 0.25}.get(name, 0.0)
    shutter(t0, 0.7, pan); n_ = int(0.17 * SR); add(bp(nz(n_), 500, 6000) * (np.linspace(0, 1, n_) ** 2) * 0.22, t0, pan, 1.0, 0.1)
    add(thud(0.75, 0.5), t0 + 0.16, pan, 1.0, 0.2); add(bp(nz(int(0.07 * SR)), 700, 6000) * np.exp(-tt(int(0.07 * SR)) * 45) * 0.6, t0 + 0.16, pan, 1.0)
for (text, t0) in EV['sp']:
    stampthud(t0 + 0.14, 1.0)
    if 'OCULTA' in text or 'MANCO' in text: bell(t0 + 0.16, 196, 0.14); bell(t0 + 0.16, 294, 0.06)


# ================= piezas nuevas para Cervantes
def boom(t0, g=0.4, pan=0.0, dist=0.0):
    n = int(2.2 * SR); t = tt(n); f = 38 + 50 * np.exp(-t * 9)
    s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 3.2) + 0.9 * lp(nz(n), 420 - 220 * dist) * np.exp(-t * (4.5 - 2 * dist)) + (1 - dist) * 0.5 * bp(nz(n), 900, 5000) * np.exp(-t * 40)
    add((s * g).astype(np.float32), t0, pan, 1.0, 0.45 + 0.3 * dist)
def crack(t0, g=0.6, pan=0.0):
    n = int(0.9 * SR); t = tt(n)
    s = 1.2 * bp(nz(n), 1200, 9000) * np.exp(-t * 70) + 0.8 * lp(nz(n), 600) * np.exp(-t * 12) + np.sin(2 * np.pi * np.cumsum(70 + 80 * np.exp(-t * 30)) / SR) * np.exp(-t * 9)
    add((s * g).astype(np.float32), t0, pan, 1.0, 0.5)
def clang(t0, f=380, g=0.3, pan=0.0, dec=2.5):
    n = int(dec * SR); t = tt(n); s = np.zeros(n, np.float32)
    for k, (m, a) in enumerate(((1.0, 1.0), (2.32, 0.6), (3.86, 0.4), (5.41, 0.25), (6.9, 0.15))):
        s += a * np.sin(2 * np.pi * f * m * t + k) * np.exp(-t * (2.2 + 1.6 * k) * 2.5 / dec)
    s = s * np.minimum(1, t / 0.002) + 0.4 * bp(nz(n), 2000, 9000) * np.exp(-t * 80)
    add((s * g * 0.5).astype(np.float32), t0, pan, 1.0, 0.4)
def chains(t0, dur=0.8, g=0.2, pan=0.0):
    k = int(dur * 22)
    for j in range(k): clang(t0 + dur * (j / k) + rng.rand() * 0.03, rng.uniform(1800, 3600), g * rng.uniform(0.4, 1.0), pan + rng.rand() * 0.4 - 0.2, 0.25)
def coins(t0, n=12, g=0.15, dur=0.9):
    for j in range(n): clang(t0 + dur * (j / n) ** 1.4 + rng.rand() * 0.02, rng.uniform(2600, 4800), g * rng.uniform(0.5, 1.0), rng.rand() * 1.0 - 0.5, 0.35)
def wind(t0, t1, g=0.12):
    n = int((t1 - t0) * SR); t = tt(n)
    s = lp(nz(n), 700) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.13 * t) ** 2) + 0.25 * bp(nz(n), 900, 2600) * (0.3 + 0.7 * np.sin(2 * np.pi * 0.09 * t + 1) ** 4)
    add((s * swell(n, 1.0, 1.0) * g).astype(np.float32), t0, 0.0, 1.0, 0.05, True)
def gallop(t0, t1, g=0.22, pan0=-0.6, pan1=0.2):
    t = t0
    while t < t1:
        p = pan0 + (pan1 - pan0) * (t - t0) / max(1e-3, t1 - t0)
        for dt in (0.0, 0.09, 0.19): clop(t + dt, g * rng.uniform(0.7, 1.0), p)
        t += 0.42
def scratch(t0, dur=1.2, g=0.12):
    n = int(dur * SR); t = tt(n); e = np.zeros(n, np.float32); k = 0
    while k < n:
        l = int(rng.uniform(0.05, 0.16) * SR); e[k:k + l] = np.sin(np.linspace(0, np.pi, len(e[k:k + l]))) * rng.uniform(0.5, 1.0); k += l + int(rng.uniform(0.02, 0.08) * SR)
    add((bp(nz(n), 2500, 8000) * e * g).astype(np.float32), t0, 0.15, 1.0, 0.15)
def murmur(t0, t1, g=0.08):
    n = int((t1 - t0) * SR); t = tt(n); s = np.zeros(n, np.float32)
    for k in range(6): s += bp(nz(n), rng.uniform(250, 500), rng.uniform(900, 1500)) * (0.3 + 0.7 * np.abs(np.sin(2 * np.pi * rng.uniform(2, 5) * t + k)))
    add((s / 6 * swell(n, 0.8, 0.8) * g).astype(np.float32), t0, 0.0, 1.0, 0.2, True)
def oars(t0, t1, g=0.10, per=1.6):
    t = t0
    while t < t1:
        n = int(0.7 * SR); tq = tt(n); s = bp(nz(n), 300, 2400) * np.sin(np.pi * tq / tq[-1]) ** 3
        add((s * g).astype(np.float32), t, rng.rand() * 0.6 - 0.3, 1.0, 0.1)
        if rng.rand() < 0.4: creak(t + 0.2, g * 0.6)
        t += per
def steps(t0, n, hz, g=0.22, pan0=0.0, pan1=0.0, f=95):
    for j in range(n): add(step_snd(g * rng.uniform(0.8, 1.0), f + rng.rand() * 20), t0 + j / hz, pan0 + (pan1 - pan0) * j / max(1, n - 1), 1.0, 0.1)
def war_drums(t0, t1, bpm=100, g=0.3):
    t = t0; k = 0; b = 60.0 / bpm
    while t < t1:
        pat = (1.0, 0.0, 0.6, 0.6)[k % 4]
        if pat: tom(t, 90 if k % 4 == 0 else 120, g * pat, -0.2 if k % 2 else 0.2)
        t += b / 2; k += 1
ANDA = [(146.8, 174.6, 220.0), (130.8, 164.8, 196.0), (116.5, 146.8, 174.6), (110.0, 138.6, 164.8)]
def lute(t0, t1, bpm=84, g=0.09):
    b = 60.0 / bpm; t = t0; k = 0
    while t < t1:
        ch = ANDA[(k // 8) % 4]; pat = [0, 1, 2, 1, 0, 2, 1, 2][k % 8]; f = ch[pat] * (2 if k % 8 in (2, 5) else 1)
        fade = min(1.0, (t - t0) / 1.5, (t1 - t) / 1.5)
        pluck(t, f, g * max(0.0, fade), 0.6, -0.25 + 0.5 * (pat / 2)); 
        if k % 8 == 0: pluck(t, ch[0] / 2, g * 0.8 * max(0.0, fade), 1.2, 0.0)
        t += b / 2; k += 1

def W(si, p, n=0): return tw(si, p, n)

# ================= DRONES / música por escena
subdrone(0.2, B[1] + 1.0, 36.7, 0.16, 1.5, 2.5); drone([73.4, 110.0, 146.8], 0.2, B[1] + 1.0, 0.05, 600, 1.5, 2.5)
subdrone(B[1] - 0.5, B[2] + 1.0, 36.7, 0.18, 2, 2); drone([73.4, 110.0, 130.8], B[1] - 0.5, B[2] + 1.0, 0.05, 700, 2, 2)
subdrone(B[2] - 0.5, B[3] + 1.0, 32.7, 0.16, 2, 2); drone([73.4, 110.0, 174.6], B[2] - 0.5, B[3] + 1.0, 0.045, 550, 2, 2)
subdrone(B[3] - 0.5, B[4] + 1.0, 36.7, 0.15, 2, 2); drone([73.4, 110.0, 146.8], B[3] - 0.5, B[4] + 1.0, 0.04, 650, 2, 2)
subdrone(B[4] - 0.5, B[5] + 1.0, 36.7, 0.18, 2, 2); drone([73.4, 87.3, 103.8], B[4] - 0.5, B[5] + 1.0, 0.05, 600, 2, 2)
subdrone(B[5] - 0.5, st0(31), 32.7, 0.20, 2, 1.5); drone([65.4, 98.0, 155.6], B[5] - 0.5, st0(31), 0.05, 500, 2, 1.5)
drone([73.4, 110.0, 185.0], st0(31) - 0.3, B[6] + 1.0, 0.05, 900, 1.5, 2); subdrone(st0(31) - 0.3, B[6] + 1.0, 36.7, 0.14, 1.5, 2)
subdrone(B[6] - 0.5, B[7] + 1.0, 36.7, 0.16, 2, 2); drone([73.4, 110.0, 130.8], B[6] - 0.5, B[7] + 1.0, 0.045, 650, 2, 2)
subdrone(B[7] - 0.5, TEND + 0.4, 36.7, 0.16, 2, 4); drone([73.4, 110.0, 146.8, 185.0], B[7] - 0.5, TEND + 0.4, 0.05, 800, 2, 4)

# ================= S0 · gancho
riser(0.2, 3.3, 0.26, 50, 620, 0.45); heart(0.35, 3.35, 70, 104, 0.30)
reverse_hit(3.32, 0.7, 0.28); add(thud(0.9, 1.0), 3.32, 0.0, 1.0, 0.4)
clang(W(1, 'soldado'), 520, 0.22, -0.4); add(thud(0.5, 0.5), W(1, 'soldado'), -0.4, 1.0, 0.2)
chains(W(1, 'prisionero'), 0.8, 0.16); add(thud(0.5, 0.5), W(1, 'prisionero'), 0.0, 1.0, 0.2)
steps(W(1, 'fugitivo'), 6, 7.0, 0.20, 0.2, 0.8); whoosh(W(1, 'fugitivo') + 0.1, 0.7, 0.10)
lute(st0(1) - 0.2, B[1] + 0.6, 84, 0.075)
paper(B[1], 1.3, 0.45)

# ================= S1 · Lepanto
whoosh(B[1] + 0.2, 2.0, 0.10, 300, 3000)
sonar(W(4, 'golfo') + 0.05, 820, 0.22, 2.4)
war_drums(st0(5) - 0.4, st0(9) - 0.2, 96, 0.26)
tb = W(5, 'enfrentan')
while tb < st0(9) - 0.5: boom(tb, rng.uniform(0.18, 0.32), rng.rand() * 1.4 - 0.7, rng.uniform(0.3, 0.8)); tb += rng.uniform(1.0, 1.9)
waves(st0(6) - 0.8, st0(9) + 0.3, 0.06, 800); oars(st0(6) - 0.5, st0(9) - 0.2, 0.08, 1.5)
heart(W(6, 'fiebre') - 0.2, st0(9), 104, 128, 0.26)
add(thud(0.6, 0.6), W(7, 'bajo'), 0.0, 1.0, 0.25)
th1 = W(9, 'disparos'); th3 = W(9, 'mano')
for tc_ in (th1, th1 + 0.45, th3): crack(tc_, 0.55, rng.rand() * 0.6 - 0.3); add(thud(0.7, 0.8), tc_ + 0.02, 0.0, 1.0, 0.3)
heart(th3 + 0.4, B[2] + 1.0, 62, 48, 0.32)
paper(B[2], 1.3, 0.4)

# ================= S2 · la mano
heart(B[2] + 1.0, st0(13) - 0.3, 50, 46, 0.22)
add(thud(0.8, 1.0), W(10, 'inutil'), 0.0, 1.0, 0.35); n_ = int(1.8 * SR); add(lp(nz(n_), 260) * swell(n_, 0.2, 1.4) * 0.14, W(10, 'inutil'), 0.0, 1.0, 0.3)
whoosh(st0(13) - 0.4, 0.9, 0.10, 300, 3000)
for p_ in (('la', 1), ('ocasion', 0), ('los', 0)): scratch(W(13, p_[0], p_[1]), 1.0, 0.10)
bell(W(13, 'siglos') + 0.2, 294, 0.08); bell(W(13, 'siglos') + 0.2, 440, 0.05)
paper(B[3], 1.3, 0.4)

# ================= S3 · captura y Argel
whoosh(B[3] + 0.2, 1.8, 0.10, 300, 3000)
waves(st0(15) - 0.5, W(16, 'asaltan') + 2.0, 0.05, 750); oars(st0(15), W(16, 'asaltan') - 0.5, 0.07, 1.4)
lute(st0(15) - 0.3, st0(16) + 0.3, 84, 0.07)
paper(W(15, 'cartas') + 0.2, 1.0, 0.35)
war_drums(st0(16) - 0.2, W(16, 'asaltan') + 0.1, 120, 0.24)
ta = W(16, 'asaltan'); boom(ta, 0.40, -0.3, 0.2); crack(ta + 0.15, 0.35, 0.4); clang(ta + 0.25, 640, 0.2, 0.2); clang(ta + 0.4, 820, 0.16, -0.2)
murmur(ta - 0.2, ta + 1.6, 0.10)
add(thud(0.8, 0.9), W(17, 'condenan'), 0.0, 1.0, 0.3)
sonar(W(17, 'importante') + 0.1, 600, 0.16, 1.8)
coins(W(17, 'quinientos'), 16, 0.12, 1.0)
whoosh(st0(18) - 0.2, 1.4, 0.10, 250, 2500); sonar(W(18, 'argel') + 0.05, 520, 0.22, 2.6)
murmur(W(18, 'mercado') - 0.3, st0(19) + 0.3, 0.12); chains(W(18, 'cautivos'), 0.9, 0.10, 0.3)
coins(W(19, 'dinero'), 6, 0.09, 0.6)
steps(W(19, 'deja') - 0.1, 7, 2.6, 0.18, 0.1, 0.9, 100); chains(W(19, 'hermano') + 0.3, 0.6, 0.08, -0.4)
paper(B[4], 1.3, 0.4)

# ================= S4 · cuatro fugas
tk = st0(20); i_ = 0
while tk < st0(25) - 0.3: add(tick(780 + (i_ % 2) * 120, 0.10), tk, 0.0); tk += 0.62; i_ += 1
add(thud(0.6, 0.6), W(20, 'cuatro'), 0.0, 1.0, 0.3)
steps(st0(21), 8, 4.0, 0.16, -0.5, 0.5)
for j in range(8): drip(st0(22) + 0.5 + j * 0.55 + rng.rand() * 0.1, 0.10)
paper(st0(23) + 0.3, 1.0, 0.35); clang(W(23, 'detienen') + 0.05, 300, 0.2, 0.2, 2.0)
waves(st0(24) - 0.3, st0(24) + 2.8, 0.05, 700)
for p_ in ((21, 'guia'), (22, 'traidor'), (23, 'detienen'), (24, 'traicion')): add(thud(0.6, 0.7), W(*p_), 0.0, 1.0, 0.3)
add(thud(1.1, 1.3), W(25, 'culpa'), 0.0, 1.0, 0.45); heart(st0(25), st0(27), 70, 96, 0.26); chains(st0(26) - 0.2, 0.7, 0.10)
tk = W(26, 'dos'); t1_ = W(26, 'palos') + 0.3; i_ = 0
while tk < t1_: add(tick(1100 + 8 * i_, 0.12), tk, 0.0); tk += 0.11 * (1 - 0.5 * (tk - W(26, 'dos')) / (t1_ - W(26, 'dos'))); i_ += 1
paper(B[5], 1.3, 0.4)

# ================= S5 · rescate
sonar(st0(28) + 0.3, 520, 0.22, 2.6)
oars(st0(29), st0(31), 0.06, 1.6); waves(st0(29) - 0.3, st0(31), 0.04, 700)
tc_ = W(29, 'constantinopla'); bell(tc_ + 0.1, 98, 0.22); bell(tc_ + 0.1, 147, 0.10); subdrone(tc_, st0(31), 30.9, 0.14, 1, 1)
add(thud(0.9, 1.0), W(30, 'imposible') + 0.1, 0.0, 1.0, 0.4)
drone([146.8, 220.0, 293.7], st0(31) - 0.2, st0(32) + 0.5, 0.035, 1400, 1.0, 1.0)
tp_ = W(31, 'pagan'); coins(tp_ - 0.1, 10, 0.12, 0.7); bell(tp_ + 0.15, 587, 0.12); bell(tp_ + 0.15, 880, 0.08); bell(tp_ + 0.15, 1175, 0.05)
waves(st0(32) - 0.3, B[6] + 0.5, 0.05, 800)
for p_ in ('cinco', 'treinta', 'nada'): add(thud(0.6, 0.6), W(32, p_), 0.0, 1.0, 0.25)
paper(B[6], 1.3, 0.4)

# ================= S6 · recaudador, cárcel y Quijote
clang(W(33, 'heroe'), 520, 0.16, -0.3); coins(W(33, 'recaudador'), 6, 0.08, 0.5)
scratch(W(34, 'cuentas') - 0.2, 1.2, 0.10)
tcar = W(34, 'carcel'); clang(tcar + 0.25, 140, 0.45, 0.0, 3.0); add(thud(1.2, 1.4), tcar + 0.25, 0.0, 1.0, 0.5); clang(tcar + 0.45, 210, 0.20, 0.3, 2.0)
for j in range(6): drip(tcar + 1.0 + j * 0.6 + rng.rand() * 0.1, 0.08)
whoosh(st0(35) - 0.5, 1.0, 0.10, 300, 3500)
te = W(36, 'exito'); bell(te + 0.2, 587, 0.12); bell(te + 0.2, 740, 0.08); bell(te + 0.2, 880, 0.08)
scratch(W(37, 'engendro') - 0.3, 1.0, 0.10); scratch(W(37, 'carcel') - 0.4, 0.9, 0.10)
sonar(W(38, 'sevilla') + 0.1, 600, 0.14, 2.0)
paper(B[7], 1.3, 0.4)

# ================= S7 · cierre
wind(B[7] - 0.3, W(39, 'escrito') + 0.5, 0.10)
for j in range(4): creak(B[7] + 0.2 + j * 0.75, 0.10)
gallop(B[7] + 0.1, W(39, 'escrito') - 0.1, 0.20)
te_ = W(39, 'escrito'); boom(te_, 0.30, -0.4, 0.5); boom(te_ + 1.3, 0.20, 0.5, 0.7); waves(te_ - 0.2, st0(40) + 0.4, 0.05, 800)
bell(W(40, 'novela') + 0.1, 440, 0.08); bell(W(40, 'novela') + 0.1, 659, 0.06)
sonar(st0(41) + 0.1, 440, 0.20, 2.8)
t_su = W(42, 'suscribete'); bell(t_su - 0.05, 1568, 0.14); bell(t_su + 0.28, 2093, 0.12); bell(t_su + 0.28, 1046, 0.05)
lute(st0(40) - 0.2, TEND + 0.2, 84, 0.075)

# ---------- mezcla final
def rev(x):
    n_ir = int(2.6 * SR); ir_ = (rng.randn(n_ir) * np.exp(-np.arange(n_ir) / SR / 0.75)).astype(np.float32); ir_ = lp(ir_, 5200); ir_ = np.concatenate([np.zeros(int(0.03 * SR), np.float32), ir_])
    y = fftconvolve(x, ir_)[:N]; return y / (np.abs(y).max() + 1e-9)
SL, SR_, L, R, AMB, VOZ, DUCK = AL.SL, AL.SR_, AL.L, AL.R, AL.AMB, AL.VOZ, AL.DUCK
wl = rev(SL); wr_ = rev(SR_)
amb = AMB * DUCK[None, :]
HK = 1 + 0.6 * np.clip((3.3 - tt(N)) / 0.3, 0, 1)
fxL = (L * (0.55 + 0.45 * DUCK) + amb[0]) * HK; fxR = (R * (0.55 + 0.45 * DUCK) + amb[1]) * HK
fxL = fxL + 0.30 * wl * np.abs(SL).max() * 6 * DUCK; fxR = fxR + 0.30 * wr_ * np.abs(SR_).max() * 6 * DUCK
mixL = VOZ * 1.2 + np.tanh(fxL * 1.2) / 1.2 * 0.50; mixR = VOZ * 1.2 + np.tanh(fxR * 1.2) / 1.2 * 0.50
mixL = np.tanh(mixL * 1.0) / np.tanh(1.0); mixR = np.tanh(mixR * 1.0) / np.tanh(1.0)
HG = 1 + 0.35 * np.clip((3.35 - tt(N)) / 0.35, 0, 1); mixL *= HG; mixR *= HG
pk = max(np.abs(mixL).max(), np.abs(mixR).max()); mixL *= 0.92 / pk; mixR *= 0.92 / pk
fade = np.clip(tt(N) / 0.25, 0, 1) * np.clip((TEND + 0.4 - tt(N)) / 2.2, 0, 1); mixL *= fade; mixR *= fade
st = np.stack([mixL, mixR], 1)[:int((TEND + 0.1) * SR)]
wv = wave.open('/home/claude/serie/cervantes/cv_audio_raw.wav', 'wb'); wv.setnchannels(2); wv.setsampwidth(2); wv.setframerate(SR); wv.writeframes((np.clip(st, -1, 1) * 32767).astype(np.int16).tobytes()); wv.close()
print('ok', round(float(np.sqrt((st ** 2).mean())), 3), 'voz rms', round(float(np.sqrt((VOZ ** 2).mean())), 3))
