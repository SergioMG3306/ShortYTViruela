import sys; sys.path.insert(0, '/home/claude/serie/cervantes')
from cv_art import *
t = 1.3
a = sea_img(300); waves(a, t); galley(a, 270, 430, 380, 1, t, smoke=1.0); galley(a, 90, 330, 90, -1, t, kind='cors'); galley(a, 440, 340, 110, -1, t, kind='cors')
b = np.empty((H, W, 3), F32); b[:] = PAPER
for i, k in enumerate(['soldier', 'cervantes', 'rodrigo', 'corsair', 'friar', 'captive']):
    person(b, 60 + (i % 3) * 170, 300 + (i // 3) * 300, 240 if i else 260, k, 1.0, t, 'stand', gun=(k == 'soldier'), chain=(k == 'captive'))
c = np.empty((H, W, 3), F32); c[:] = PAPER
for i, k in enumerate(['helmet', 'chains', 'run', 'letter', 'coins', 'feet', 'cave', 'ship', 'stick', 'ledger', 'wheat', 'book', 'quill', 'messenger']):
    icon(c, k, 90 + (i % 3) * 180, 90 + (i // 3) * 175, 1.0, 1.0, t)
d = cell_img(); person(d, 200, 600, 300, 'writer', 1.0, t, 'write'); desk(d, 210, 470, 240, 1.0, t)
e = field_img(540, 0.8); windmill(e, 380, 560, 1.6, t); windmill(e, 500, 540, 0.9, t + 1); knight(e, 140, 600, 1.3, t)
f = np.empty((H, W, 3), F32); f[:] = PAPER; big_hand(f, 270, 330, 360, 1.0, 0.0); big_hand(f, 270, 720, 300, 1.0, 1.0)
out = np.hstack([cv2.resize(np.clip(i, 0, 1), (360, 640)) for i in (a, b, c, d, e, f)])
cv2.imwrite('t_art.jpg', (out[:, :, ::-1] * 255).astype(np.uint8))
