"""Ilustraciones propias para el Short de Cervantes: galeras, mar, personajes, iconos, cárcel, molinos."""
import sys, math
sys.path.insert(0, '/home/claude/serie/cervantes')
sys.path.insert(0, '/home/claude/serie/trailer/v2')
from cv_lib import *
from cv_lib import _f, _d
from cv_artbase import _L, _P, _C, _E, _fm, WOOD, OCHRE, CLAY, SAGE, NAVY, BONE, SKIN, STONE, GOLD
from lib import hand_mask

STEEL = C3(0.62, 0.64, 0.66); DARK = C3(0.16, 0.14, 0.13); HAIR = C3(0.30, 0.20, 0.13); WHITE = C3(0.95, 0.93, 0.88)
CORS = C3(0.26, 0.20, 0.17); CSAIL = C3(0.74, 0.30, 0.20); SEA = C3(0.34, 0.50, 0.56); TBLUE = C3(0.22, 0.34, 0.66)


def mk(): return np.zeros((H, W), np.uint8)
def paint(img, m, col, a=1.0, bl=0.5): over(img, _fm(m, bl), col, a)
def _R(m, x, y, r, th=2):
    cv2.circle(m, (int(round(x * 16)), int(round(y * 16))), int(round(max(r, 0.3) * 16)), 255, max(1, int(round(th))), cv2.LINE_AA, shift=4)
def outline(img, m, a=1.0, k=0.85, w=1.2):
    f = _fm(m, 0.0); e = np.clip(cv2.GaussianBlur(f, (0, 0), w) - f, 0, 1) * 2.4 + np.clip(f - cv2.GaussianBlur(f, (0, 0), w), 0, 1) * 2.4
    over(img, np.clip(e, 0, 1), INK, a * k)


# ------------------------------------------------------------------ galera
def galley(img, x, y, L, facing=1, t=0.0, a=1.0, kind='cris', name=None, row=True, sink=0.0, roll=0.0, smoke=0.0):
    """galera de perfil; (x,y)=centro en la línea de flotación; L=eslora px. kind: 'cris' (cristiana) | 'cors' (corsaria)."""
    u = L / 100.0; f = facing
    def P(px, py):
        ca, sa = math.cos(roll), math.sin(roll); qx, qy = px * f * u, py * u
        return (x + qx * ca - qy * sa, y + sink * u * 10 + qx * sa + qy * ca)
    def PP(pts): return [P(px, py) for px, py in pts]
    hull_c = WOOD if kind == 'cris' else CORS; sail_c = BONE if kind == 'cris' else CSAIL; band_c = RED if kind == 'cris' else OCHRE
    allm = mk()
    # mástiles y velas latinas
    mm = mk(); sm = mk(); fl = mk()
    _L(mm, PP([(4, -6), (4, -50)]), max(1, 1.1 * u)); _L(mm, PP([(30, -6), (30, -34)]), max(1, 0.9 * u))
    s1 = PP([(-22, -22), (32, -56), (6, -9)]); s2 = PP([(16, -17), (46, -36), (31, -8)])
    _P(sm, s1); _P(sm, s2)
    _L(mm, PP([(-24, -21), (34, -57)]), max(1, 0.8 * u)); _L(mm, PP([(14, -16), (48, -37)]), max(1, 0.7 * u))
    wv = math.sin(t * 5.0)
    _P(fl, PP([(4, -50), (4, -45), (14 + wv, -47.5 + 0.8 * wv)])); _P(fl, PP([(-50, -22), (-50, -17), (-41 + wv, -19.5)]))
    # casco
    hm = mk()
    hull = [(-52, -10), (-44, -7), (-30, -6), (36, -6), (44, -5), (60, -3.2), (44, -1.2), (36, 1.5), (26, 3), (-36, 3), (-48, 0), (-53, -4)]
    _P(hm, PP(hull))
    cm = mk(); _P(cm, PP([(-51, -9), (-38, -8), (-38, -18), (-41, -21), (-48, -21), (-51, -18)]))
    bm = mk(); _P(bm, PP([(-38, -8.5), (38, -8.5), (40, -5.5), (-38, -5.5)]))
    np.maximum(allm, hm, out=allm); np.maximum(allm, cm, out=allm); np.maximum(allm, sm, out=allm)
    shadow(img, _fm(allm, 0.5), 0.18 * a, (2, 3), 2.0)
    paint(img, sm, sail_c, a); over(img, _fm(sm, 0.5) * (((XX * 0.4 - YY) % (max(3.0, 2.2 * u))) < 0.7), INK, 0.10 * a)
    if kind == 'cors': over(img, _fm(sm, 0.5) * ((((XX - YY * 0.6) / max(1.0, 3.5 * u)) % 2) < 1), C3(0.55, 0.16, 0.12), 0.35 * a)
    paint(img, mm, WOOD * 0.8, a)
    paint(img, fl, RED if kind == 'cris' else C3(0.70, 0.12, 0.10), a)
    paint(img, hm, hull_c, a); paint(img, bm, band_c, a * 0.9); paint(img, cm, hull_c * 1.25, a)
    if u > 0.25:
        om = mk(); n = 16 if u > 1.2 else 9
        for i in range(n):
            xo = -34 + 68 * i / (n - 1); ph = (t * 1.1 * (1 if row else 0)) * 2 * math.pi + i * 0.05
            sw = 6.0 * math.sin(ph); dip = 2.5 * math.cos(ph)
            _L(om, PP([(xo, -6.5), (xo - 9 + sw, 15 + dip)]), max(1, 0.8 * u))
        paint(img, om, C3(0.62, 0.48, 0.30) if kind == 'cris' else C3(0.48, 0.36, 0.24), a); outline(img, om, a, 0.35, 0.6)
    if u > 0.6:
        wm = mk()
        for i in range(3): _C(wm, *P(-48 + i * 3.6, -14), 0.9 * u)
        paint(img, wm, C3(0.98, 0.80, 0.40) if smoke > 0 else DARK, a * 0.8)
    if u > 0.25:
        outline(img, cv2.max(hm, cm), a, 0.8, 0.9); outline(img, sm, a, 0.55, 0.9)
    # espuma
    if u > 0.5:
        fm_ = mk()
        for i in range(10):
            xx = -50 + i * 11 + 3 * math.sin(t * 2 + i); _E(fm_, *P(xx, 3.5), 4 * u, 0.9 * u)
        paint(img, fm_, C3(0.92, 0.94, 0.92), a * 0.55, 1.0)
    if smoke > 0:
        for j in range(5):
            ph = (t * 0.35 + j / 5) % 1.0; sx, sy = P(40 - j * 18, -10 - 40 * ph)
            smm = mcirc([(sx + 6 * u * ph, sy, (5 + 14 * ph) * u)], 3.0); over(img, smm, C3(0.82, 0.80, 0.76), a * smoke * 0.55 * (1 - ph))
    if name:
        ox, oy = P(-10, 14)
    return P


# ------------------------------------------------------------------ mar y cielo
_SC = {}
def sea_img(hy=300, dusk=0.0):
    k = ('sea', hy, round(dusk, 2))
    if k in _SC: return _SC[k].copy()
    g = np.clip(YY / hy, 0, 1)[..., None]
    sky = C3(0.70, 0.78, 0.82) * (1 - g) + C3(0.96, 0.90, 0.76) * g
    if dusk > 0: sky = sky * (1 - dusk) + (C3(0.42, 0.40, 0.55) * (1 - g) + C3(0.98, 0.70, 0.42) * g) * dusk
    cl_ = cv2.GaussianBlur(fractal(37, (60, 120, 240)).astype(F32), (0, 0), 6); cl_ = np.clip((cl_ - 0.52) * 3.0, 0, 1) * np.clip(1 - YY / hy, 0, 1)
    img = sky.astype(F32); over(img, cl_, C3(1.0, 0.98, 0.94), 0.5)
    gs = np.clip((YY - hy) / (H - hy), 0, 1)[..., None]
    sea = C3(0.48, 0.62, 0.66) * (1 - gs) + C3(0.22, 0.36, 0.42) * gs
    sm = (YY >= hy).astype(F32)[..., None]
    img = img * (1 - sm) + sea * sm
    over(img, (np.abs(YY - hy) < 1.2).astype(F32), INK, 0.35)
    img *= (0.92 + 0.14 * _f[..., None])
    _SC[k] = np.clip(img, 0, 1).astype(F32); return _SC[k].copy()

def field_img(hy=520, dusk=0.8):
    k = ('field', hy, dusk)
    if k in _SC: return _SC[k].copy()
    img = sea_img(hy, dusk)
    gm = (YY >= hy).astype(F32); g = np.clip((YY - hy) / (H - hy), 0, 1)[..., None]
    land = C3(0.78, 0.62, 0.38) * (1 - g) + C3(0.50, 0.38, 0.24) * g
    land = land * (0.9 + 0.2 * fractal(19, (20, 40, 90))[..., None])
    img = img * (1 - gm[..., None]) + land * gm[..., None]
    rows = ((np.abs(np.sin((XX - 270) / np.maximum(YY - hy + 30, 1) * 9.0)) < 0.12) * gm * np.clip((YY - hy) / 200, 0, 1)).astype(F32)
    over(img, rows, C3(0.40, 0.28, 0.16), 0.30)
    over(img, (np.abs(YY - hy) < 1.2).astype(F32), INK, 0.35)
    _SC[k] = np.clip(img, 0, 1).astype(F32); return _SC[k].copy()


def waves(img, t, hy=300, a=1.0, n=70, seed=4):
    rs = np.random.RandomState(seed); m = mk()
    for i in range(n):
        yy = hy + 8 + (H - hy) * rs.rand() ** 1.6; sc = 0.3 + 1.4 * (yy - hy) / (H - hy)
        xx = (rs.rand() * (W + 80) + t * 10 * sc * (1 if i % 2 else 0.6)) % (W + 80) - 40
        w = 10 + 26 * sc
        pts = [(xx + w * j / 8, yy - 2.2 * sc * math.sin(math.pi * j / 8)) for j in range(9)]
        _L(m, pts, max(1, 1.3 * sc))
    paint(img, m, C3(0.90, 0.94, 0.92), 0.45 * a, 0.6)


# ------------------------------------------------------------------ personajes (papel recortado, de frente)
def person(img, x, y, h, kind='soldier', a=1.0, t=0.0, pose='stand', look=0.0, chain=False, gun=False, wound=0.0):
    """figura de frente con los pies en (x,y) y altura h. kind: soldier, cervantes, corsair, friar, captive, rodrigo, writer."""
    u = h / 10.0
    walk = pose == 'walk'; ph = t * 2 * math.pi * 1.4
    ink = mk(); M = {}
    def m_(k):
        if k not in M: M[k] = mk()
        return M[k]
    hx, hy = x + look * 0.3 * u, y - 9.0 * u
    shy = y - 7.9 * u; wy = y - 4.9 * u
    long_robe = kind in ('friar',)
    # piernas
    if not long_robe:
        for sg in (-1, 1):
            sw = 0.9 * u * math.sin(ph) * sg if walk else 0.0
            hip = (x + 0.55 * u * sg, wy + 0.3 * u); ft = (x + 0.75 * u * sg + sw, y - (0.5 * u * max(0, math.sin(ph * sg)) if walk else 0))
            _L(ink, [hip, ft], 1.25 * u + 2); _L(m_('leg'), [hip, ft], 1.25 * u)
            _E(ink, ft[0] + 0.25 * u * sg, ft[1], 0.85 * u + 1, 0.4 * u + 1); _E(m_('shoe'), ft[0] + 0.25 * u * sg, ft[1], 0.85 * u, 0.4 * u)
    # torso
    tor = [(x - 1.25 * u, shy), (x + 1.25 * u, shy), (x + 1.0 * u, wy), (x - 1.0 * u, wy)]
    if long_robe: tor = [(x - 1.25 * u, shy), (x + 1.25 * u, shy), (x + 1.9 * u, y), (x - 1.9 * u, y)]
    if kind == 'captive': tor = [(x - 1.2 * u, shy), (x + 1.2 * u, shy), (x + 1.3 * u, wy + 1.4 * u), (x + 0.5 * u, wy + 1.0 * u), (x - 0.2 * u, wy + 1.5 * u), (x - 1.3 * u, wy + 1.2 * u)]
    _P(ink, [(px + (1 if px > x else -1), py + (1 if py > shy else -1)) for px, py in tor]); _P(m_('torso'), tor)
    # calzas / gregüescos
    if kind in ('soldier', 'cervantes', 'rodrigo', 'corsair'):
        br = [(x - 1.05 * u, wy - 0.2 * u), (x + 1.05 * u, wy - 0.2 * u), (x + 1.45 * u, wy + 1.6 * u), (x - 1.45 * u, wy + 1.6 * u)]
        if kind == 'corsair': br = [(x - 1.05 * u, wy - 0.2 * u), (x + 1.05 * u, wy - 0.2 * u), (x + 1.6 * u, wy + 3.4 * u), (x + 0.2 * u, wy + 3.0 * u), (x - 0.2 * u, wy + 3.0 * u), (x - 1.6 * u, wy + 3.4 * u)]
        _P(ink, [(px, py + 1) for px, py in br]); _P(m_('breech'), br)
    # brazos
    arms = []
    for sg in (-1, 1):
        sh = (x + 1.15 * u * sg, shy + 0.4 * u)
        if pose == 'write' and sg == 1: hd = (x + 0.6 * u, wy - 0.3 * u); el = (x + 1.6 * u, wy - 1.0 * u)
        elif pose == 'write': hd = (x - 0.9 * u, wy - 0.1 * u); el = (x - 1.7 * u, wy - 0.9 * u)
        elif pose == 'raise' and sg == 1: hd = (x + 2.0 * u, shy - 2.2 * u); el = (x + 2.0 * u, shy - 0.6 * u)
        else:
            sw = -0.6 * u * math.sin(ph) * sg if walk else 0.0
            el = (x + 1.45 * u * sg, shy + 1.7 * u); hd = (x + 1.55 * u * sg + sw, wy + 0.2 * u)
        arms.append((sh, el, hd))
        _L(ink, [sh, el, hd], 0.85 * u + 2); _L(m_('sleeve'), [sh, el, hd], 0.85 * u)
    # cabeza
    _C(ink, hx, hy, 0.82 * u + 1.2)
    for (sh, el, hd) in arms: _C(m_('skin'), hd[0], hd[1], 0.42 * u)
    _C(m_('skin'), hx, hy, 0.82 * u)
    # detalles por tipo
    if kind in ('cervantes', 'writer', 'rodrigo'):
        _E(m_('hair'), hx, hy - 0.25 * u, 0.88 * u, 0.7 * u, 0, 180, 360)
        if kind != 'rodrigo':
            _E(m_('hair'), hx, hy + 0.45 * u, 0.62 * u, 0.55 * u, 0, 0, 180)      # barba
            _E(m_('ruff'), x, shy - 0.05 * u, 1.25 * u, 0.42 * u)
        else:
            _E(m_('ruff'), x, shy - 0.05 * u, 0.8 * u, 0.25 * u)
    if kind == 'soldier':
        _E(m_('helm'), hx, hy - 0.45 * u, 1.45 * u, 0.32 * u)                  # ala del morrión
        _E(m_('helm'), hx, hy - 0.62 * u, 0.85 * u, 0.85 * u, 0, 180, 360)
        _P(m_('helm'), [(hx - 0.15 * u, hy - 1.45 * u), (hx + 0.15 * u, hy - 1.45 * u), (hx + 0.08 * u, hy - 1.75 * u), (hx - 0.08 * u, hy - 1.75 * u)])
        _E(m_('hair'), hx, hy + 0.45 * u, 0.55 * u, 0.45 * u, 0, 0, 180)
        _L(m_('sash'), [(x - 1.15 * u, shy + 0.3 * u), (x + 1.0 * u, wy - 0.2 * u)], 0.55 * u)
        if gun:
            _L(ink, [(x - 2.4 * u, wy + 0.8 * u), (x + 2.6 * u, shy - 2.6 * u)], 0.45 * u + 2); _L(m_('gun'), [(x - 2.4 * u, wy + 0.8 * u), (x + 2.6 * u, shy - 2.6 * u)], 0.45 * u)
    if kind == 'corsair':
        _E(m_('turban'), hx, hy - 0.5 * u, 1.0 * u, 0.62 * u); _C(m_('turban2'), hx, hy - 0.9 * u, 0.3 * u)
        _E(m_('hair'), hx, hy + 0.45 * u, 0.55 * u, 0.45 * u, 0, 0, 180)
        _L(m_('sash'), [(x - 1.0 * u, wy - 0.15 * u), (x + 1.0 * u, wy - 0.15 * u)], 0.5 * u)
    if kind == 'friar':
        _E(m_('hood'), x, shy + 0.1 * u, 1.35 * u, 0.55 * u)
        _P(m_('hood'), [(hx - 0.95 * u, hy + 0.2 * u), (hx + 0.95 * u, hy + 0.2 * u), (hx + 0.7 * u, shy), (hx - 0.7 * u, shy)])
        _L(m_('crossr'), [(x, shy + 0.9 * u), (x, shy + 2.5 * u)], 0.36 * u); _L(m_('crossb'), [(x - 0.65 * u, shy + 1.45 * u), (x + 0.65 * u, shy + 1.45 * u)], 0.36 * u)
        _E(m_('hair'), hx, hy - 0.6 * u, 0.6 * u, 0.25 * u)                        # tonsura
    if kind == 'captive':
        _E(m_('hair'), hx, hy - 0.3 * u, 0.86 * u, 0.62 * u, 0, 180, 360); _E(m_('hair'), hx, hy + 0.45 * u, 0.6 * u, 0.5 * u, 0, 0, 180)
    if chain:
        cm = mk()
        for j in range(7): _R(cm, x - 0.9 * u + j * 0.3 * u, y - 0.4 * u + 0.15 * u * math.sin(j * 1.3), 0.17 * u, max(1, 0.12 * u))
        M['chain'] = cm
    # pintar
    sh_ = cv2.GaussianBlur(_fm(ink, 0.0), (0, 0), 3.0); img *= (1 - 0.22 * a * np.roll(np.roll(sh_, 3, 0), 3, 1))[..., None]
    over(img, _fm(ink, 0.45), INK, 0.92 * a)
    COL = {
        'soldier': dict(torso=STEEL, breech=CLAY, sleeve=OCHRE, leg=DARK, shoe=DARK),
        'cervantes': dict(torso=DARK * 1.4, breech=DARK * 1.2, sleeve=DARK * 1.5, leg=DARK, shoe=DARK),
        'writer': dict(torso=DARK * 1.4, breech=DARK * 1.2, sleeve=DARK * 1.5, leg=DARK, shoe=DARK),
        'rodrigo': dict(torso=NAVY, breech=NAVY * 0.8, sleeve=NAVY * 1.15, leg=DARK, shoe=DARK),
        'corsair': dict(torso=C3(0.70, 0.18, 0.14), breech=C3(0.88, 0.84, 0.74), sleeve=C3(0.90, 0.86, 0.76), leg=SKIN * 0.9, shoe=C3(0.55, 0.36, 0.20)),
        'friar': dict(torso=WHITE, sleeve=WHITE * 0.96),
        'captive': dict(torso=C3(0.58, 0.48, 0.36), sleeve=C3(0.55, 0.45, 0.34), leg=SKIN * 0.85, shoe=SKIN * 0.7),
    }[kind]
    order = ['leg', 'shoe', 'breech', 'torso', 'sleeve', 'sash', 'gun', 'hood', 'crossr', 'crossb', 'skin', 'hair', 'ruff', 'helm', 'turban', 'turban2', 'chain']
    extra = dict(skin=SKIN, hair=HAIR, ruff=WHITE, helm=STEEL * 1.08, sash=RED, gun=WOOD, hood=WHITE * 0.9, crossr=RED, crossb=TBLUE, turban=WHITE, turban2=RED, chain=STEEL * 0.8)
    for k in order:
        if k in M: paint(img, M[k], COL.get(k, extra.get(k, INK)), a, 0.45)
    if 'chain' in M: outline(img, M['chain'], a, 0.6, 0.7)
    return dict(head=(hx, hy), chest=(x, shy + 1.4 * u), hands=[ar[2] for ar in arms], u=u)


# ------------------------------------------------------------------ iconos
def icon(img, kind, x, y, s=1.0, a=1.0, t=0.0):
    m = mk(); o = mk()
    if kind == 'helmet':
        _E(m, x, y + 10 * s, 46 * s, 9 * s); _E(m, x, y + 6 * s, 28 * s, 30 * s, 0, 180, 360); _P(m, [(x - 4 * s, y - 24 * s), (x + 4 * s, y - 24 * s), (x + 2 * s, y - 36 * s), (x - 2 * s, y - 36 * s)])
        paint(img, m, STEEL * 1.05, a); outline(img, m, a, 0.9, 1.0)
        hl = mk(); _E(hl, x - 10 * s, y - 8 * s, 6 * s, 10 * s, -20); paint(img, hl, WHITE, a * 0.6, 1.5)
    elif kind == 'chains':
        for j in range(5):
            cx = x - 44 * s + j * 22 * s; cy = y + 6 * math.sin(j * 0.9 + t * 0.0) * s
            if j % 2 == 0: cv2.ellipse(m, (int(cx * 16), int(cy * 16)), (int(14 * s * 16), int(8 * s * 16)), 0, 0, 360, 255, max(2, int(4 * s)), cv2.LINE_AA, 4)
            else: cv2.ellipse(m, (int(cx * 16), int(cy * 16)), (int(13 * s * 16), int(4 * s * 16)), 0, 0, 360, 255, max(2, int(4 * s)), cv2.LINE_AA, 4)
        _C(m, x + 62 * s, y + 4 * s, 13 * s); hole = mk(); _C(hole, x + 62 * s, y + 4 * s, 7 * s)
        paint(img, m, STEEL * 0.85, a); paint(img, hole, CREAM, a); outline(img, m, a, 0.8, 0.8)
    elif kind == 'run':
        person(img, x, y + 40 * s, 82 * s, 'captive', a, t * 1.5, 'walk')
        for j in range(3): _L(o, [(x - 40 * s - j * 6 * s, y - 10 * s + j * 14 * s), (x - 24 * s - j * 6 * s, y - 10 * s + j * 14 * s)], max(1, 3 * s))
        paint(img, o, INK, a * 0.7)
    elif kind == 'letter':
        _P(m, [(x - 46 * s, y - 30 * s), (x + 46 * s, y - 30 * s), (x + 46 * s, y + 30 * s), (x - 46 * s, y + 30 * s)]); paint(img, m, C3(0.95, 0.90, 0.78), a)
        _L(o, [(x - 46 * s, y - 30 * s), (x, y + 4 * s), (x + 46 * s, y - 30 * s)], max(1, 2.2 * s)); paint(img, o, INK, a * 0.7); outline(img, m, a, 0.8, 1.0)
        sl = mk(); _C(sl, x, y + 4 * s, 11 * s); paint(img, sl, RED * 0.9, a); sl2 = mk(); _R(sl2, x, y + 4 * s, 6 * s, max(1, 2 * s)); paint(img, sl2, C3(0.5, 0.08, 0.06), a)
    elif kind == 'coins':
        for j in range(5):
            cx = x - 28 * s + (j % 3) * 28 * s; cy = y + 18 * s - (j // 3) * 22 * s
            for k in range(4):
                c_ = mk(); _E(c_, cx, cy - k * 6 * s, 15 * s, 6 * s); paint(img, c_, GOLD * (0.85 + 0.05 * k), a); e_ = mk(); cv2.ellipse(e_, (int(cx * 16), int((cy - k * 6 * s) * 16)), (int(15 * s * 16), int(6 * s * 16)), 0, 0, 360, 255, 1, cv2.LINE_AA, 4); paint(img, e_, INK, a * 0.6)
    elif kind == 'feet':
        for j in range(5):
            fx = x - 50 * s + j * 25 * s; fy = y + (8 if j % 2 else -8) * s
            f_ = mk(); _E(f_, fx, fy, 9 * s, 5 * s, -10); _C(f_, fx + 10 * s, fy - 1 * s, 3 * s); paint(img, f_, INK, a * 0.75)
        ar = mk(); cv2.arrowedLine(ar, (int((x + 60 * s) * 16), int(y * 16)), (int((x + 76 * s) * 16), int(y * 16)), 255, max(1, int(3 * s)), cv2.LINE_AA, 4, 0.6); paint(img, ar, INK, a * 0.75)
    elif kind == 'cave':
        _P(m, [(x - 70 * s, y + 40 * s), (x - 60 * s, y - 10 * s), (x - 30 * s, y - 40 * s), (x + 20 * s, y - 44 * s), (x + 60 * s, y - 16 * s), (x + 72 * s, y + 40 * s)])
        paint(img, m, STONE, a); over(img, _fm(m, 0.5) * (((XX + YY * 0.4) % 7) < 1.6), INK, 0.18 * a)
        hole = mk(); _E(hole, x, y + 40 * s, 34 * s, 50 * s, 0, 180, 360); paint(img, hole, DARK, a)
        outline(img, m, a, 0.8, 1.0)
        for j in range(3): person(img, x - 16 * s + j * 16 * s, y + 38 * s, 34 * s, 'captive', a * 0.85)
    elif kind == 'ship':
        galley(img, x, y + 14 * s, 120 * s, 1, t, a, 'cris', row=False)
        sm = mk(); _L(sm, [(x - 70 * s, y + 18 * s), (x + 70 * s, y + 18 * s)], max(1, 2 * s)); paint(img, sm, SEA, a * 0.6)
    elif kind == 'stick':
        _L(m, [(x - 40 * s, y + 34 * s), (x + 40 * s, y - 34 * s)], max(2, 8 * s)); paint(img, m, WOOD, a); outline(img, m, a, 0.8, 0.8)
    elif kind == 'ledger':
        _P(m, [(x - 46 * s, y - 36 * s), (x + 46 * s, y - 36 * s), (x + 46 * s, y + 36 * s), (x - 46 * s, y + 36 * s)]); paint(img, m, C3(0.95, 0.91, 0.80), a); outline(img, m, a, 0.8, 1.0)
        for j in range(6):
            _L(o, [(x - 38 * s, y - 26 * s + j * 11 * s), (x + 38 * s, y - 26 * s + j * 11 * s)], 1)
        _L(o, [(x + 10 * s, y - 32 * s), (x + 10 * s, y + 32 * s)], 1); paint(img, o, INK, a * 0.35)
        for j in range(5):
            w_ = 12 + (j * 7) % 18; nm = mk(); _L(nm, [(x + 14 * s, y - 22 * s + j * 11 * s), (x + (14 + w_) * s, y - 22 * s + j * 11 * s)], max(1, 2 * s)); paint(img, nm, INK, a * 0.75)
    elif kind == 'wheat':
        _P(m, [(x - 34 * s, y + 40 * s), (x - 40 * s, y - 10 * s), (x - 24 * s, y - 34 * s), (x + 24 * s, y - 34 * s), (x + 40 * s, y - 10 * s), (x + 34 * s, y + 40 * s)]); paint(img, m, C3(0.80, 0.70, 0.50), a); outline(img, m, a, 0.8, 1.0)
        tie = mk(); _L(tie, [(x - 24 * s, y - 26 * s), (x + 24 * s, y - 26 * s)], max(1, 3 * s)); paint(img, tie, WOOD, a)
        for k in range(5):
            bx = x - 16 * s + k * 8 * s; g_ = mk(); _L(g_, [(bx, y - 30 * s), (bx + (k - 2) * 3 * s, y - 52 * s)], max(1, 1.6 * s))
            for j in range(3): _E(g_, bx + (k - 2) * 3 * s * (0.4 + 0.3 * j), y - 44 * s - j * 4 * s, 2 * s, 3.5 * s)
            paint(img, g_, OCHRE * 0.9, a)
    elif kind == 'book':
        _P(m, [(x - 52 * s, y - 30 * s), (x, y - 22 * s), (x + 52 * s, y - 30 * s), (x + 52 * s, y + 30 * s), (x, y + 38 * s), (x - 52 * s, y + 30 * s)]); paint(img, m, C3(0.95, 0.91, 0.80), a); outline(img, m, a, 0.8, 1.0)
        _L(o, [(x, y - 22 * s), (x, y + 38 * s)], max(1, 2 * s))
        for j in range(4):
            _L(o, [(x - 44 * s, y - 16 * s + j * 11 * s), (x - 8 * s, y - 10 * s + j * 11 * s)], 1); _L(o, [(x + 8 * s, y - 10 * s + j * 11 * s), (x + 44 * s, y - 16 * s + j * 11 * s)], 1)
        paint(img, o, INK, a * 0.55)
    elif kind == 'quill':
        _P(m, [(x + 30 * s, y - 44 * s), (x + 40 * s, y - 40 * s), (x - 20 * s, y + 30 * s), (x - 26 * s, y + 40 * s), (x - 22 * s, y + 26 * s)]); paint(img, m, WHITE, a); outline(img, m, a, 0.7, 0.8)
        _L(o, [(x + 36 * s, y - 42 * s), (x - 26 * s, y + 40 * s)], max(1, 1.5 * s)); paint(img, o, INK, a * 0.6)
    elif kind == 'messenger':
        icon(img, 'letter', x + 8 * s, y - 6 * s, 0.6 * s, a, t)
        person(img, x - 36 * s, y + 40 * s, 76 * s, 'corsair', a * 0.95)
    return


def x_mark(img, x, y, r, col, p=1.0, th=7):
    m = np.zeros((H, W), np.uint8); k = min(1.0, p * 2)
    cv2.line(m, (int((x - r) * 16), int((y - r) * 16)), (int((x - r + 2 * r * k) * 16), int((y - r + 2 * r * k) * 16)), 255, th, cv2.LINE_AA, shift=4)
    if p > 0.5:
        k2 = min(1.0, (p - 0.5) * 2); cv2.line(m, (int((x + r) * 16), int((y - r) * 16)), (int((x + r - 2 * r * k2) * 16), int((y - r + 2 * r * k2) * 16)), 255, th, cv2.LINE_AA, shift=4)
    over(img, cv2.GaussianBlur(m.astype(F32) / 255, (0, 0), 0.6), col, 0.95)


def big_hand(img, x, y, S, a=1.0, dead=0.0):
    """mano izquierda grande (máscara del trailer) con contorno; dead → gris y rayada."""
    hm = hand_mask(int(S))
    full = np.zeros((H, W), F32); x0 = int(x - S / 2); y0 = int(y - S / 2)
    xa, ya, xb, yb = max(0, x0), max(0, y0), min(W, x0 + int(S)), min(H, y0 + int(S))
    full[ya:yb, xa:xb] = hm[ya - y0:yb - y0, xa - x0:xb - x0]
    shadow(img, full, 0.25 * a, (4, 6), 5.0)
    col = SKIN * (1 - dead) + C3(0.66, 0.62, 0.58) * dead
    over(img, full, col, a)
    over(img, full * (((XX - YY) % 9) < 2.0), RED, 0.45 * dead * a)
    e = np.clip(cv2.GaussianBlur(full, (0, 0), 1.4) - full, 0, 1) * 2.5 + np.clip(full - cv2.GaussianBlur(full, (0, 0), 1.4), 0, 1) * 2.5
    over(img, np.clip(e, 0, 1), INK, 0.85 * a)


# ------------------------------------------------------------------ cárcel
def cell_img():
    if 'cell' in _SC: return _SC['cell'].copy()
    img = np.empty((H, W, 3), F32); img[:] = C3(0.46, 0.42, 0.38)
    m = mk(); rs = np.random.RandomState(8)
    for r in range(40):
        y0 = 120 + r * 26; off = (r % 2) * 30
        for c in range(-1, 10):
            x0 = c * 60 + off + rs.randint(-3, 4)
            cv2.rectangle(m, (int((x0 + 2) * 16), int((y0 + 2) * 16)), (int((x0 + 58) * 16), int((y0 + 24) * 16)), 255, -1, cv2.LINE_AA, 4)
    st = _fm(m, 0.6); over(img, st, C3(0.56, 0.51, 0.45), 1.0)
    over(img, st * fractal(12, (8, 16, 32))[...], C3(0.66, 0.60, 0.52), 0.35)
    fl = (YY > 560).astype(F32); over(img, fl, C3(0.32, 0.28, 0.25), 1.0)
    # ventana con barrotes
    wnd = mk(); cv2.rectangle(wnd, (int(330 * 16), int(170 * 16)), (int(450 * 16), int(270 * 16)), 255, -1, cv2.LINE_AA, 4)
    over(img, _fm(wnd), C3(0.88, 0.86, 0.78), 1.0)
    bars = mk()
    for k in range(5): cv2.line(bars, (int((340 + k * 25) * 16), int(170 * 16)), (int((340 + k * 25) * 16), int(270 * 16)), 255, 4 * 16 // 16 + 3, cv2.LINE_AA, 4)
    cv2.line(bars, (int(330 * 16), int(220 * 16)), (int(450 * 16), int(220 * 16)), 255, 4, cv2.LINE_AA, 4)
    over(img, _fm(bars), DARK, 0.95)
    # haz de luz
    beam = mpoly([[(330, 270), (450, 270), (300, 620), (90, 620)]], 8.0); img += beam[..., None] * C3(1.0, 0.92, 0.70) * 0.16
    img *= np.clip(1.15 - 0.6 * _d ** 1.6, 0.35, 1)[..., None]
    _SC['cell'] = np.clip(img, 0, 1).astype(F32); return _SC['cell'].copy()


def desk(img, x, y, w, a=1.0, t=0.0, candle=True):
    m = mk(); _P(m, [(x - w / 2, y), (x + w / 2, y), (x + w / 2, y + 16), (x - w / 2, y + 16)]); _P(m, [(x - w / 2 + 10, y + 16), (x - w / 2 + 22, y + 16), (x - w / 2 + 22, y + 120), (x - w / 2 + 10, y + 120)]); _P(m, [(x + w / 2 - 22, y + 16), (x + w / 2 - 10, y + 16), (x + w / 2 - 10, y + 120), (x + w / 2 - 22, y + 120)])
    paint(img, m, WOOD, a); outline(img, m, a, 0.8, 1.0)
    pp = mk(); _P(pp, [(x - 30, y - 2), (x + 34, y - 4), (x + 36, y + 2), (x - 28, y + 3)]); paint(img, pp, WHITE, a)
    if candle:
        cx = x + w / 2 - 34; c = mk(); _P(c, [(cx - 6, y), (cx + 6, y), (cx + 6, y - 34), (cx - 6, y - 34)]); paint(img, c, BONE, a)
        fl = mk(); fk = 1 + 0.12 * math.sin(t * 13) * math.sin(t * 5.1); _E(fl, cx, y - 44, 4.5, 9 * fk); paint(img, fl, C3(1.0, 0.82, 0.36), a)
        glow_roi(img, cx, y - 44, 150, C3(1.0, 0.70, 0.32), 0.40 * a * fk, 2.0)


# ------------------------------------------------------------------ La Mancha: molino y caballero
def windmill(img, x, y, s, t, a=1.0, col=None, spin=0.6):
    col = WHITE if col is None else col
    m = mk(); _P(m, [(x - 26 * s, y), (x + 26 * s, y), (x + 20 * s, y - 92 * s), (x - 20 * s, y - 92 * s)]); paint(img, m, col, a); outline(img, m, a, 0.8, 1.0)
    r = mk(); _P(r, [(x - 25 * s, y - 90 * s), (x + 25 * s, y - 90 * s), (x, y - 122 * s)]); paint(img, r, C3(0.30, 0.22, 0.18) if col is WHITE else col, a)
    d = mk(); _P(d, [(x - 7 * s, y), (x + 7 * s, y), (x + 7 * s, y - 22 * s), (x - 7 * s, y - 22 * s)]); paint(img, d, DARK, a)
    hub = (x, y - 100 * s); sl = mk()
    for k in range(4):
        th = t * spin + k * math.pi / 2; ca, sa = math.cos(th), math.sin(th)
        def R(px, py): return (hub[0] + px * ca - py * sa, hub[1] + px * sa + py * ca)
        _L(sl, [R(0, 0), R(96 * s, 0)], max(1, 3 * s))
        for j in range(5):
            _L(sl, [R((22 + 17 * j) * s, 0), R((22 + 17 * j) * s, 14 * s)], max(1, 1.5 * s))
        _L(sl, [R(22 * s, 14 * s), R(96 * s, 14 * s)], max(1, 1.5 * s))
    paint(img, sl, WOOD * 0.7 if col is WHITE else col, a)
    hb = mk(); _C(hb, hub[0], hub[1], 5 * s); paint(img, hb, DARK, a)


def knight(img, x, y, s, t, a=1.0, col=None):
    """caballero flaco a caballo con lanza (silueta), galopando hacia la derecha."""
    col = C3(0.16, 0.12, 0.12) if col is None else col
    m = mk(); g = t * 2 * math.pi * 1.6; bob = 3 * s * math.sin(g * 2)
    _E(m, x, y - 60 * s + bob, 46 * s, 17 * s)                              # cuerpo del caballo
    _L(m, [(x + 36 * s, y - 66 * s + bob), (x + 58 * s, y - 104 * s + bob)], max(2, 13 * s))   # cuello
    _P(m, [(x + 52 * s, y - 110 * s + bob), (x + 64 * s, y - 112 * s + bob), (x + 84 * s, y - 92 * s + bob), (x + 76 * s, y - 86 * s + bob), (x + 54 * s, y - 96 * s + bob)])  # cabeza
    _L(m, [(x - 44 * s, y - 64 * s + bob), (x - 62 * s, y - 40 * s + bob)], max(2, 5 * s))    # cola
    for k, (lx, ph0) in enumerate(((-30, 0.0), (-20, 2.2), (26, 3.4), (36, 1.0))):
        ang = 0.55 * math.sin(g + ph0); kx = x + lx * s + 12 * s * math.sin(ang); ky = y - 30 * s + bob
        fx = kx + 16 * s * math.sin(ang + 0.4); fy = y - 2 * s * max(0, math.sin(g + ph0))
        _L(m, [(x + lx * s, y - 52 * s + bob), (kx, ky), (fx, fy)], max(2, 5 * s))
    # jinete flaco
    rx, ry = x - 4 * s, y - 76 * s + bob
    _L(m, [(rx, ry), (rx + 4 * s, ry - 46 * s)], max(2, 8 * s))
    _C(m, rx + 6 * s, ry - 56 * s, 8 * s)
    _P(m, [(rx - 2 * s, ry - 62 * s), (rx + 14 * s, ry - 62 * s), (rx + 6 * s, ry - 74 * s)])          # yelmo/bacía
    _L(m, [(rx, ry), (rx + 12 * s, ry + 26 * s), (rx + 6 * s, ry + 46 * s)], max(2, 5 * s))           # pierna
    _L(m, [(rx + 2 * s, ry - 36 * s), (rx + 20 * s, ry - 20 * s)], max(2, 4 * s))
    _L(m, [(rx - 30 * s, ry - 4 * s), (rx + 130 * s, ry - 44 * s)], max(2, 3.5 * s))                 # lanza
    _E(m, rx - 8 * s, ry - 26 * s, 12 * s, 14 * s)                                                    # escudo
    paint(img, m, col, a)
