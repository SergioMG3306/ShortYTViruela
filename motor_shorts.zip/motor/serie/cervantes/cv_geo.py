"""Mapas del Mediterráneo (estilo archivo) con proyección equirectangular fija, para que zoom y paneo sean afines exactos."""
import sys, math
sys.path.insert(0, '/home/claude/serie/cervantes')
from cv_lib import *
from cv_lib import _f
from cv_geomap import render_map, dashed, along, solid, pin, pulse, _MC

KLAT = math.cos(math.radians(38.0))
WIN = (-30.0, 60.0, 10.0, 65.0)
MED = ['Spain', 'Portugal', 'France', 'Italy', 'Greece', 'Turkey', 'Albania', 'Algeria', 'Tunisia', 'Libya', 'Morocco', 'Egypt', 'Malta', 'Cyprus',
       'Croatia', 'Montenegro', 'Bosnia and Herz.', 'Serbia', 'Bulgaria', 'Macedonia', 'Slovenia', 'Switzerland', 'Austria', 'Germany', 'Hungary',
       'Romania', 'Kosovo', 'Syria', 'Lebanon', 'Israel', 'Jordan', 'Andorra', 'Monaco', 'San Marino', 'Vatican', 'Slovakia', 'Czechia', 'Ukraine',
       'Moldova', 'Belgium', 'Luxembourg', 'Netherlands', 'United Kingdom', 'Poland', 'Georgia', 'Iraq', 'Saudi Arabia', 'Palestine', 'W. Sahara',
       'Mauritania', 'Mali', 'Niger', 'Chad', 'Sudan', 'Russia', 'Belarus', 'Armenia', 'Azerbaijan', 'Iran', 'Ireland', 'Denmark', 'Liechtenstein']

# lugares (lon, lat)
LEPANTO = (21.15, 38.27); NAUPAKTOS = (21.83, 38.39); MESINA = (15.55, 38.19); NAPOLES = (14.27, 40.85)
CAPTURA = (3.30, 42.05); BARCELONA = (2.17, 41.39); ARGEL = (3.06, 36.77); ORAN = (-0.63, 35.70)
CONSTANT = (28.98, 41.01); DENIA = (0.11, 38.84); SEVILLA = (-5.98, 37.39); MADRID = (-3.70, 40.42)


class EQ:
    """proyección equirectangular: x = ox + R·Δλ·cos38°, y = oy − R·Δφ (radianes)."""
    def __init__(s, lon0, lat0, R, ox=270.0, oy=330.0):
        s.lon0, s.lat0, s.R, s.ox, s.oy = lon0, lat0, R, ox, oy
    def xy(s, lon, lat):
        lon = np.asarray(lon, np.float64); lat = np.asarray(lat, np.float64)
        return s.ox + s.R * np.radians(lon - s.lon0) * KLAT, s.oy - s.R * np.radians(lat - s.lat0)
    def pt(s, lon, lat):
        x, y = s.xy(lon, lat); return float(x), float(y)


def level(center, R):
    key = ('med', center, int(R))
    P = EQ(center[0], center[1], R)
    if key in _MC: return _MC[key], P
    img = render_map(key, P, ['LAND'], WIN, (), contour=0.5, grat=0.8, step=(5 if R < 3000 else 1), borders=0.0)
    return img, P


def view(center, R, levels, cx=270.0, cy=330.0):
    """mapa a escala R (continua) centrado en `center` (en ox,oy); mezcla los niveles cacheados (todos con el mismo centro)."""
    Rl = max(levels[0], min(levels[-1], R)); k = 0
    while k < len(levels) - 2 and Rl >= levels[k + 1]: k += 1
    La, Lb = levels[k], levels[k + 1]
    ba, _ = level(center, La); img = Cam(Rl / La, 0, 0, cx, cy).apply(ba)
    f = ease((math.log(Rl) - math.log(La * 1.55)) / (math.log(Lb) - math.log(La * 1.55))) if Rl > La * 1.55 else 0.0
    if f > 0:
        bb, _ = level(center, Lb); img = img * (1 - f) + Cam(Rl / Lb, 0, 0, cx, cy).apply(bb) * f
    return img, EQ(center[0], center[1], Rl)


def route(P, pts):
    x, y = P.xy(np.array([p[0] for p in pts]), np.array([p[1] for p in pts])); return np.stack([x, y], 1)
