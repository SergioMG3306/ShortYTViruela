"""Mapas de archivo (estilo Palomares) con datos reales de Natural Earth (world-atlas 50 m)."""
import json, math, sys
import numpy as np, cv2
sys.path.insert(0, '/home/claude/serie/cervantes')
from cv_lib import *
from cv_lib import _f

_G = json.load(open('/home/claude/serie/plaga/geo/countries-50m.geojson'))
CTRY = {}      # nombre -> [(anillo_exterior(np.array lon,lat), [huecos])]
for _ft in _G['features']:
    g = _ft['geometry']
    if g is None: continue
    polys = g['coordinates'] if g['type'] == 'MultiPolygon' else [g['coordinates']]
    CTRY[_ft['properties']['name']] = [(np.array(p[0], np.float64), [np.array(h, np.float64) for h in p[1:]]) for p in polys]

USSR = ['Russia', 'Ukraine', 'Belarus', 'Lithuania', 'Latvia', 'Estonia', 'Moldova', 'Georgia', 'Armenia', 'Azerbaijan',
        'Kazakhstan', 'Uzbekistan', 'Turkmenistan', 'Kyrgyzstan', 'Tajikistan']
USA = ['United States of America']
NATO_EU = ['Germany', 'United Kingdom', 'Italy', 'Belgium', 'Netherlands', 'France', 'Spain', 'Norway', 'Denmark', 'Greece', 'Turkey', 'Portugal', 'Luxembourg']


class GP:
    """Proyección acimutal de áreas iguales de Lambert."""
    def __init__(s, lon0, lat0, R, ox, oy, rot=0.0):
        s.lon0, s.lat0, s.R, s.ox, s.oy, s.rot = lon0, lat0, R, ox, oy, rot
    def xy(s, lon, lat):
        lon = np.asarray(lon, np.float64); lat = np.asarray(lat, np.float64)
        lam = np.radians(lon - s.lon0); phi = np.radians(lat); p0 = math.radians(s.lat0)
        den = np.maximum(1 + math.sin(p0) * np.sin(phi) + math.cos(p0) * np.cos(phi) * np.cos(lam), 1e-4)
        k = np.sqrt(2 / den)
        x = k * np.cos(phi) * np.sin(lam); y = k * (math.cos(p0) * np.sin(phi) - math.sin(p0) * np.cos(phi) * np.cos(lam))
        c, sn = math.cos(math.radians(s.rot)), math.sin(math.radians(s.rot))
        xr = x * c - y * sn; yr = x * sn + y * c
        return s.ox + s.R * xr, s.oy - s.R * yr
    def pt(s, lon, lat):
        x, y = s.xy(lon, lat); return float(x), float(y)
    def with_(s, **kw):
        d = dict(lon0=s.lon0, lat0=s.lat0, R=s.R, ox=s.ox, oy=s.oy, rot=s.rot); d.update(kw); return GP(**d)


def gc(lon1, lat1, lon2, lat2, n=80):
    """círculo máximo (n puntos) como arrays lon, lat."""
    a = np.radians([lon1, lat1, lon2, lat2]); l1, p1, l2, p2 = a
    v1 = np.array([math.cos(p1) * math.cos(l1), math.cos(p1) * math.sin(l1), math.sin(p1)])
    v2 = np.array([math.cos(p2) * math.cos(l2), math.cos(p2) * math.sin(l2), math.sin(p2)])
    om = math.acos(np.clip(v1 @ v2, -1, 1)); s = np.linspace(0, 1, n)
    P = (np.sin((1 - s) * om)[:, None] * v1 + np.sin(s * om)[:, None] * v2) / max(math.sin(om), 1e-9)
    return np.degrees(np.arctan2(P[:, 1], P[:, 0])), np.degrees(np.arcsin(np.clip(P[:, 2], -1, 1)))


def _rings(names, win):
    """anillos exteriores de los países `names` cuyo cuadro cae dentro de `win`=(lon0,lon1,lat0,lat1)."""
    out = []
    for nm in names:
        for ring, holes in CTRY.get(nm, []):
            lo0, lo1 = ring[:, 0].min(), ring[:, 0].max(); la0, la1 = ring[:, 1].min(), ring[:, 1].max()
            if win and (lo1 < win[0] or lo0 > win[1] or la1 < win[2] or la0 > win[3]): continue
            out.append(ring)
    return out


def _mask(P, names, win, blur=0.7):
    m = np.zeros((H, W), np.uint8)
    for ring in _rings(names, win):
        x, y = P.xy(ring[:, 0], ring[:, 1])
        pts = np.round(np.stack([x, y], 1) * 16).astype(np.int64)
        if np.abs(pts).max() > 2 ** 30: continue
        cv2.fillPoly(m, [pts.astype(np.int32)], 255, cv2.LINE_AA, shift=4)
    m = m.astype(F32) / 255
    return cv2.GaussianBlur(m, (0, 0), blur) if blur else m


def _coast(P, names, win):
    m = np.zeros((H, W), np.uint8)
    for ring in _rings(names, win):
        x, y = P.xy(ring[:, 0], ring[:, 1])
        pts = np.round(np.stack([x, y], 1) * 16).astype(np.int64)
        if np.abs(pts).max() > 2 ** 30: continue
        cv2.polylines(m, [pts.astype(np.int32)], True, 255, 1, cv2.LINE_AA, shift=4)
    return cv2.GaussianBlur(m.astype(F32) / 255, (0, 0), 0.5)


def graticule(P, step=15, lats=(), a=0.10, lat_rng=(-60, 88)):
    gm = np.zeros((H, W), np.uint8)
    for lo in range(-180, 181, step):
        la = np.linspace(lat_rng[0], lat_rng[1], 60); x, y = P.xy(np.full(60, lo), la)
        pts = np.round(np.stack([x, y], 1) * 8).astype(np.int64)
        if np.abs(pts).max() < 2 ** 30: cv2.polylines(gm, [pts.astype(np.int32)], False, 255, 1, cv2.LINE_AA, shift=3)
    for la in range(-60, 90, step):
        lo = np.linspace(-180, 180, 160); x, y = P.xy(lo, np.full(160, la))
        pts = np.round(np.stack([x, y], 1) * 8).astype(np.int64)
        if np.abs(pts).max() < 2 ** 30: cv2.polylines(gm, [pts.astype(np.int32)], False, 255, 1, cv2.LINE_AA, shift=3)
    return gm.astype(F32) / 255 * a


_MC = {}
def render_map(key, P, names, win=None, highlights=(), contour=0.6, grat=1.0, step=15, sea=None, land=None, borders=0.0, tint=1.0):
    """imagen base float32 HxWx3 (cacheada por `key`). highlights = [(nombres, color, alpha, hatch)]"""
    if key in _MC: return _MC[key]
    lm = _mask(P, names, win)
    dist = cv2.distanceTransform((lm < 0.5).astype(np.uint8), cv2.DIST_L2, 3)
    rip = np.clip(1 - np.abs(np.sin(dist * 0.42)) / 0.22, 0, 1) * np.exp(-dist / 55.0)
    sea_img = np.empty((H, W, 3), F32); sea_img[:] = SEA_C if sea is None else sea; sea_img *= (1 - 0.16 * rip[..., None]); sea_img *= (0.94 + 0.08 * (_f[..., None] - 0.5))
    shadow(sea_img, lm, 0.22, (3, 4), 4.0)
    line = np.clip(1 - np.abs(np.sin(CONT * 22 * math.pi)) / 0.10, 0, 1) * contour
    lc = PAPER * (1 - 0.30 * line[..., None] * C3(0.35, 0.55, 0.9)[None, None, :]); lc = lc * C3(1.01, 1.0, 0.97)
    if land is not None: lc = lc * land
    img = sea_img * (1 - lm[..., None]) + lc * lm[..., None]
    for (nm, col, al, hatch) in highlights:
        hm = _mask(P, nm, win, 0.6) * lm
        over(img, hm, col, al * tint)
        if hatch: over(img, (((XX + YY) % 9) < 2.3).astype(F32) * hm, col, 0.30 * tint)
    over(img, _coast(P, names, win), INK, 0.60)
    if borders > 0:
        for nm in names:
            over(img, _coast(P, [nm], win) * lm, INK, 0.30 * borders)
    if grat > 0: over(img, graticule(P, step) * 1.0, INK, grat)
    _MC[key] = img.astype(F32); return _MC[key]


# ---------- utilidades de dibujo sobre mapa
def dashed(img, pts, col, a=1.0, th=2, dash=9, gap=7, phase=0.0, upto=1.0):
    """polilínea discontinua (pts en px), dibujada hasta la fracción `upto` de su longitud."""
    pts = np.asarray(pts, np.float64); seg = np.hypot(*np.diff(pts, axis=0).T); L = np.concatenate([[0], np.cumsum(seg)]); tot = L[-1] * upto
    m = np.zeros((H, W), np.uint8); d = -phase % (dash + gap)
    while d < tot:
        a0, a1 = max(d, 0), min(d + dash, tot)
        if a1 > a0:
            i0 = np.interp([a0, a1], L, pts[:, 0]); j0 = np.interp([a0, a1], L, pts[:, 1])
            cv2.line(m, (int(i0[0] * 16), int(j0[0] * 16)), (int(i0[1] * 16), int(j0[1] * 16)), 255, th, cv2.LINE_AA, shift=4)
        d += dash + gap
    over(img, cv2.GaussianBlur(m.astype(F32) / 255, (0, 0), 0.5), col, a)

def along(pts, f):
    """punto y tangente a la fracción f de la polilínea."""
    pts = np.asarray(pts, np.float64); seg = np.hypot(*np.diff(pts, axis=0).T); L = np.concatenate([[0], np.cumsum(seg)])
    d = L[-1] * min(max(f, 0), 1); x = np.interp(d, L, pts[:, 0]); y = np.interp(d, L, pts[:, 1]); i = min(np.searchsorted(L, d), len(pts) - 1); i = max(i, 1)
    tx, ty = pts[i] - pts[i - 1]; n = math.hypot(tx, ty) + 1e-9
    return float(x), float(y), tx / n, ty / n

def solid(img, pts, col, a=1.0, th=2, upto=1.0):
    pts = np.asarray(pts, np.float64); seg = np.hypot(*np.diff(pts, axis=0).T); L = np.concatenate([[0], np.cumsum(seg)]); tot = L[-1] * upto
    k = max(2, int(np.searchsorted(L, tot))); P2 = pts[:k + 1].copy()
    if k < len(pts) and tot > 0:
        x = np.interp(tot, L, pts[:, 0]); y = np.interp(tot, L, pts[:, 1]); P2 = np.vstack([pts[:max(1, np.searchsorted(L, tot))], [[x, y]]])
    m = np.zeros((H, W), np.uint8)
    if len(P2) > 1: cv2.polylines(m, [np.round(P2 * 16).astype(np.int32)], False, 255, th, cv2.LINE_AA, shift=4)
    over(img, cv2.GaussianBlur(m.astype(F32) / 255, (0, 0), 0.5), col, a)

def pin(img, x, y, col=RED, a=1.0, r=7):
    over(img, mcirc([(x, y, r + 2.5)], 0.6), CREAM, a); over(img, mcirc([(x, y, r)], 0.6), col, a)

def pulse(img, x, y, t, col=RED, a=1.0, r0=8, r1=44, per=1.1, th=2, n=2):
    for j in range(n):
        ph = ((t / per) + j / n) % 1.0
        m = np.zeros((H, W), np.uint8); cv2.circle(m, (int(round(x * 16)), int(round(y * 16))), int(round((r0 + (r1 - r0) * ph) * 16)), 255, th, cv2.LINE_AA, shift=4)
        over(img, m.astype(F32) / 255, col, a * (1 - ph) * 0.9)

def star_blip(img, x, y, col, a=1.0, r=6):
    over(img, mcirc([(x, y, r)], 0.6), col, a); glow_roi(img, x, y, r * 4, col, 0.5 * a, 2.0)


# tierra sin fronteras modernas (para mapas de época)
_LG = json.load(open('/home/claude/serie/plaga/geo/land-50m.geojson'))
CTRY['LAND'] = []
for _ft in _LG['features']:
    g = _ft['geometry']; polys = g['coordinates'] if g['type'] == 'MultiPolygon' else [g['coordinates']]
    CTRY['LAND'] += [(np.array(p[0], np.float64), [np.array(h, np.float64) for h in p[1:]]) for p in polys]
