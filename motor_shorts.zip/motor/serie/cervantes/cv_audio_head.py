import sys, json
sys.path.insert(0, '/home/claude/serie/cervantes')
from cv_audio_lib import *
import cv_audio_lib as AL
EV = json.load(open('/home/claude/serie/cervantes/events.json'))
def _e(x): x = np.clip(x, 0, 1); return x * x * (3 - 2 * x)

# ---------- piezas nuevas
def riser(t0, t1, g=0.2, f0=60, f1=420, noise=0.35):
    n = int((t1 - t0) * SR); t = tt(n); x = np.linspace(0, 1, n) ** 2.2; f = f0 + (f1 - f0) * x; ph = 2 * np.pi * np.cumsum(f) / SR
    s = (np.sin(ph) + 0.5 * np.sin(1.5 * ph + 1)) * 0.6 + noise * bp(nz(n), 300, 5000) * x
    add((s * x ** 0.6 * g).astype(np.float32), t0, 0.0, 1.0, 0.25, True)
def reverse_hit(t_hit, dur=0.9, g=0.3):
    n = int(dur * SR); t = tt(n); s = bp(nz(n), 400, 7000) * (np.linspace(0, 1, n) ** 2.5); add((s * g).astype(np.float32), t_hit - dur, 0.0, 1.0, 0.3)
def glitch(t0, t1, g=0.3, dens=60):
    n = int(dens * (t1 - t0))
    for j in range(n):
        tj = t0 + (t1 - t0) * (j / max(n, 1)) ** 0.8 + rng.rand() * 0.01
        add(click(600 + rng.rand() * 5000, 0.004 + 0.01 * rng.rand(), g * (0.5 + 0.5 * rng.rand())), tj, rng.rand() * 1.6 - 0.8)
def sonar(t0, f=1050, g=0.3, dec=2.4, pan=0.0):
    n = int(dec * SR); t = tt(n); s = np.sin(2 * np.pi * f * t) * np.exp(-t * 3.0) * np.minimum(1, t / 0.01) + 0.35 * np.sin(2 * np.pi * f * 1.5 * t) * np.exp(-t * 5.5)
    add((s * g).astype(np.float32), t0, pan, 1.0, 0.7)
def chirp(t0, f0=1200, f1=3200, dur=0.07, g=0.2, pan=0.0):
    n = int(dur * SR); t = tt(n); f = f0 + (f1 - f0) * t / dur; s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.minimum(1, t / 0.004) * np.minimum(1, (dur - t) / 0.01)
    add((s * g).astype(np.float32), t0, pan, 1.0, 0.2)
def step_snd(g=1.0, f=85):
    n = int(0.17 * SR); t = tt(n); s = np.sin(2 * np.pi * np.cumsum(f * (1 + 0.6 * np.exp(-t * 30))) / SR) * np.exp(-t * 22) + 0.45 * bp(nz(n), 300, 2400) * np.exp(-t * 55) + 0.2 * lp(nz(n), 600) * np.exp(-t * 25)
    return (s * g).astype(np.float32)
def stomps(t0, t1, hz, g_fn, v_fn, spread=1.4):
    t = t0
    while t < t1:
        g = g_fn(t); nv = int(max(1, round(v_fn(t))))
        for v in range(nv): add(step_snd(g * (0.55 + 0.45 * rng.rand()), 65 + rng.rand() * 45), t + rng.randn() * 0.014, (rng.rand() - 0.5) * spread, 1.0, 0.10)
        t += 1.0 / hz
def tom(t0, f=95, g=0.5, pan=0.0):
    n = int(0.45 * SR); t = tt(n); s = np.sin(2 * np.pi * np.cumsum(f * (1 + 0.8 * np.exp(-t * 20))) / SR) * np.exp(-t * 9) + 0.3 * bp(nz(n), 400, 2500) * np.exp(-t * 40)
    add((s * g).astype(np.float32), t0, pan, 1.0, 0.3)
def pluck(t0, f, g=0.18, dur=0.5, pan=0.0):
    n = int(dur * SR); t = tt(n); s = (2 * np.abs(2 * ((f * t) % 1) - 1) - 1) * 0.6 + 0.3 * np.sin(2 * np.pi * f * 2 * t); s = lp(s, 2200) * np.exp(-t * 7) * np.minimum(1, t / 0.003)
    add((s * g).astype(np.float32), t0, pan, 1.0, 0.35)
def drip(t0, g=0.14):
    n = int(0.14 * SR); t = tt(n); f = rng.uniform(1100, 2200) * np.exp(-t * rng.uniform(6, 14)); s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 28)
    add((s * g).astype(np.float32), t0, rng.rand() * 1.6 - 0.8, 1.0, 0.3)
def clop(t0, g=0.22, pan=0.0):
    n = int(0.12 * SR); t = tt(n); s = (np.sin(2 * np.pi * 720 * t) * 0.5 + bp(nz(n), 500, 3500) * 0.8) * np.exp(-t * 50)
    add((s * g).astype(np.float32), t0, pan, 1.0, 0.18)
def bird(t0, g=0.06):
    k = rng.randint(2, 5); t_ = t0
    for j in range(k): chirp(t_, rng.uniform(2800, 4200), rng.uniform(3200, 5200), rng.uniform(0.05, 0.10), g, rng.rand() * 1.4 - 0.7); t_ += rng.uniform(0.08, 0.16)

# ---------- máquina de escribir, fotos y sellos
for (text, t0, cps) in EV['tn']:
    typing(t0, len(text), cps, 0.42 if cps >= 14 else 0.38)
for (name, t0, t1) in EV['ph']:
    pan = {'portada.jpg': -0.2, 'retrato.png': 0.25}.get(name, 0.0)
    shutter(t0, 0.7, pan); n_ = int(0.17 * SR); add(bp(nz(n_), 500, 6000) * (np.linspace(0, 1, n_) ** 2) * 0.22, t0, pan, 1.0, 0.1)
    add(thud(0.75, 0.5), t0 + 0.16, pan, 1.0, 0.2); add(bp(nz(int(0.07 * SR)), 700, 6000) * np.exp(-tt(int(0.07 * SR)) * 45) * 0.6, t0 + 0.16, pan, 1.0)
for (text, t0) in EV['sp']:
    stampthud(t0 + 0.14, 1.0)
    if 'OCULTA' in text or 'MANCO' in text: bell(t0 + 0.16, 196, 0.14); bell(t0 + 0.16, 294, 0.06)

