"""Ilustraciones propias (estilo grabado coloreado) para la plaga del baile: bailarines animados, calle, iconos."""
import sys, math
sys.path.insert(0, '/home/claude/serie/cervantes')
from cv_lib import *
from cv_lib import _f, _d
import cv_lib as L

WOOD = C3(0.36, 0.24, 0.14); OCHRE = C3(0.80, 0.62, 0.30); CLAY = C3(0.72, 0.30, 0.22); SAGE = C3(0.50, 0.58, 0.38)
NAVY = C3(0.24, 0.34, 0.50); BONE = C3(0.94, 0.90, 0.80); SKIN = C3(0.86, 0.68, 0.54); STONE = C3(0.62, 0.57, 0.50)
SANDSTONE = C3(0.66, 0.40, 0.33); GOLD = C3(0.92, 0.74, 0.30)
GCOL = [CLAY, OCHRE, NAVY, SAGE, C3(0.50, 0.30, 0.46), C3(0.62, 0.50, 0.34)]


# ------------------------------------------------------------------ primitivas de máscara (uint8, supersampled)
def _L(m, pts, th):
    cv2.polylines(m, [np.round(np.asarray(pts, np.float64) * 16).astype(np.int32)], False, 255, max(1, int(round(th))), cv2.LINE_AA, shift=4)
def _P(m, pts):
    cv2.fillPoly(m, [np.round(np.asarray(pts, np.float64) * 16).astype(np.int32)], 255, cv2.LINE_AA, shift=4)
def _C(m, x, y, r):
    cv2.circle(m, (int(round(x * 16)), int(round(y * 16))), int(round(max(r, 0.3) * 16)), 255, -1, cv2.LINE_AA, shift=4)
def _E(m, x, y, rx, ry, ang=0.0, a0=0, a1=360):
    cv2.ellipse(m, (int(round(x * 16)), int(round(y * 16))), (int(round(max(rx, 0.3) * 16)), int(round(max(ry, 0.3) * 16))), ang, a0, a1, 255, -1, cv2.LINE_AA, shift=4)
def _fm(m, bl=0.5):
    f = m.astype(F32) / 255
    return cv2.GaussianBlur(f, (0, 0), bl) if bl else f
def over_roi(img, m, col, a=1.0, box=None):
    """como over() pero limitado a la caja (x0,y0,x1,y1) para ir más rápido."""
    if box is None: return over(img, m, col, a)
    x0, y0, x1, y1 = [int(v) for v in box]; x0 = max(0, x0); y0 = max(0, y0); x1 = min(W, x1); y1 = min(H, y1)
    if x0 >= x1 or y0 >= y1: return
    c = np.asarray(col, F32); mm = (m[y0:y1, x0:x1] * a)[..., None]
    img[y0:y1, x0:x1] = img[y0:y1, x0:x1] * (1 - mm) + c[None, None, :] * mm


# ------------------------------------------------------------------ bailarín
class Dn:
    __slots__ = ('x', 'y', 'h', 'ph', 'kind', 't0', 'w', 'tag')
    def __init__(s, x, y, h, ph=0.0, kind=0, t0=0.0, w=1.0, tag=None): s.x, s.y, s.h, s.ph, s.kind, s.t0, s.w, s.tag = x, y, h, ph, kind, t0, w, tag

def _draw_dancer(M, d, t, hs_=1.0):
    """dibuja un bailarín en el diccionario de máscaras M. kind: 0 mujer arcilla, 1 hombre ocre, 2 hombre azul, 3 mujer verde, 4 mujer morada, 5 niño."""
    idle = d.tag in ('idle', 'beg')
    ph = d.ph + (0.0 if idle else 2 * math.pi * 1.45 * d.w * (t - d.t0))
    h = d.h * hs_; u = h / 10.0; x, y = d.x, d.y
    s1, s2, s3 = math.sin(ph), math.sin(ph + 1.7), math.cos(ph)
    if idle: s1 = 0.0; s3 = 1.0; ph = 0.0
    woman = d.kind in (0, 3, 4); child = d.kind == 5
    pel = (x + 0.25 * u * s1, y - 4.7 * u - 0.28 * u * abs(s3))
    neck = (pel[0] + 0.7 * u * math.sin(ph + 0.8), pel[1] - 3.1 * u)
    head = (neck[0] + 0.3 * u * math.sin(ph + 0.8), neck[1] - 1.0 * u)
    sh = (neck[0], neck[1] + 0.45 * u)
    # piernas
    feet = []
    for k, sg in enumerate((1, -1)):
        sw = s1 * sg; lift = max(0.0, math.sin(ph + 1.5 + (math.pi if k else 0))) * 1.0 * u
        f = (x + 1.35 * u * sw, y - lift); kn = ((pel[0] + f[0]) / 2 + 0.55 * u * sg * (0.5 + 0.5 * abs(s3)), (pel[1] + f[1]) / 2 - 0.1 * u)
        feet.append((f, kn))
    # brazos (manos al aire, al ritmo)
    arms = []
    for k, sg in enumerate((1, -1)):
        pz = ph + (0.0 if k == 0 else 2.6)
        hand = (sh[0] + sg * (2.1 * u + 0.7 * u * math.sin(pz + 1.0)), sh[1] - 1.1 * u + 1.7 * u * math.sin(pz + 2.0))
        el = (sh[0] + sg * 1.5 * u, (sh[1] + hand[1]) / 2 + 0.55 * u)
        if d.tag == 'idle': hand = (sh[0] + sg * 1.7 * u, sh[1] + 3.1 * u); el = (sh[0] + sg * 1.9 * u, sh[1] + 1.6 * u)
        if d.tag == 'beg': hand = (sh[0] + sg * 1.5 * u, sh[1] - 2.4 * u + 0.25 * u * math.sin(t * 6 + k)); el = (sh[0] + sg * 2.0 * u, sh[1] - 0.6 * u)
        arms.append((sh, el, hand))
    ink = M['ink']; cm = M[d.kind]; skin = M['skin']; bone = M['bone']
    lw = max(1.0, 0.55 * u); tw_ = max(2.0, 1.55 * u)
    # tinta: contorno
    for (f, kn) in feet: _L(ink, [pel, kn, f], max(2.0, 0.95 * u)); _E(ink, f[0] + 0.25 * u, f[1], 0.75 * u, 0.33 * u)
    _L(ink, [neck, pel], tw_ + 1.6)
    for (a, e, hd) in arms: _L(ink, [a, e, hd], lw + 1.6)
    _C(ink, head[0], head[1], 0.92 * u + 0.6)
    if woman:
        _P(ink, [(pel[0] - 1.05 * u, pel[1] - 0.2 * u), (pel[0] + 1.05 * u, pel[1] - 0.2 * u), (pel[0] + 2.35 * u + 0.8 * u * s1, y - 0.55 * u), (pel[0] - 2.35 * u + 0.8 * u * math.sin(ph + 1.3), y - 0.45 * u)])
        _E(ink, head[0], head[1] - 0.15 * u, 1.05 * u, 0.9 * u, 0, 180, 360)
    else:
        _P(ink, [(pel[0] - 1.05 * u, pel[1] - 0.4 * u), (pel[0] + 1.05 * u, pel[1] - 0.4 * u), (pel[0] + 1.4 * u, pel[1] + 1.4 * u), (pel[0] - 1.4 * u, pel[1] + 1.4 * u)])
        if not child: _P(ink, [(head[0] - 1.35 * u, head[1] - 0.45 * u), (head[0] + 1.35 * u, head[1] - 0.45 * u), (head[0] + 0.7 * u, head[1] - 1.55 * u), (head[0] - 0.7 * u, head[1] - 1.55 * u)])
    # color
    _L(cm, [neck, pel], tw_)
    if woman:
        _P(cm, [(pel[0] - 0.9 * u, pel[1] - 0.2 * u), (pel[0] + 0.9 * u, pel[1] - 0.2 * u), (pel[0] + 2.15 * u + 0.8 * u * s1, y - 0.65 * u), (pel[0] - 2.15 * u + 0.8 * u * math.sin(ph + 1.3), y - 0.55 * u)])
        _E(bone, head[0], head[1] - 0.2 * u, 0.98 * u, 0.82 * u, 0, 180, 360)
    else:
        _P(cm, [(pel[0] - 0.9 * u, pel[1] - 0.4 * u), (pel[0] + 0.9 * u, pel[1] - 0.4 * u), (pel[0] + 1.25 * u, pel[1] + 1.3 * u), (pel[0] - 1.25 * u, pel[1] + 1.3 * u)])
    for (a, e, hd) in arms: _L(cm, [a, e], lw)
    for (a, e, hd) in arms: _C(skin, hd[0], hd[1], 0.42 * u + 0.3)
    _C(skin, head[0], head[1] + 0.12 * u, 0.78 * u)
    if not woman and not child:
        pass
    return (x - 3.6 * u, y - 11.4 * u, x + 3.6 * u, y + 1.0 * u)

def crowd(img, ds, t, hs_=None, bands=3, haze=0.0, shadow_k=0.30, alpha=1.0, tint=None):
    """pinta una lista de Dn (ordenados por y) en `bands` pasadas para que los cercanos tapen a los lejanos."""
    vis = [d for d in ds if t >= d.t0]
    if not vis: return
    vis.sort(key=lambda d: d.y)
    n = len(vis); per = max(1, int(math.ceil(n / bands)))
    for b0 in range(0, n, per):
        grp = vis[b0:b0 + per]
        M = {k: np.zeros((H, W), np.uint8) for k in ('ink', 'skin', 'bone', 0, 1, 2, 3, 4, 5)}
        bx0 = bx1 = by0 = by1 = None
        sh_m = np.zeros((H, W), np.uint8)
        for d in grp:
            k = ease((t - d.t0) / 0.35)
            if k <= 0.01: continue
            bb = _draw_dancer(M, d, t, k * (1.0 if hs_ is None else hs_))
            _E(sh_m, d.x, d.y + 0.2 * d.h * 0.1, d.h * 0.28 * k, d.h * 0.055 * k)
            bx0 = bb[0] if bx0 is None else min(bx0, bb[0]); by0 = bb[1] if by0 is None else min(by0, bb[1]); bx1 = bb[2] if bx1 is None else max(bx1, bb[2]); by1 = bb[3] if by1 is None else max(by1, bb[3])
        if bx0 is None: continue
        box = (bx0 - 8, by0 - 8, bx1 + 8, by1 + 12)
        x0, y0, x1, y1 = [int(v) for v in box]; x0 = max(0, x0); y0 = max(0, y0); x1 = min(W, x1); y1 = min(H, y1)
        if x0 >= x1 or y0 >= y1: continue
        sl = (slice(y0, y1), slice(x0, x1))
        shm = cv2.GaussianBlur(sh_m[sl].astype(F32) / 255, (0, 0), 2.2)
        img[sl] *= (1 - shadow_k * shm * alpha)[..., None]
        fin = lambda key: cv2.GaussianBlur(M[key][sl].astype(F32) / 255, (0, 0), 0.45)
        ink_col = INK if tint is None else INK * tint
        ci = fin('ink'); img[sl] = img[sl] * (1 - (0.93 * alpha) * ci[..., None]) + ink_col[None, None, :] * (0.93 * alpha) * ci[..., None]
        for key in (0, 1, 2, 3, 4, 5):
            if not M[key][sl].any(): continue
            cc = fin(key); col = GCOL[key] if tint is None else GCOL[key] * tint
            img[sl] = img[sl] * (1 - alpha * cc[..., None]) + col[None, None, :] * alpha * cc[..., None]
        for key, col in (('bone', BONE), ('skin', SKIN)):
            if not M[key][sl].any(): continue
            cc = fin(key); col = col if tint is None else col * tint
            img[sl] = img[sl] * (1 - alpha * cc[..., None]) + col[None, None, :] * alpha * cc[..., None]
        if haze > 0:
            img[sl] = img[sl] * (1 - haze * ci[..., None] * 0.4) + C3(0.85, 0.82, 0.75)[None, None, :] * haze * ci[..., None] * 0.4


# ------------------------------------------------------------------ calle de Estrasburgo (fondo estático)
_SB = {}
def _lerp2(q, u, v):
    """interpolación bilineal en el cuadrilátero q=[(TL),(TR),(BR),(BL)]"""
    tl, tr, br, bl = q
    top = (tl[0] + (tr[0] - tl[0]) * u, tl[1] + (tr[1] - tl[1]) * u); bot = (bl[0] + (br[0] - bl[0]) * u, bl[1] + (br[1] - bl[1]) * u)
    return (top[0] + (bot[0] - top[0]) * v, top[1] + (bot[1] - top[1]) * v)

def _wall(M, q, nx, ny, seed=0, braces=True):
    """pared de entramado de madera sobre el cuadrilátero q: M dict de máscaras (wall, beam, win, door)."""
    rs = np.random.RandomState(seed)
    _P(M['wall'], q)
    for j in range(ny + 1):
        a = _lerp2(q, 0, j / ny); b = _lerp2(q, 1, j / ny); _L(M['beam'], [a, b], 3 if j in (0, ny) else 2)
    for i in range(nx + 1):
        a = _lerp2(q, i / nx, 0); b = _lerp2(q, i / nx, 1); _L(M['beam'], [a, b], 2)
    for j in range(ny):
        for i in range(nx):
            if rs.rand() < 0.35 and braces:
                if rs.rand() < 0.5: _L(M['beam'], [_lerp2(q, i / nx, (j + 1) / ny), _lerp2(q, (i + 1) / nx, j / ny)], 2)
                else: _L(M['beam'], [_lerp2(q, i / nx, j / ny), _lerp2(q, (i + 1) / nx, (j + 1) / ny)], 2)
            elif rs.rand() < 0.75 and j > 0:
                uu0, uu1 = (i + 0.25) / nx, (i + 0.75) / nx; vv0, vv1 = (j + 0.2) / ny, (j + 0.78) / ny
                _P(M['win'], [_lerp2(q, uu0, vv0), _lerp2(q, uu1, vv0), _lerp2(q, uu1, vv1), _lerp2(q, uu0, vv1)])
                _L(M['beam'], [_lerp2(q, (uu0 + uu1) / 2, vv0), _lerp2(q, (uu0 + uu1) / 2, vv1)], 1)
    return q

def street_layers():
    """máscaras del fondo (cacheadas). Devuelve dict de capas float."""
    if 'L' in _SB: return _SB['L']
    S = {k: np.zeros((H, W), np.uint8) for k in ('wall', 'beam', 'win', 'roof', 'stone', 'door', 'far', 'spire')}
    VP = (270, 318)
    # ---- fondo lejano: casas pequeñas y la aguja del Münster
    rs = np.random.RandomState(5)
    x = 100
    while x < 440:
        w = rs.randint(34, 58); hh = rs.randint(40, 78); base = 336
        _P(S['far'], [(x, base), (x + w, base), (x + w, base - hh), (x + w / 2, base - hh - rs.randint(18, 34)), (x, base - hh)])
        x += w - 4
    # catedral (Münster): cuerpo ancho + aguja alta
    _P(S['spire'], [(300, 336), (410, 336), (410, 226), (395, 214), (392, 160), (375, 150), (360, 150), (343, 160), (340, 214), (322, 226), (300, 236)])
    _P(S['spire'], [(318, 226), (332, 226), (336, 168), (318, 168)]); _P(S['spire'], [(372, 150), (364, 118), (360, 80), (357, 34), (355, 20), (353, 34), (350, 80), (346, 118), (338, 150)])
    for (px, py, ph_) in ((330, 160, 36), (386, 160, 36)): _P(S['spire'], [(px - 5, py), (px + 5, py), (px, py - ph_)])
    # ---- paredes laterales en perspectiva
    LQ = [((-20, 30), (150, 150), (150, 372), (-20, 470)), ((150, 150), (205, 215), (205, 340), (150, 372))]
    RQ = [((560, 30), (390, 150), (390, 372), (560, 470)), ((390, 150), (335, 215), (335, 340), (390, 372))]
    for qs, sd in ((LQ, 1), (RQ, 2)):
        _wall(S, qs[0], 5, 4, sd); _wall(S, qs[1], 3, 3, sd + 7)
        q0 = qs[0]
        top0 = q0[0]; top1 = q0[1]; _P(S['roof'], [(top0[0], top0[1] - 4), (top1[0], top1[1] - 4), (top1[0], top1[1] - 62), (top0[0], top0[1] - 150)] if sd == 1 else [(top0[0], top0[1] - 4), (top1[0], top1[1] - 4), (top1[0], top1[1] - 62), (top0[0], top0[1] - 150)])
        q1 = qs[1]; _P(S['roof'], [(q1[0][0], q1[0][1] - 3), (q1[1][0], q1[1][1] - 3), (q1[1][0], q1[1][1] - 40), (q1[0][0], q1[0][1] - 62)])
        d0 = _lerp2(q0, 0.55, 1.0); d1 = _lerp2(q0, 0.75, 1.0); dt0 = _lerp2(q0, 0.55, 0.70); dt1 = _lerp2(q0, 0.75, 0.72)
        _P(S['door'], [d0, d1, dt1, dt0])
    # ---- suelo: adoquines
    rs2 = np.random.RandomState(9)
    y = 342.0
    while y < 700:
        sc = (y - 300) / 340.0; rw = 7 + 40 * sc * sc ** 0.2; step = 4 + 22 * sc
        xx0 = -rw * rs2.rand(); xx = xx0
        while xx < W + rw:
            ww = rw * (0.7 + 0.5 * rs2.rand()); hh = step * 0.55 * (0.85 + 0.3 * rs2.rand())
            _E(S['stone'], xx + ww / 2, y, ww * 0.46, hh * 0.52, 0, 0, 360); xx += ww + rw * 0.18
        y += step
    L_ = {k: v for k, v in S.items()}
    # color: cada capa como máscara float y su sombreado
    out = {k: _fm(v, 0.5) for k, v in L_.items()}
    _SB['L'] = out; return out

def street_img(night=0.0, t=0.0, lanterns=()):
    """imagen RGB de la calle (día mezclado con noche). Cacheada en dos versiones (día/noche) y mezclada."""
    key = ('img',)
    if key not in _SB:
        S = street_layers(); r = np.random.RandomState(3)
        sky = vgrad([(0, (190, 205, 212)), (0.55, (232, 222, 200)), (1, (240, 222, 190))]) if False else None
        gy = np.clip((YY - 0) / 336.0, 0, 1)[..., None]
        img = (C3(0.72, 0.80, 0.84) * (1 - gy) + C3(0.95, 0.88, 0.74) * gy).astype(F32)
        # nubes de rayado
        cl_ = cv2.GaussianBlur(fractal(31, (60, 120, 240)).astype(F32), (0, 0), 6); cl_ = np.clip((cl_ - 0.52) * 3.0, 0, 1) * np.clip(1 - YY / 330.0, 0, 1)
        over(img, cl_, C3(1.0, 0.98, 0.94), 0.55)
        # lejos
        over(img, S['far'], C3(0.74, 0.66, 0.56), 0.95); over(img, S['far'] * (((XX + YY) % 7) < 1.8), INK, 0.10)
        over(img, S['spire'], C3(0.72, 0.52, 0.44), 0.93); over(img, cv2.GaussianBlur(S['spire'], (0, 0), 0.8) * ((YY % 6) < 1.4), C3(0.42, 0.24, 0.20), 0.30)
        edge = np.clip(cv2.GaussianBlur(S['spire'], (0, 0), 1.2) - S['spire'], 0, 1); over(img, np.clip(S['spire'] - cv2.GaussianBlur(S['spire'], (0, 0), 1.6), 0, 1) * 3, INK, 0.25)
        # suelo
        g = np.clip((YY - 334) / 330.0, 0, 1)[..., None]
        ground = (C3(0.74, 0.67, 0.55) * (1 - g) + C3(0.62, 0.55, 0.44) * g)
        gm = (YY >= 334).astype(F32); img = img * (1 - gm[..., None]) + ground * gm[..., None]
        over(img, S['stone'] * gm, C3(0.38, 0.32, 0.26), 0.42)
        # casas
        for sd in (0,):
            pass
        wall_c = C3(0.88, 0.78, 0.60)
        wm = np.clip(S['wall'], 0, 1)
        shade = np.clip(1.05 - 0.55 * np.abs(XX - 270) / 270.0, 0.55, 1.0)[..., None]
        img = img * (1 - wm[..., None]) + wall_c * (0.80 + 0.20 * ((XX < 200) * 1.0 + (XX > 340) * 0.0))[..., None] * wm[..., None] if False else img
        over(img, wm, C3(0.90, 0.80, 0.62), 1.0)
        # sombreado de profundidad en las paredes (más oscuro hacia la calle)
        side = np.clip(np.abs(XX - 270) / 270.0, 0, 1); over(img, wm * (1 - side), C3(0.40, 0.30, 0.20), 0.30)
        over(img, wm * (((XX * 0.6 + YY) % 6) < 1.2), INK, 0.06)
        over(img, S['roof'], C3(0.50, 0.24, 0.18), 1.0); over(img, S['roof'] * (((XX - YY * 0.35) % 5) < 1.3), INK, 0.35)
        over(img, S['win'] * wm, C3(0.20, 0.17, 0.15), 0.9)
        over(img, S['door'], C3(0.28, 0.18, 0.12), 1.0)
        over(img, S['beam'] * wm, C3(0.26, 0.17, 0.10), 0.95)
        # contorno de tinta de edificios y roofs
        for kk in ('wall', 'roof', 'door'):
            m = S[kk]; e = np.clip(cv2.GaussianBlur(m, (0, 0), 1.3) - m, 0, 1) * 2.0; over(img, np.clip(e + np.clip(m - cv2.GaussianBlur(m, (0, 0), 1.3), 0, 1) * 2.0, 0, 1), INK, 0.55)
        img *= (0.90 + 0.18 * _f[..., None])
        _SB[key] = np.clip(img, 0, 1).astype(F32); _SB['win'] = S['win'] * wm
    day = _SB[key]
    if night <= 0.01: return day.copy()
    nt = day * C3(0.30, 0.38, 0.62) * 0.62
    # ventanas encendidas + luz de farolillos
    wn = _SB['win'] * (0.75 + 0.25 * np.sin(XX * 0.7 + t * 5))[...] if False else _SB['win']
    nt = nt + wn[..., None] * C3(1.0, 0.68, 0.28) * 0.9
    for (lx, ly, lr) in lanterns:
        glow_roi(nt, lx, ly, lr, C3(1.0, 0.68, 0.30), 0.85, 2.0)
    out = day * (1 - night) + nt * night
    return out.astype(F32)
