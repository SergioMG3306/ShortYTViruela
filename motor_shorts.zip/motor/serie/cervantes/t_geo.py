import sys, time; sys.path.insert(0, '/home/claude/serie/cervantes')
from cv_geo import *
ims = []
for c, R in ((LEPANTO, 900), (LEPANTO, 5000), ((7.5, 39.0), 1750), ((15.5, 38.5), 1050)):
    t0 = time.time(); img, P = level(c, R); print(c, R, round(time.time() - t0, 2))
    for nm, ll in (('LEP', LEPANTO), ('ARG', ARGEL), ('CON', CONSTANT), ('CAT', CAPTURA), ('NAP', NAPOLES), ('ORA', ORAN), ('DEN', DENIA)):
        x, y = P.pt(*ll)
        if 0 < x < W and 0 < y < H: pin(img, x, y)
    ims.append(img)
out = np.hstack([cv2.resize(i, (270, 480)) for i in ims])
cv2.imwrite('t_geo.jpg', (out[:, :, ::-1] * 255).astype(np.uint8))
