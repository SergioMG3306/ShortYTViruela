import sys, json, math
import numpy as np, cv2
sys.path.insert(0, '/home/claude/serie/trailer/v2')
from lib import W, H, FW, FH, YY, XX, cl, prog, ease, eo, ei, hs, vgrad, radial, fractal, splat
from PIL import Image, ImageDraw, ImageFont

import os
PAL_DIR = os.environ.get('PAL_DIR', '/home/claude/serie/cervantes')
TJ = json.load(open(PAL_DIR + '/timing.json'))
ST = TJ['sent_t']; WD = TJ['words']; TEND = TJ['total']
SW = [[] for _ in ST]
for w, t, si in WD: SW[si].append((w, t))
_sf = TJ['scene_first']
B = [0.0] + [ST[_sf[i]][0] - 1.0 for i in range(1, len(_sf))] + [TEND]
T_I = 0.0
def tw(si, prefix, nth=0):
    """instante en que se pronuncia la palabra que empieza por `prefix` (sin acentos, minúsculas) dentro de la frase global `si`."""
    import unicodedata
    def nz_(x): return ''.join(c for c in unicodedata.normalize('NFD', x.lower()) if unicodedata.category(c) != 'Mn' and c.isalnum())
    p = nz_(prefix); k = 0
    for (w, t, s_) in WD:
        if s_ == si and nz_(w).startswith(p):
            if k == nth: return t
            k += 1
    raise KeyError((si, prefix, nth))
def st0(si): return ST[si][0]
def st1(si): return ST[si][1]

F32 = np.float32
def C3(a, b, c): return np.array((a, b, c), F32)
INK = C3(0.105, 0.095, 0.085); RED = C3(0.74, 0.17, 0.13); CREAM = C3(0.94, 0.90, 0.80); PAPER_C = C3(0.90, 0.85, 0.73)
def lerp(a, b, x): return a + (b - a) * x

# ---------- papel
_f = fractal(11, (5, 12, 28, 64, 150)); _g = np.random.RandomState(3).rand(H, W).astype(F32)
PAPER = np.clip(PAPER_C[None, None, :] * (0.88 + 0.2 * _f[..., None]) + 0.14 * (cv2.GaussianBlur(_g, (0, 0), 0.6) - 0.5)[..., None], 0, 1).astype(F32)
_d = np.sqrt(((XX - W / 2) / (W * 0.78)) ** 2 + ((YY - H / 2) / (H * 0.72)) ** 2)
VIG = np.clip(1 - 0.40 * _d ** 2.2, 0.42, 1)[..., None].astype(F32)
CONT = fractal(23, (40, 90, 200))

# ---------- dibujo vectorial
def mpoly(polys, blur=0.6):
    m = np.zeros((H, W), np.uint8)
    for p in polys: cv2.fillPoly(m, [np.round(np.asarray(p, np.float64) * 16).astype(np.int32)], 255, cv2.LINE_AA, shift=4)
    m = m.astype(F32) / 255
    return cv2.GaussianBlur(m, (0, 0), blur) if blur else m
def mcirc(items, blur=0.6):
    m = np.zeros((H, W), np.uint8)
    for (x, y, r) in items: cv2.circle(m, (int(round(x * 16)), int(round(y * 16))), int(round(max(r, 0.1) * 16)), 255, -1, cv2.LINE_AA, shift=4)
    m = m.astype(F32) / 255
    return cv2.GaussianBlur(m, (0, 0), blur) if blur else m
def over(img, m, col, a=1.0):
    c = np.asarray(col, F32)
    if c.ndim == 1: c = c[None, None, :]
    mm = (m * a)[..., None]; img[:] = img * (1 - mm) + c * mm
def shadow(img, m, k=0.3, off=(2, 3), bl=2.5):
    s = cv2.GaussianBlur(cv2.warpAffine(m, np.float32([[1, 0, off[0]], [0, 1, off[1]]]), (W, H)), (0, 0), bl); img *= (1 - k * s)[..., None]
def glow_roi(img, cx, cy, r, col, k=1.0, power=2.0):
    x0 = int(max(0, cx - r)); x1 = int(min(W, cx + r + 1)); y0 = int(max(0, cy - r)); y1 = int(min(H, cy + r + 1))
    if x0 >= x1 or y0 >= y1 or r < 1: return
    yy, xx = np.mgrid[y0:y1, x0:x1].astype(F32); d = np.sqrt((xx - cx) ** 2 + (yy - cy) ** 2) / r
    img[y0:y1, x0:x1] += (np.clip(1 - d, 0, 1) ** power)[..., None] * (np.asarray(col, F32) * k)
def rot(pts, ang, c):
    a = math.radians(ang); ca, sa = math.cos(a), math.sin(a)
    return [((x - c[0]) * ca - (y - c[1]) * sa + c[0], (x - c[0]) * sa + (y - c[1]) * ca + c[1]) for x, y in pts]
def beat(t, bpm=54, k=1.0):
    ph = (t * bpm / 60.0) % 1.0
    return k * (math.exp(-ph * 14) + 0.55 * math.exp(-((ph - 0.28) * 16) ** 2))

class Cam:
    def __init__(s, z=1.0, dx=0.0, dy=0.0, cx=W / 2, cy=H / 2): s.z, s.dx, s.dy, s.cx, s.cy = z, dx, dy, cx, cy
    def apply(s, img):
        M = cv2.getRotationMatrix2D((s.cx, s.cy), 0, s.z); M[:, 2] += (s.dx, s.dy)
        return cv2.warpAffine(img, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    def pt(s, x, y): return ((x - s.cx) * s.z + s.cx + s.dx, (y - s.cy) * s.z + s.cy + s.dy)

# ---------- texto a resolución completa
FM = '/usr/share/texmf/fonts/opentype/public/lm/lmmonolt10-bold.otf'
FMR = '/usr/share/texmf/fonts/opentype/public/lm/lmmono10-regular.otf'
_fo = {}; _ts = {}
def fnt(sz, bold=True):
    k = (sz, bold)
    if k not in _fo: _fo[k] = ImageFont.truetype(FM if bold else FMR, sz)
    return _fo[k]
def adv(sz, bold=True, track=0): return fnt(sz, bold).getlength('M') + track
def tsp(text, sz, bold=True, track=0):
    k = (text, sz, bold, track)
    if k in _ts: return _ts[k]
    f = fnt(sz, bold); a_ = adv(sz, bold, track); w = int(a_ * len(text)) + 10; h = int(sz * 1.45)
    im = Image.new('L', (w, h), 0); d = ImageDraw.Draw(im)
    for i, ch in enumerate(text): d.text((5 + i * a_, int(sz * 0.12)), ch, font=f, fill=255)
    _ts[k] = np.asarray(im, F32) / 255; return _ts[k]
def put(fr, a, x, y, col, alpha=1.0, anchor='l'):
    h, w = a.shape
    x0 = int(x - w / 2) if anchor == 'c' else (int(x - w) if anchor == 'r' else int(x)); y0 = int(y - h / 2)
    xa = max(0, x0); ya = max(0, y0); xb = min(FW, x0 + w); yb = min(FH, y0 + h)
    if xa >= xb or ya >= yb: return
    m = (a[ya - y0:yb - y0, xa - x0:xb - x0] * alpha)[..., None]
    fr[ya:yb, xa:xb] = fr[ya:yb, xa:xb] * (1 - m) + np.asarray(col, F32) * m

OV = []; RC = []; SP = []; PH = []
FOTOS = '/home/claude/serie/cervantes/fotos/'
def photo(name, cx, cy, w, ang, t0, t1, cap=''):
    PH.append((FOTOS + name, cx * 2, cy * 2, w * 2, ang, t0, t1, cap, 1.0))
_pc = {}
def photo_sprite(path, w, ang, cap):
    k = (path, w, ang, cap)
    if k in _pc: return _pc[k]
    a = np.asarray(Image.open(path).convert('RGB'), F32) / 255; h0, w0 = a.shape[:2]
    g = a.mean(2, keepdims=True); a = g + (a - g) * 0.45; a = a * C3(1.05, 0.97, 0.86); a = np.clip((a - 0.5) * 1.10 + 0.52, 0, 1)
    b = int(w * 0.045); bb = int(w * 0.17); iw = w - 2 * b; ih = int(iw * h0 / w0)
    ph = cv2.resize(a, (iw, ih), interpolation=cv2.INTER_AREA if iw < w0 else cv2.INTER_CUBIC)
    ph = ph + np.random.RandomState(2).randn(ih, iw, 1).astype(F32) * 0.03
    Hh = ih + b + bb; card = np.empty((Hh, w, 3), F32); card[:] = C3(0.95, 0.93, 0.86) * (0.97 + 0.03 * np.random.RandomState(4).rand(Hh, w, 1).astype(F32)); card[b:b + ih, b:b + iw] = np.clip(ph, 0, 1)
    if cap:
        sz = max(18, int(w * 0.05)); t_ = tsp(cap, sz, True); hh_, ww_ = t_.shape; x0 = (w - ww_) // 2; y0 = ih + b + (bb - hh_) // 2 + 2
        sl = card[y0:y0 + hh_, max(0, x0):max(0, x0) + min(ww_, w)]; tt_ = t_[:sl.shape[0], :sl.shape[1], None]; sl[:] = sl * (1 - tt_) + INK * 0.9 * tt_
    p = int(0.16 * max(w, Hh)); cv_ = np.zeros((Hh + 2 * p, w + 2 * p, 3), F32); al = np.zeros((Hh + 2 * p, w + 2 * p), F32); cv_[p:p + Hh, p:p + w] = card; al[p:p + Hh, p:p + w] = 1
    for (tx, ty, tang) in ((p + int(0.10 * w), p + 4, -38), (p + int(0.90 * w), p + 4, 38)):
        tw, th_ = 0.20 * w, 0.065 * w; bx = [(-tw / 2, -th_ / 2), (tw / 2, -th_ / 2), (tw / 2, th_ / 2), (-tw / 2, th_ / 2)]; ca, sa = math.cos(math.radians(tang)), math.sin(math.radians(tang))
        pts = np.array([(tx + x * ca - y * sa, ty + x * sa + y * ca) for x, y in bx], np.float32); tm = np.zeros(al.shape, np.uint8); cv2.fillPoly(tm, [np.round(pts).astype(np.int32)], 255, cv2.LINE_AA); tm = cv2.GaussianBlur(tm.astype(F32) / 255, (0, 0), 0.9)
        cv_ = cv_ * (1 - 0.80 * tm[..., None]) + C3(0.92, 0.85, 0.60) * 0.80 * tm[..., None]; al = np.maximum(al, tm * 0.9)
    M = cv2.getRotationMatrix2D(((w + 2 * p) / 2, (Hh + 2 * p) / 2), ang, 1.0)
    cv_ = cv2.warpAffine(cv_, M, (w + 2 * p, Hh + 2 * p)); al = cv2.warpAffine(al, M, (w + 2 * p, Hh + 2 * p)); al = cv2.GaussianBlur(al, (0, 0), 0.8)
    sh = cv2.GaussianBlur(al, (0, 0), 14); _pc[k] = (cv_, al, sh); return _pc[k]
def _xf(img, ea, s):
    h_, w_ = img.shape[:2]; nw, nh = int(w_ * s), int(h_ * s); M = cv2.getRotationMatrix2D((w_ / 2, h_ / 2), ea, s); M[0, 2] += nw / 2 - w_ / 2; M[1, 2] += nh / 2 - h_ / 2
    return cv2.warpAffine(img, M, (nw, nh), flags=cv2.INTER_LINEAR)
def draw_photos(fr, t):
    for (path, cx, cy, w, ang, t0, t1, cap, mul) in PH:
        d = t - t0
        if d < 0 or t > t1 or not os.path.exists(path): continue
        if d < 0.3: fr += (1 - np.clip(fr, 0, 1)) * (0.32 * math.exp(-d / 0.08))
        cv_, al, sh = photo_sprite(path, int(w), ang, cap)
        if d < 0.16: p_ = d / 0.16; s = 1.0 + 1.6 * (1 - p_ ** 2.2); ea = 14 * (1 - p_); a_in = min(1, d / 0.04)
        elif d < 0.38: q = (d - 0.16) / 0.22; s = 1 - 0.05 * math.sin(math.pi * q) * (1 - q); ea = -1.5 * math.sin(math.pi * q) * (1 - q); a_in = 1.0
        else: s = 1.0; ea = 0.0; a_in = 1.0
        if 0.16 <= d < 0.45:
            sx = 9 * math.exp(-(d - 0.16) * 13) * math.sin(d * 95); fr[:] = cv2.warpAffine(fr, np.float32([[1, 0, sx], [0, 1, sx * 0.6]]), (FW, FH), borderMode=cv2.BORDER_REFLECT)
        if abs(s - 1) > 1e-3 or abs(ea) > 1e-3: cv_ = _xf(cv_, ea, s); al = _xf(al, ea, s); sh = _xf(sh, ea, s)
        a_ = a_in * min(1, (t1 - t) / 0.35) * mul
        dy = 14 * (1 - min(1, (t1 - t) / 0.35)) + (4 * math.sin((d - 0.38) * 0.9) if d > 0.38 else 0); dx = 3 * math.sin(d * 0.7) if d > 0.38 else 0
        h_, w_ = al.shape; x0 = int(cx + dx - w_ / 2); y0 = int(cy + dy - h_ / 2)
        xa, ya, xb, yb = max(0, x0), max(0, y0), min(FW, x0 + w_), min(FH, y0 + h_)
        if xa >= xb or ya >= yb: continue
        sl = (slice(ya, yb), slice(xa, xb)); ss = (slice(ya - y0, yb - y0), slice(xa - x0, xb - x0))
        ks = 0.5 if d > 0.16 else 0.25
        fr[sl] *= (1 - ks * a_ * sh[ss])[..., None]; m = (al[ss] * a_)[..., None]; fr[sl] = fr[sl] * (1 - m) + cv_[ss] * m
    PH.clear()
def rect(x0, y0, x1, y1, col=None, alpha=0.95, sh=0.35):
    RC.append((x0 * 2, y0 * 2, x1 * 2, y1 * 2, CREAM if col is None else col, alpha, sh))
def sp(text, sz, col, ang, x, y, t0, alpha=0.9): SP.append((text, sz, col, ang, x, y, t0, alpha))
def ov(text, x, y, sz=40, col=INK, alpha=1.0, anchor='l', n=None, bold=True, track=0, sh=0.0):
    if alpha <= 0.003: return
    if sz <= 56: sz = int(sz * 1.28)
    OV.append((text, x * 2, y * 2, sz, col, alpha, anchor, n, bold, track, sh))
def typed(text, t, t0, cps=14.0):
    return int(max(0, min(len(text), (t - t0) * cps)))
def draw_ov(fr, t=0.0):
    for (x0, y0, x1, y1, col, al, shk) in RC:
        x0, y0, x1, y1 = int(x0), int(y0), int(x1), int(y1); xa, ya, xb, yb = max(0, x0 - 20), max(0, y0 - 20), min(FW, x1 + 20), min(FH, y1 + 20)
        if xa >= xb or ya >= yb: continue
        sub = fr[ya:yb, xa:xb]; m = np.zeros(sub.shape[:2], F32); cv2.rectangle(m, (x0 - xa + 5, y0 - ya + 7), (x1 - xa + 5, y1 - ya + 7), 1.0, -1); m = cv2.GaussianBlur(m, (0, 0), 8)
        sub *= (1 - shk * al * m)[..., None]; b = np.zeros(sub.shape[:2], F32); cv2.rectangle(b, (x0 - xa, y0 - ya), (x1 - xa, y1 - ya), 1.0, -1)
        sub[:] = sub * (1 - al * b[..., None]) + col * (al * b[..., None])
    RC.clear()
    draw_photos(fr, t)
    for (text, x, y, sz, col, al, anc, n, bold, track, sh) in OV:
        a = tsp(text, sz, bold, track); h, w = a.shape
        if n is not None:
            if n <= 0: continue
            wc = min(w, int(5 + n * adv(sz, bold, track)))
        else: wc = w
        x0 = x - w / 2 if anc == 'c' else (x - w if anc == 'r' else x)
        sub = a[:, :wc]
        if sh > 0: put(fr, cv2.GaussianBlur(sub, (0, 0), 3), x0 + 3, y + 4, (0, 0, 0), sh * al, 'l')
        put(fr, sub, x0, y, col, al, 'l')
    OV.clear()
    for (text, sz, col, ang, x, y, t0, al) in SP: stamp(fr, text, sz, col, ang, x, y, t, t0, al)
    SP.clear()

_st = {}
def stamp(fr, text, sz, col, ang, x, y, t, t0, alpha=0.9):
    d = t - t0
    if d < 0: return
    k = (text, sz, ang)
    if k not in _st:
        a = tsp(text, sz, True, 2); h, w = a.shape; pad = int(sz * 0.55)
        im = np.zeros((h + 2 * pad, w + 2 * pad), F32); im[pad:pad + h, pad:pad + w] = a
        b = np.zeros_like(im); cv2.rectangle(b, (6, 6), (im.shape[1] - 7, im.shape[0] - 7), 1.0, 6, cv2.LINE_AA); cv2.rectangle(b, (22, 22), (im.shape[1] - 23, im.shape[0] - 23), 1.0, 2, cv2.LINE_AA)
        im = np.maximum(im, b)
        nz = cv2.GaussianBlur(np.random.RandomState(5).rand(*im.shape).astype(F32), (0, 0), 1.7); nz = (nz - nz.min()) / (nz.max() - nz.min())
        im *= np.clip((nz - 0.30) * 3.2, 0, 1) * 0.85 + 0.15
        M = cv2.getRotationMatrix2D((im.shape[1] / 2, im.shape[0] / 2), ang, 1.0); _st[k] = cv2.warpAffine(im, M, (im.shape[1], im.shape[0]))
    a = _st[k]; s = 1 + 0.45 * (1 - eo(d / 0.16))
    if s != 1: a = cv2.resize(a, None, fx=s, fy=s, interpolation=cv2.INTER_LINEAR)
    put(fr, a, x * 2, y * 2, col, alpha * min(1, d / 0.08), 'c')

# ---------- subtítulos (tira de etiqueta con palabras que aparecen al ser dichas)
def _chunks(si):
    ws = SW[si]; out = []; cur = []; ln = 0
    for i, (w, t) in enumerate(ws):
        cur.append((w, t)); ln += len(w) + 1
        if i == len(ws) - 1 or (ln > 58) or (w[-1] in ',:;' and ln > 22): out.append(cur); cur = []; ln = 0
    return out
CH = [_chunks(i) for i in range(len(ST))]
def _wrap(text, width=30):
    lines = []; cur = ''
    for w in text.split():
        if len(cur) + len(w) + (1 if cur else 0) > width and cur: lines.append(cur); cur = w
        else: cur = (cur + ' ' + w) if cur else w
    lines.append(cur); return lines
CAP_SZ = 52
def caption(fr, t):
    for si, (t0, t1, _) in enumerate(ST):
        if not (t0 - 0.2 <= t <= t1 + 0.7): continue
        chs = CH[si]; ci = 0
        for k, c in enumerate(chs):
            if c[0][1] - 0.15 <= t: ci = k
        c = chs[ci]; end = (chs[ci + 1][0][1] - 0.15) if ci + 1 < len(chs) else (t1 + 0.6)
        al = min(1, (t - (c[0][1] - 0.05)) / 0.18) * min(1, (end - t) / 0.3)
        if al <= 0.01: continue
        full = ' '.join(w for w, _ in c); lines = _wrap(full, 26)
        a_ = adv(CAP_SZ); wmax = max(len(l) for l in lines) * a_ + 70; hh = len(lines) * CAP_SZ * 1.38 + 44
        cx, cy = FW / 2, 1385
        x0, y0, x1, y1 = int(cx - wmax / 2), int(cy - hh / 2), int(cx + wmax / 2), int(cy + hh / 2)
        sl = (slice(max(0, y0 - 18), min(FH, y1 + 18)), slice(max(0, x0 - 18), min(FW, x1 + 18)))
        # sombra + tira de papel
        sub = fr[sl]; sh = np.zeros(sub.shape[:2], F32); cv2.rectangle(sh, (18 + 6, 18 + 8), (18 + x1 - x0 + 6, 18 + y1 - y0 + 8), 1.0, -1); sh = cv2.GaussianBlur(sh, (0, 0), 9)
        sub *= (1 - 0.35 * al * sh)[..., None]
        bg = np.zeros(sub.shape[:2], F32); cv2.rectangle(bg, (18, 18), (18 + x1 - x0, 18 + y1 - y0), 1.0, -1)
        sub[:] = sub * (1 - 0.94 * al * bg[..., None]) + CREAM * (0.94 * al * bg[..., None])
        shown = [(w, tw) for w, tw in c if tw <= t + 0.04]
        txt = ' '.join(w for w, _ in shown)
        # reparte por líneas fijas según el texto completo
        idx = 0
        for li, l in enumerate(lines):
            seg = txt[idx:idx + len(l)]; idx += len(l) + 1
            if seg: put(fr, tsp(seg, CAP_SZ, True), cx - len(l) * a_ / 2 - 5, y0 + 22 + CAP_SZ * 0.72 + li * CAP_SZ * 1.38, INK, al, 'l')
        return

# ---------- iconos
def trefoil(img, cx, cy, R, col, a=1.0, spin=0.0):
    m = np.zeros((H, W), np.uint8); S = 16
    for base in (90, 210, 330):
        cv2.ellipse(m, (int(cx * S), int(cy * S)), (int(R * S), int(R * S)), 0, base - 30 + spin, base + 30 + spin, 255, -1, cv2.LINE_AA, shift=4)
    cv2.circle(m, (int(cx * S), int(cy * S)), int(R * 0.30 * S), 0, -1, cv2.LINE_AA, shift=4); cv2.circle(m, (int(cx * S), int(cy * S)), int(R * 0.17 * S), 255, -1, cv2.LINE_AA, shift=4)
    over(img, cv2.GaussianBlur(m.astype(F32) / 255, (0, 0), 0.6), col, a)

def chute(img, x, y, s=1.0, sway=0.0, top=False, a=1.0):
    """paracaídas visto de lado con bomba (si top=False) o disco visto desde arriba (top=True)."""
    if top:
        m = mcirc([(x, y, 15 * s)], 0.7); over(img, m, CREAM, a * 0.95)
        ang = np.linspace(0, 2 * np.pi, 9)[:-1]
        for i, th in enumerate(ang):
            if i % 2 == 0: over(img, mpoly([[(x, y), (x + 15 * s * math.cos(th), y + 15 * s * math.sin(th)), (x + 15 * s * math.cos(th + 0.785), y + 15 * s * math.sin(th + 0.785))]], 0.5) * m, RED, a * 0.9)
        return
    cx, cy = x, y - 62 * s; pts = []
    for th in np.linspace(math.pi, 2 * math.pi, 13): pts.append((cx + 34 * s * math.cos(th), cy + 20 * s * math.sin(th) + 20 * s))
    pts += [(cx + 34 * s, cy + 22 * s), (cx + 17 * s, cy + 15 * s), (cx, cy + 22 * s), (cx - 17 * s, cy + 15 * s), (cx - 34 * s, cy + 22 * s)]
    pts = rot(pts, sway, (x, y - 62 * s * 0.1))
    m = mpoly([pts], 0.6); shadow(img, m, 0.2, (2, 3), 2.0); over(img, m, CREAM, a)
    for i in (0, 2):
        xa = -34 + 22.7 * i; xb = xa + 22.7; pp = [(cx + xa * s, cy + 22 * s)] + [(cx + (xa + (xb - xa) * j / 6) * s, cy + (22 - 20 * math.sin(math.pi * ((xa + 34 + (xb - xa) * j / 6) / 68.0))) * s) for j in range(7)] + [(cx + xb * s, cy + 22 * s)]
        over(img, mpoly([rot(pp, sway, (x, y - 62 * s * 0.1))], 0.6) * m, RED, a * 0.85)
    for dx in (-34, -17, 0, 17, 34):
        p0 = rot([(cx + dx * s, cy + 22 * s)], sway, (x, y - 62 * s * 0.1))[0]; cv2.line(img, (int(p0[0]), int(p0[1])), (int(x), int(y)), tuple(float(v) for v in INK * 0.6), 1, cv2.LINE_AA)
    bomb(img, x, y + 16 * s, 40 * s, 90 + sway * 0.6, a)

def bomb(img, x, y, L, ang=0.0, a=1.0):
    """bomba termonuclear (cápsula con aletas) centrada en x,y, eje horizontal girado ang (90=morro abajo)."""
    h = L * 0.17
    body = [(-L / 2, -h), (L * 0.28, -h), (L * 0.40, -h * 0.55), (L * 0.5, 0), (L * 0.40, h * 0.55), (L * 0.28, h), (-L / 2, h)]
    fin1 = [(-L / 2, -h), (-L / 2 - L * 0.10, -h * 2.0), (-L * 0.30, -h)]; fin2 = [(-L / 2, h), (-L / 2 - L * 0.10, h * 2.0), (-L * 0.30, h)]
    c = (x, y)
    def tr(P): return rot([(x + p[0], y + p[1]) for p in P], ang, c)
    mb = mpoly([tr(body)], 0.5); shadow(img, mb, 0.25, (2, 3), 2.0)
    over(img, mpoly([tr(fin1), tr(fin2)], 0.5), C3(0.30, 0.32, 0.35), a); over(img, mb, C3(0.66, 0.68, 0.70), a)
    hi = [(-L / 2 + 2, -h * 0.9), (L * 0.28, -h * 0.9), (L * 0.36, -h * 0.5), (L * 0.2, -h * 0.35), (-L / 2 + 2, -h * 0.35)]
    over(img, mpoly([tr(hi)], 0.5) * mb, C3(0.90, 0.91, 0.92), a * 0.8)
    band = [(L * 0.05, -h), (L * 0.14, -h), (L * 0.14, h), (L * 0.05, h)]; over(img, mpoly([tr(band)], 0.5) * mb, C3(0.62, 0.15, 0.12), a * 0.85)

# ---------- mapa de España (lon, lat)
LL = [(-9.30, 43.05), (-8.70, 43.40), (-8.30, 43.45), (-7.00, 43.58), (-5.80, 43.58), (-4.00, 43.42), (-2.00, 43.40), (-1.78, 43.37), (-0.50, 42.80), (0.70, 42.80), (1.70, 42.50), (3.20, 42.40),
      (3.20, 42.20), (2.80, 41.70), (2.20, 41.40), (1.20, 41.08), (0.85, 40.72), (0.30, 40.10), (-0.30, 39.50), (0.15, 38.80), (-0.40, 38.40), (-0.60, 38.17), (-0.70, 37.85), (-0.80, 37.66), (-0.98, 37.58),
      (-1.15, 37.55), (-1.35, 37.45), (-1.58, 37.38), (-1.72, 37.22), (-1.83, 37.14), (-1.98, 36.98), (-2.10, 36.83), (-2.20, 36.72), (-2.70, 36.78), (-3.00, 36.72), (-4.40, 36.70), (-5.35, 36.13),
      (-5.60, 36.00), (-6.30, 36.50), (-6.90, 37.20), (-7.40, 37.20), (-8.90, 37.00), (-8.80, 38.50), (-9.50, 38.70), (-8.90, 40.20), (-8.70, 41.20), (-8.80, 42.00), (-9.00, 42.60)]
SEA_C = C3(0.62, 0.74, 0.76); LAND_L = C3(0.93, 0.88, 0.76)
def proj(lon, lat, cx, cy, k, ox=W / 2, oy=H / 2):
    return ((lon - cx) * k * math.cos(math.radians(cy)) + ox, -(lat - cy) * k + oy)
def mapbase(cx, cy, k, t, ox=W / 2, oy=H / 2, contour=1.0, grat=1.0):
    pts = [proj(lo, la, cx, cy, k, ox, oy) for lo, la in LL]
    land = mpoly([pts], 0.8)
    dist = cv2.distanceTransform((land < 0.5).astype(np.uint8), cv2.DIST_L2, 3)
    rip = np.clip(1 - np.abs(np.sin(dist * 0.42 - t * 0.5)) / 0.22, 0, 1) * np.exp(-dist / 55.0)
    sea = np.empty((H, W, 3), F32); sea[:] = SEA_C; sea *= (1 - 0.16 * rip[..., None]); sea *= (0.94 + 0.08 * (_f[..., None] - 0.5))
    shadow(sea, land, 0.22, (3, 4), 4.0)
    line = np.clip(1 - np.abs(np.sin(CONT * 22 * math.pi)) / 0.10, 0, 1) * contour
    lc = PAPER * (1 - 0.30 * line[..., None] * C3(0.35, 0.55, 0.9)[None, None, :]); lc = lc * C3(1.01, 1.0, 0.97)
    img = sea * (1 - land[..., None]) + lc * land[..., None]
    cm = np.zeros((H, W), np.uint8); cv2.polylines(cm, [np.round(np.array(pts) * 16).astype(np.int32)], True, 255, 1, cv2.LINE_AA, shift=4)
    over(img, cv2.GaussianBlur(cm.astype(F32) / 255, (0, 0), 0.7), INK, 0.65)
    if grat > 0:
        gm = np.zeros((H, W), np.uint8); step = 0.5 if k > 120 else 2.0
        lo0 = math.floor((cx - W / (k * 0.7)) / step) * step
        for lo in np.arange(lo0, cx + W / (k * 0.7), step):
            x = int(proj(lo, cy, cx, cy, k, ox, oy)[0]); cv2.line(gm, (x, 0), (x, H), 255, 1)
        la0 = math.floor((cy - H / k) / step) * step
        for la in np.arange(la0, cy + H / k, step):
            y = int(proj(cx, la, cx, cy, k, ox, oy)[1]); cv2.line(gm, (0, y), (W, y), 255, 1)
        over(img, gm.astype(F32) / 255, INK, 0.10 * grat)
    return img

def smoke(img, items, col=C3(0.10, 0.09, 0.09), a=0.5):
    m = mcirc(items, 6.0); over(img, np.clip(m * 1.8, 0, 1), col, a)

def post_grain(img, fi):
    return img
