import sys; sys.path.insert(0, '/home/claude/serie/cervantes')
from cv_lib import *
from cv_lib import _f, _d
import cv_lib as L
from cv_art import *
from cv_artbase import _L, _P, _C, _E, _fm
from cv_art import _R
from cv_geo import *

BLUE = C3(0.20, 0.40, 0.62); INKR = C3(0.52, 0.10, 0.08); GREENI = C3(0.16, 0.42, 0.30)
def tn(text, t, t0, cps=14.0): return typed(text, t, t0, cps)
def fadeio(t, a, b, fi=0.4, fo=0.5): return ease((t - a) / fi) * (1 - ease((t - b) / fo))
def win(t, a, b, fi=0.35, fo=0.35): return ease((t - a) / fi) * (1 - ease((t - b) / fo))
def panel(img, x0, y0, x1, y1, a=0.93, col=None, sh=0.3):
    col = CREAM if col is None else col
    m = np.zeros((H, W), F32); cv2.rectangle(m, (int(x0), int(y0)), (int(x1), int(y1)), 1.0, -1)
    s_ = cv2.GaussianBlur(np.roll(np.roll(m, 3, 0), 2, 1), (0, 0), 4); img *= (1 - sh * a * s_)[..., None]
    img[:] = img * (1 - a * m[..., None]) + np.asarray(col, F32) * (a * m[..., None])
L_C = {}
def paper_bg(tone=(0.93, 0.89, 0.82)):
    k = ('pap', tone)
    if k in L_C: return L_C[k]
    line = np.clip(1 - np.abs(np.sin(CONT * 20 * math.pi)) / 0.09, 0, 1)
    L_C[k] = (PAPER * C3(*tone)[None, None, :] * (1 - 0.14 * line[..., None])).astype(F32); return L_C[k]
def vignette(img, k=0.35): img *= np.clip(1 - k * _d ** 2.2, 0.45, 1)[..., None]
def white_flash(img, a): img += (1 - np.clip(img, 0, 1)) * a
def header(t, text, t0, t1, cps=22, col=None):
    if t0 - 0.05 < t < t1 + 0.6:
        al = fadeio(t, t0 - 0.05, t1, 0.3, 0.45); rect(20, 40, 520, 130, col, 0.92 * al); ov(text, 270, 86, 30, INK, al, 'c', n=tn(text, t, t0, cps))
def recre(t, a=0.8, col=None):
    ov('RECREACIÓN GRÁFICA · ILUSTRACIÓN PROPIA', 270, 640, 14, INK if col is None else col, a, 'c')
def tag(x, y, text, t, t0, a, col=INK, sz=20, w=None, cps=16):
    """etiqueta de papel con texto tecleado centrada en (x,y)."""
    if a <= 0.003: return
    ww = (len(text) * sz * 0.52 + 30) if w is None else w
    rect(x - ww / 2, y - sz * 0.95, x + ww / 2, y + sz * 0.95, None, 0.93 * a, 0.3); ov(text, x, y, sz, col, a, 'c', n=tn(text, t, t0, cps))
def shake(t, t0, k=8.0, dec=10.0):
    d = t - t0
    if d < 0 or d > 0.6: return 0.0
    return k * math.exp(-d * dec) * math.sin(d * 90)
def bell(img, x, y, s, t, a=1.0):
    sw = math.sin(t * 6) * 0.35
    pts = [(0, -18), (10, -14), (14, 6), (20, 16), (-20, 16), (-14, 6), (-10, -14)]
    c, sn = math.cos(sw), math.sin(sw)
    P_ = [(x + (px * c - py * sn) * s, y - 8 * s + (px * sn + py * c) * s) for px, py in pts]
    m = mk(); _P(m, P_); paint(img, m, GOLD, a); o = mk(); _L(o, P_ + [P_[0]], 2); paint(img, o, INK, a * 0.85)
    cl_ = mk(); _C(cl_, x + math.sin(sw * 3) * 4 * s, y + 18 * s, 4 * s); paint(img, cl_, INK, a * 0.9)
def maplabel(P, ll, text, t, t0, a, col=RED, dx=0, dy=30, sz=20, pinr=6):
    x, y = P.pt(*ll)
    if a <= 0.003: return x, y
    pin(img_hold[0], x, y, col, a, pinr)
    ww = len(text) * sz * 0.52 + 26
    rect(x + dx - ww / 2, y + dy - sz * 0.85, x + dx + ww / 2, y + dy + sz * 0.85, None, 0.9 * a, 0.25); ov(text, x + dx, y + dy, sz, col * 0.9, a, 'c', n=tn(text, t, t0, 14))
    return x, y
img_hold = [None]
def ring(img, x, y, r, col, a, th=3):
    m = mk(); _R(m, x, y, r, th); paint(img, m, col, a, 0.6)
def arrow(img, p0, p1, col, a, th=4, tip=0.3):
    m = mk(); cv2.arrowedLine(m, (int(p0[0] * 16), int(p0[1] * 16)), (int(p1[0] * 16), int(p1[1] * 16)), 255, th, cv2.LINE_AA, 4, tip); paint(img, m, col, a, 0.6)


# ===================================================== S0 · gancho
_DB = {}
def desk_bg(t):
    if 'd' not in _DB:
        g = np.clip(YY / H, 0, 1)[..., None]
        img = C3(0.24, 0.16, 0.11) * (1 - g) + C3(0.14, 0.09, 0.06) * g
        grain = np.sin((YY * 0.09 + 9 * fractal(44, (30, 80, 200))) * 6.0)
        img = img * (0.88 + 0.10 * grain[..., None] + 0.12 * _f[..., None])
        _DB['d'] = img.astype(F32)
    img = _DB['d'].copy()
    fk = 1 + 0.08 * math.sin(t * 11) * math.sin(t * 4.3)
    glow_roi(img, 470, 120, 420, C3(1.0, 0.66, 0.30), 0.30 * fk, 1.6)
    vignette(img, 0.55)
    return img

def s0(t):
    img = desk_bg(t)
    img = Cam(1.0 + 0.06 * prog(t, 0, B[1]), 0, 0, 270, 400).apply(img)
    t_casi = st0(1); t_es = st0(2)
    header(t, 'ARCHIVO · MIGUEL DE CERVANTES', 0.1, B[1] - 0.6, 26)
    # fotos: portada y retrato
    photo('portada.jpg', 166, 410, 240, -4.0, 0.2, t_casi - 0.15, 'EL QUIJOTE · 1605')
    photo('retrato.png', 384, 318, 260, 5.0, 1.05, t_casi - 0.15, 'MIGUEL DE CERVANTES')
    if t < t_casi - 0.1: sp('DESCLASIFICADO', 64, RED, -8, 300, 596, 2.0, 0.95 * (1 - ease(prog(t, t_casi - 0.45, t_casi - 0.15))))
    if t < t_casi: ov('1547 – 1616', 384, 456, 24, CREAM, ease((t - 1.5) / 0.4) * (1 - ease((t - t_casi + 0.3) / 0.3)), 'c', sh=0.6)
    # antes del Quijote: tres tarjetas
    cards = [('SOLDADO', tw(1, 'soldado'), 'helmet'), ('PRISIONERO', tw(1, 'prisionero'), 'chains'), ('FUGITIVO', tw(1, 'fugitivo'), 'run')]
    for k, (lab, tc, ic) in enumerate(cards):
        if t > tc - 0.25:
            a = ease((t - tc + 0.25) / 0.3); x0 = 18 + k * 172; y0 = 236 + 16 * (1 - eo((t - tc + 0.25) / 0.4)) - 46 * ease(prog(t, t_es, t_es + 0.6))
            panel(img, x0, y0, x0 + 164, y0 + 226, 0.95 * a)
            icon(img, ic, x0 + 82, y0 + 92, 1.25 if ic != 'run' else 1.4, a, t)
            ov(lab, x0 + 82, y0 + (196 if k != 1 else 204), 26 if k != 1 else 22, INK if k == 0 else RED, a, 'c', n=tn(lab, t, tc, 16))
            if k == 1: ov('DE PIRATAS', x0 + 82, y0 + 176, 17, INK, a, 'c')
    if t > t_casi - 0.2:
        a = ease((t - t_casi + 0.2) / 0.4) * (1 - ease((t - t_es) / 0.3)); rect(110, 160, 430, 210, None, 0.93 * a, 0.3)
        ov('ANTES DEL QUIJOTE', 270, 185, 26, RED, a, 'c', n=tn('ANTES DEL QUIJOTE', t, t_casi, 18))
    # la historia que no te contaron
    tst = tw(2, 'historia')
    sp('LA HISTORIA OCULTA', 58, RED, -4, 270, 500, tst - 0.1, 0.97)
    if t > tw(2, 'contaron') - 0.2:
        a = ease((t - tw(2, 'contaron') + 0.2) / 0.3)
        rect(30, 562, 510, 618, None, 0.94 * a, 0.3); ov('1571 · 1575 · 1580 · 1597 · 1605', 270, 590, 26, INK, a, 'c', n=tn('1571 · 1575 · 1580 · 1597 · 1605', t, tw(2, 'contaron'), 26))
    return img


# ===================================================== S1 · Lepanto
FLEET_W = [(-14, -10), (-14, 10), (-26, 0), (-26, 20), (-26, -20), (-38, 10), (-38, -10)]
FLEET_E = [(14, -12), (14, 8), (26, -2), (26, 18), (26, -22), (38, 8), (38, -12)]
def sea_battle(t, smoke=1.0, dusk=0.0, big=True):
    img = sea_img(300, dusk); waves(img, t, 300)
    for (gx, gy, gl, f, k) in ((40, 318, 60, 1, 'cris'), (130, 312, 46, 1, 'cris'), (420, 316, 64, -1, 'cors'), (505, 322, 50, -1, 'cors'), (330, 309, 38, -1, 'cors')):
        galley(img, gx, gy, gl, f, t + gx * 0.01, 1.0, k, smoke=0.0)
    for j in range(7):
        ph = (t * 0.22 + j / 7) % 1.0; sx = 40 + j * 72; sy = 300 - 10 - 60 * ph
        over(img, mcirc([(sx + 18 * ph, sy, 12 + 30 * ph)], 5.0), C3(0.86, 0.84, 0.80), 0.5 * smoke * (1 - ph) * ease(ph * 6))
    if big: galley(img, 270, 470, 410, 1, t, 1.0, 'cris', smoke=smoke)
    return img

def s1(t):
    t_d = st0(3); t_g = st0(4); t_ci = st0(5); t_m = st0(6); t_or = st0(7); t_ni = st0(8); t_re = st0(9)
    out = None
    # ---------- A · mapa
    aA = 1 - ease(prog(t, t_m - 0.6, t_m - 0.1))
    if aA > 0:
        R = lerp(900.0, 3000.0, ease(prog(t, t_d + 0.6, t_g + 0.9)))
        img, P = view(LEPANTO, R, [900.0, 1800.0, 3000.0]); img = img.copy(); img_hold[0] = img
        if t > t_g - 0.2:
            a = ease((t - t_g + 0.2) / 0.4); x, y = P.pt(*LEPANTO)
            pulse(img, x, y, t, RED, a * (1 - ease(prog(t, t_ci, t_ci + 0.5))), 8, 50, 1.2, 2, 2)
            maplabel(P, LEPANTO, 'LEPANTO', t, t_g, a * (1 - ease(prog(t, t_ci - 0.2, t_ci + 0.3))), RED, 0, -34, 22)
        if t > t_ci - 0.3:
            k = ease(prog(t, t_ci - 0.3, tw(5, 'enfrentan') + 0.4)); af = ease((t - t_ci + 0.3) / 0.3)
            AW = route(P, [(17.6, 39.75), (19.0, 39.1), (20.2, 38.55), (20.85, 38.33)]); AE = route(P, [(22.05, 38.36), (21.6, 38.31), (21.25, 38.27)])
            solid(img, AW, BLUE, 0.85 * af, 7, upto=k); solid(img, AE, RED, 0.85 * af, 7, upto=k)
            for (A_, col_, kind_, f_) in ((AW, BLUE, 'cris', 1), (AE, RED, 'cors', -1)):
                x, y, tx, ty = along(A_, k)
                m = mk(); cv2.arrowedLine(m, (int((x - tx * 4) * 16), int((y - ty * 4) * 16)), (int((x + tx * 14) * 16), int((y + ty * 14) * 16)), 255, 7, cv2.LINE_AA, 4, 0.9); paint(img, m, col_, 0.9 * af, 0.6)
                for j in range(3): galley(img, x - tx * (34 + 22 * j) + (j - 1) * 6, y - ty * (34 + 22 * j) - 16 + 13 * j, 30, f_, t + j, af, kind_)
            a = ease((t - tw(5, 'galeras') + 0.2) / 0.4) * (1 - ease((t - tw(5, 'mayor') + 0.1) / 0.3))
            x, y = P.pt(*LEPANTO)
            tag(x - 120, y - 150, 'LIGA SANTA', t, tw(5, 'galeras'), a, BLUE, 22)
            tag(x + 70, y + 110, 'IMPERIO OTOMANO', t, tw(5, 'galeras') + 0.25, a, RED, 22)
            if k > 0.95:
                for j in range(6):
                    ph = (t * 0.6 + j / 6) % 1.0; sx = x - 20 + (hs(j, 2) - 0.5) * 60; sy = y + (hs(j, 5) - 0.5) * 30 - 20 * ph
                    over(img, mcirc([(sx, sy, 5 + 14 * ph)], 3.0), C3(0.9, 0.88, 0.84), 0.6 * (1 - ph))
        header(t, '7 DE OCTUBRE DE 1571', t_d, t_g - 0.3, 22)
        header(t, 'GOLFO DE LEPANTO', t_g, t_m - 0.7, 20)
        photo('lepanto.jpg', 270, 410, 476, -2.0, tw(5, 'mayor') - 0.05, t_m - 0.6, 'LA BATALLA DE LEPANTO · ÓLEO ANÓNIMO')
        out = img
    # ---------- B · la galera Marquesa
    aB = ease(prog(t, t_m - 0.6, t_m - 0.1)) * (1 - ease(prog(t, t_re - 0.5, t_re)))
    if aB > 0:
        img = sea_battle(t)
        sx = shake(t, tw(8, 'niega'), 6)
        img = Cam(1.0 + 0.05 * prog(t, t_m, t_re), sx, 0, 270, 470).apply(img)
        tg = tw(6, 'marquesa')
        if t > tg - 0.2:
            a = win(t, tg - 0.2, t_or - 0.2); tag(270, 560, 'GALERA MARQUESA', t, tg, a, INK, 22)
        tsd = tw(6, 'soldado')
        if t > tsd - 0.3:
            a = ease((t - tsd + 0.3) / 0.35); panel(img, 22, 146, 214, 460, 0.95 * a)
            ch = person(img, 118, 384, 200, 'soldier', a, t, 'stand', gun=True)
            ov('SOLDADO', 118, 412, 20, INK, a, 'c'); ov('24 AÑOS', 118, 440, 20, RED, a, 'c', n=tn('24 AÑOS', t, tw(6, 'veinticuatro'), 10))
            tf = tw(6, 'fiebre')
            if t > tf - 0.2:
                af = ease((t - tf + 0.2) / 0.3) * a; hx, hy = ch['head']
                for j in range(3):
                    m = mk(); rr = 26 + j * 9 + 4 * math.sin(t * 6 + j)
                    cv2.ellipse(m, (int(hx * 16), int(hy * 16)), (int(rr * 16), int(rr * 16)), 0, 200, 340, 255, 2, cv2.LINE_AA, 4); paint(img, m, RED, af * (0.9 - 0.25 * j), 0.6)
                tag(118, 492, 'FIEBRE', t, tf, af, RED, 24)
        if t > t_or - 0.2:
            a = win(t, t_or - 0.2, t_re - 0.6); x, y = 300, 400
            arrow(img, (x, y - 70), (x, y + 30), RED, a * ease((t - t_or) / 0.4), 6, 0.35)
            tag(x + 100, 330, 'BAJO CUBIERTA', t, tw(7, 'bajo'), a, INK, 20)
        if t < t_re - 0.3: sp('SE NIEGA', 60, RED, -6, 360, 248, tw(8, 'niega') - 0.05, 0.97 * (1 - ease(prog(t, t_re - 0.6, t_re - 0.3))))
        if t > t_m - 0.2: recre(t, 0.8)
        out = img if out is None else out * (1 - aB) + img * aB
    # ---------- C · informe de heridas
    aC = ease(prog(t, t_re - 0.5, t_re))
    if aC > 0:
        img = paper_bg((0.86, 0.82, 0.74)).copy()
        th1 = tw(9, 'disparos'); th2 = th1 + 0.45; th3 = tw(9, 'mano')
        sx = shake(t, th1, 7) + shake(t, th2, 7) + shake(t, th3, 9)
        panel(img, 60, 150, 480, 640, 0.6, C3(0.95, 0.92, 0.84))
        ch = person(img, 270, 620, 440, 'soldier', 1.0, t, 'stand')
        img = Cam(1.0, sx, sx * 0.5, 270, 400).apply(img)
        header(t, 'INFORME DE HERIDAS', t_re - 0.2, B[2] - 0.5, 20)
        cx, cy = ch['chest']; u = ch['u']; hits = [((cx - 0.55 * u, cy - 0.2 * u), th1), ((cx + 0.45 * u, cy + 0.6 * u), th2), (ch['hands'][1], th3)]
        for k, ((hx, hy), th) in enumerate(hits):
            if t > th - 0.05:
                d = t - th; a = ease(d / 0.15)
                if d < 0.25: glow_roi(img, hx + sx, hy, 70, C3(1.0, 0.9, 0.6), 1.2 * (1 - d / 0.25), 2.0)
                ring(img, hx + sx, hy, 16 + 26 * math.exp(-d * 5), RED, a, 4); x_mark(img, hx + sx, hy, 9, RED, min(1, d / 0.2), 5)
        if t > th1: tag(112, 300, 'PECHO', t, th1, ease((t - th1) / 0.3), RED, 22, 120); tag(112, 344, '2 DISPAROS', t, th2, ease((t - th2) / 0.3), INK, 18, 120)
        if t > th3: tag(440, 470, 'MANO', t, th3, ease((t - th3) / 0.3), RED, 22, 132); tag(440, 514, 'IZQUIERDA', t, th3 + 0.2, ease((t - th3 - 0.2) / 0.3), RED, 18, 132)
        if t > tw(9, 'arcabuz') - 0.2: tag(430, 196, 'ARCABUZ', t, tw(9, 'arcabuz'), ease((t - tw(9, 'arcabuz') + 0.2) / 0.3), INK, 20)
        recre(t, 0.7)
        out = img if out is None else out * (1 - aC) + img * aC
    return out


# ===================================================== S2 · la mano
def s2(t):
    t_no = st0(10); t_in = tw(10, 'inutil'); t_ma = tw(11, 'manco'); t_nu = st0(12); t_q = st0(13)
    img = paper_bg().copy()
    aH = 1 - ease(prog(t, t_q - 0.3, t_q + 0.2))
    if aH > 0:
        dead = ease(prog(t, t_in - 0.1, t_in + 0.8))
        sub = paper_bg().copy(); big_hand(sub, 270, 352, 400, 1.0, dead)
        sub = Cam(1.0 + 0.05 * prog(t, B[2], t_q), 0, 0, 270, 372).apply(sub)
        img = img * (1 - aH) + sub * aH
        header(t, 'LA MANO IZQUIERDA', B[2] + 0.4, t_q - 0.4, 20)
        if t > t_no - 0.1: tag(128, 596, 'NO LA PERDIÓ', t, t_no, win(t, t_no - 0.1, t_ma - 0.3), INK, 20)
        if t > t_in - 0.1: tag(382, 596, 'INÚTIL PARA SIEMPRE', t, t_in, win(t, t_in - 0.1, t_ma - 0.3), RED, 20)
        if t < t_q: sp('EL MANCO DE LEPANTO', 56, RED, -5, 270, 560, t_ma - 0.1, 0.97 * (1 - ease(prog(t, t_q - 0.4, t_q - 0.05))))
        if t > t_nu - 0.2: tag(270, 186, 'NUNCA SE ARREPINTIÓ', t, t_nu, win(t, t_nu - 0.2, t_q - 0.3), INK, 22)
    # cita
    if t > t_q - 0.3:
        a = ease((t - t_q + 0.3) / 0.4)
        header(t, 'EN SUS PROPIAS PALABRAS', t_q - 0.2, B[3] - 0.5, 22)
        panel(img, 30, 160, 510, 560, 0.95 * a)
        icon(img, 'quill', 440, 230, 0.9, a, t)
        L1 = '«LA MÁS ALTA'; L2 = 'OCASIÓN QUE VIERON'; L3 = 'LOS PASADOS SIGLOS»'
        ov(L1, 270, 300, 38, INK, a, 'c', n=tn(L1, t, tw(13, 'la', 1), 13))
        ov(L2, 270, 360, 38, INK, a, 'c', n=tn(L2, t, tw(13, 'ocasion'), 14))
        ov(L3, 270, 420, 38, RED, a, 'c', n=tn(L3, t, tw(13, 'los'), 14))
        ov('CERVANTES · QUIJOTE II, PRÓLOGO (1615)', 270, 510, 15, INK, a * ease((t - tw(13, 'siglos')) / 0.4), 'c')
    return img


# ===================================================== S3 · captura y Argel
C3M = (7.0, 40.8)
ROUTE_SOL = [NAPOLES, (13.2, 41.15), (12.0, 41.9), (10.5, 43.0), (9.0, 44.1), (7.3, 43.6), (5.4, 43.15), (4.1, 43.05), (3.45, 42.55), CAPTURA]
ROUTE_ARG = [CAPTURA, (3.6, 41.0), (3.4, 39.4), (3.2, 37.9), ARGEL]
def s3(t):
    t_s = st0(14); t_v = st0(15); t_ca = tw(15, 'cartas'); t_f = st0(16); t_as = tw(16, 'asaltan'); t_co = st0(17); t_im = tw(17, 'importante'); t_qu = tw(17, 'quinientos')
    t_de = st0(18); t_ar = tw(18, 'argel'); t_me = tw(18, 'mercado'); t_fa = st0(19); t_he = tw(19, 'hermano')
    R = lerp(1750.0, 1950.0, prog(t, B[3], t_fa))
    img, P = view(C3M, R, [1750.0, 3000.0]); img = img.copy(); img_hold[0] = img
    sx = shake(t, t_as, 7); dim = 0.0
    rs = route(P, ROUTE_SOL); ra = route(P, ROUTE_ARG)
    # ruta de la galera Sol
    if t > t_v - 0.3:
        k = ease(prog(t, t_v, t_as - 0.2)); a = 1 - ease(prog(t, t_fa - 0.4, t_fa))
        dashed(img, rs, INK, 0.75 * a, 2, 8, 6, upto=k)
        x, y, tx, ty = along(rs, k)
        if t < t_de + 0.2: galley(img, x, y, 46, 1 if tx >= 0 else -1, t, a, 'cris')
        if k < 0.98: tag(x, y - 44, 'GALERA SOL', t, tw(15, 'galera'), a * win(t, tw(15, 'galera') - 0.2, t_f), INK, 16)
        tag(390, 446, 'RUTA APROXIMADA', t, t_v + 0.4, a * 0.85 * win(t, t_v + 0.2, t_f - 0.2), INK, 16)
    a = 1 - ease(prog(t, t_fa - 0.4, t_fa))
    maplabel(P, NAPOLES, 'NÁPOLES', t, t_s + 0.3, ease((t - t_s - 0.2) / 0.4) * a * (1 - ease(prog(t, t_f, t_f + 0.4))), INK, 0, 28, 18, 5)
    if t > t_s: ov('ESPAÑA', *P.pt(-2.0, 40.0), 24, INK * 1.6, ease((t - t_s) / 0.5) * 0.7 * a, 'c')
    # corsarios
    if t > t_f - 0.3:
        k = ease(prog(t, t_f - 0.3, t_as)); x0, y0 = P.pt(*CAPTURA)
        for j, (ox_, oy_) in enumerate(((-70, 150), (10, 170), (90, 140))):
            gx = x0 + ox_ * (1 - k) + (j - 1) * 30 * k; gy = y0 + oy_ * (1 - k) + 22 * k + (6 if j == 1 else 0)
            if t < t_de + 0.2: galley(img, gx, gy, 40, 1 if ox_ < 0 else -1, t + j, a * ease((t - t_f + 0.3) / 0.3), 'cors')
        if t > t_as - 0.2:
            pulse(img, x0, y0, t, RED, a * (1 - ease(prog(t, t_co, t_co + 0.4))), 10, 60, 1.0, 3, 2)
        tag(x0 + 40, y0 + 112, 'CORSARIOS BERBERISCOS', t, tw(16, 'corsarios'), a * win(t, tw(16, 'corsarios') - 0.2, t_co - 0.2), RED, 18)
        tag(x0 - 20, y0 - 50, 'COSTA CATALANA', t, tw(16, 'costa'), a * win(t, tw(16, 'costa') - 0.2, tw(16, 'corsarios')), INK, 16)
    # cartas de recomendación
    if t > t_ca - 0.3:
        a = win(t, t_ca - 0.3, t_f - 0.2); panel(img, 290, 300, 524, 500, 0.96 * a); icon(img, 'letter', 407, 362, 1.1, a, t)
        ov('CARTAS DE', 407, 428, 18, INK, a, 'c'); ov('DON JUAN DE AUSTRIA', 407, 462, 17, RED, a, 'c', n=tn('DON JUAN DE AUSTRIA', t, tw(15, 'juan'), 16))
    # las cartas lo condenan
    if t > t_co - 0.3:
        a = win(t, t_co - 0.3, t_de - 0.1); img *= (1 - 0.45 * a)
        panel(img, 30, 160, 510, 610, 0.96 * a)
        icon(img, 'letter', 150, 262, 1.4, a, t)
        ov('LAS CARTAS', 360, 240, 24, INK, a, 'c'); ov('LO CONDENAN', 360, 280, 24, RED, a, 'c', n=tn('LO CONDENAN', t, tw(17, 'condenan') - 0.2, 14))
        if t > t_im - 0.2: tag(270, 366, '¿ALGUIEN IMPORTANTE?', t, t_im, ease((t - t_im + 0.2) / 0.3) * a, RED, 22)
        if t > t_qu - 0.3:
            aq = ease((t - t_qu + 0.3) / 0.3) * a; icon(img, 'coins', 140, 510, 1.4, aq, t)
            n = int(500 * ease(prog(t, t_qu, t_qu + 1.0)))
            ov('%d' % n, 360, 496, 72, RED, aq, 'c'); ov('ESCUDOS DE ORO', 360, 556, 22, INK, aq, 'c'); ov('RESCATE PEDIDO', 360, 440, 18, INK, aq, 'c')
    # destino Argel
    if t > t_de - 0.2:
        k = ease(prog(t, t_de, t_ar + 0.6)); a = 1 - ease(prog(t, t_fa - 0.4, t_fa))
        dashed(img, ra, RED, 0.9 * a, 3, 9, 6, upto=k)
        x, y, tx, ty = along(ra, k)
        for j in range(3): galley(img, x + (j - 1) * 26, y + (abs(j - 1)) * 14, 38, -1 if j == 0 else 1, t + j, a, 'cors' if j != 1 else 'cris')
        maplabel(P, ARGEL, 'ARGEL', t, t_ar, ease((t - t_ar + 0.1) / 0.3) * a, RED, 0, 30, 22, 7)
        photo('argel.jpg', 270, 410, 470, 2.0, t_me - 0.1, t_fa - 0.25, 'ARGEL · GRABADO ANTIGUO')
    header(t, 'SEPTIEMBRE DE 1575', t_s - 0.1, t_de - 0.4, 22)
    header(t, 'DESTINO: ARGEL', t_de, t_fa - 0.4, 22)
    if sx: img = Cam(1.0, sx, sx * 0.5).apply(img)
    # el hermano
    aF = ease(prog(t, t_fa - 0.4, t_fa))
    if aF > 0:
        sub = paper_bg((0.88, 0.84, 0.76)).copy()
        header(t, 'ARGEL · 1577', t_fa - 0.2, B[4] - 0.5, 22)
        icon(sub, 'coins', 270, 190, 1.0, 1.0, t)
        tag(270, 262, 'DINERO PARA UNO', t, tw(19, 'dinero'), ease((t - tw(19, 'dinero') + 0.2) / 0.3), INK, 18)
        kw = ease(prog(t, tw(19, 'deja') - 0.2, B[4] + 0.4))
        person(sub, 170, 600, 250, 'cervantes', 1.0, t, 'stand', chain=True)
        person(sub, 370 + 160 * kw, 600, 240, 'rodrigo', 1.0 - 0.0 * kw, t, 'walk' if 0 < kw < 1 else 'stand')
        tag(170, 330, 'MIGUEL · SE QUEDA', t, t_he + 0.2, ease((t - t_he - 0.1) / 0.3), RED, 17)
        tag(380, 330, 'RODRIGO · LIBRE', t, t_he - 0.1, ease((t - t_he + 0.2) / 0.3), INK, 17)
        recre(t, 0.7)
        img = img * (1 - aF) + sub * aF
    return img


# ===================================================== S4 · cuatro fugas
ESC = [(21, 'feet', 'A PIE', 'HACIA ORÁN', 'guia', 'EL GUÍA HUYE'), (22, 'cave', 'UNA CUEVA', '5 MESES · 15 HOMBRES', 'traidor', 'DELATADOS'),
       (23, 'letter', 'CARTAS', 'AL GOBERNADOR DE ORÁN', 'detienen', 'MENSAJERO PRESO'), (24, 'ship', 'UNA FRAGATA', '60 HOMBRES', 'traicion', 'TRAICIÓN')]
CAPT = [(70, 590, 150), (150, 575, 140), (390, 575, 140), (470, 590, 150), (110, 520, 120), (430, 520, 120)]
def s4(t):
    t_i = st0(20); t_dv = st0(25); t_pa = st0(26); t_nu = st0(27)
    img = paper_bg((0.88, 0.84, 0.76)).copy()
    header(t, 'ARGEL · 1576-1579', B[4] + 0.3, t_dv - 0.4, 22)
    aG = 1 - ease(prog(t, t_dv - 0.4, t_dv + 0.1))
    if aG > 0:
        a = ease((t - t_i + 0.2) / 0.3) * aG
        rect(40, 150, 500, 232, None, 0.95 * a, 0.3); ov('4', 100, 191, 70, RED, a, 'c'); ov('INTENTOS DE FUGA', 300, 191, 32, INK, a, 'c', n=tn('INTENTOS DE FUGA', t, tw(20, 'escapar'), 18))
        for k, (si, ic, l1, l2, wo, res) in enumerate(ESC):
            tc = st0(si)
            if t < tc - 0.3: continue
            ac = ease((t - tc + 0.3) / 0.35) * aG
            nxt = st0(ESC[k + 1][0]) if k < 3 else t_dv
            act = 1.0 if t < nxt - 0.2 else 0.78
            x0 = 22 + (k % 2) * 258; y0 = 250 + (k // 2) * 196; yo = 14 * (1 - eo((t - tc + 0.3) / 0.4))
            panel(img, x0, y0 + yo, x0 + 238, y0 + 182 + yo, 0.96 * ac)
            icon(img, ic, x0 + 119, y0 + 66 + yo, 0.8 if ic in ('cave', 'ship') else 0.95, ac, t)
            ov('%d' % (k + 1), x0 + 22, y0 + 26 + yo, 30, RED, ac, 'c')
            ov(l1, x0 + 119, y0 + 134 + yo, 26, INK, ac * act, 'c', n=tn(l1, t, tc, 16))
            ov(l2, x0 + 119, y0 + 164 + yo, 15 if len(l2) > 18 else 18, INK, ac * act, 'c')
            tr = tw(si, wo)
            if t < t_dv + 0.1: sp(res, 40, RED, -8, x0 + 119, y0 + 92 + yo, tr - 0.05, 0.95 * aG)
            if act < 1: img[int(y0 + yo):int(y0 + 182 + yo), int(x0):int(x0 + 238)] *= 0.93
    # asume la culpa
    aC = ease(prog(t, t_dv - 0.3, t_dv + 0.2))
    if aC > 0:
        sub = paper_bg((0.84, 0.80, 0.72)).copy()
        for (cx, cy, ch_) in sorted(CAPT, key=lambda c: c[1]): person(sub, cx, cy, ch_, 'captive', 0.75, t)
        st_ = ease(prog(t, tw(25, 'asume') - 0.2, tw(25, 'culpa')))
        glow_roi(sub, 270, 420, 240, C3(1.0, 0.85, 0.6), 0.35 * st_, 1.6)
        person(sub, 270, 560 + 60 * st_, 250 + 60 * st_, 'cervantes', 1.0, t, 'stand', chain=t > t_pa)
        header(t, 'DOS VECES', t_dv, B[5] - 0.5, 14)
        tag(270, 196, 'ASUME TODA LA CULPA', t, tw(25, 'culpa') - 0.2, ease((t - tw(25, 'culpa') + 0.3) / 0.3) * (1 - ease(prog(t, t_pa - 0.3, t_pa))), RED, 22)
        if t > t_pa - 0.2:
            a = ease((t - t_pa + 0.2) / 0.3); panel(sub, 60, 150, 480, 300, 0.96 * a)
            icon(sub, 'stick', 130, 225, 0.9, a, t); icon(sub, 'stick', 150, 225, 0.9, a, t)
            n = int(2000 * ease(prog(t, tw(26, 'dos'), tw(26, 'palos') + 0.3)))
            ov('{:,}'.format(n).replace(',', '.'), 320, 206, 72, RED, a, 'c'); ov('PALOS DE CONDENA', 320, 270, 22, INK, a, 'c')
            if t > t_nu - 0.2:
                x_mark(sub, 320, 210, 60, INK, ease(prog(t, tw(27, 'nunca'), tw(27, 'nunca') + 0.5)), 8)
            sp('NUNCA SE CUMPLIÓ', 46, RED, -6, 300, 236, tw(27, 'cumple') - 0.1, 0.97)
        recre(t, 0.7)
        img = img * (1 - aC) + sub * aC
    return img


# ===================================================== S5 · rescate
C5M = (15.0, 40.6)
ROUTE_CON = [ARGEL, (6.0, 37.6), (9.5, 37.7), (12.0, 37.2), (15.5, 36.3), (19.5, 36.0), (22.6, 36.2), (24.2, 37.4), (25.3, 39.0), (26.2, 40.1), (27.4, 40.8), CONSTANT]
ROUTE_DEN = [ARGEL, (2.2, 37.6), (1.0, 38.4), DENIA]
def s5(t):
    t_d = st0(28); t_b = st0(29); t_c = tw(29, 'constantinopla'); t_al = st0(30); t_fr = st0(31); t_pa = tw(31, 'pagan'); t_tr = st0(32)
    R = lerp(1050.0, 1120.0, prog(t, B[5], B[6]))
    img, P = view(C5M, R, [1050.0, 2000.0]); img = img.copy(); img_hold[0] = img
    rc = route(P, ROUTE_CON); rd = route(P, ROUTE_DEN)
    maplabel(P, ARGEL, 'ARGEL', t, t_d, ease((t - t_d + 0.2) / 0.3), RED, 0, 30, 20, 6)
    stop = ease(prog(t, t_pa - 0.2, t_pa + 0.5))
    if t > t_b - 0.2:
        k = ease(prog(t, tw(29, 'llevara') - 0.2, t_c + 0.8)); fadeR = 1 - 0.75 * stop
        dashed(img, rc, RED, 0.9 * fadeR, 3, 9, 6, upto=k)
        kg = 0.05 * ease(prog(t, t_b, t_fr)) * (1 - stop)
        if t < t_tr:
            x, y, tx, ty = along(rc, kg); galley(img, x + 10, y + 4, 44, 1, t, 1.0 - ease(prog(t, t_tr - 0.5, t_tr)), 'cors')
        if t > t_c - 0.2:
            maplabel(P, CONSTANT, 'CONSTANTINOPLA', t, t_c, ease((t - t_c + 0.2) / 0.3) * fadeR, RED, -60, -34, 18, 6)
        if t > t_al - 0.2:
            x, y = P.pt(*CONSTANT); a = win(t, t_al - 0.2, t_fr)
            pulse(img, x, y, t, RED, a, 8, 56, 1.0, 3, 2)
            sp('SIN RETORNO', 40, RED, -6, x - 110, y + 60, tw(30, 'imposible') - 0.1, 0.95 * (1 - ease(prog(t, t_fr - 0.3, t_fr))))
    # frailes trinitarios
    if t > t_fr - 0.3:
        a = win(t, t_fr - 0.3, t_tr - 0.2); panel(img, 270, 330, 520, 636, 0.96 * a)
        person(img, 340, 590, 200, 'friar', a, t); person(img, 452, 590, 190, 'friar', a, t + 0.3)
        ov('FRAILES TRINITARIOS', 395, 364, 20, INK, a, 'c', n=tn('FRAILES TRINITARIOS', t, tw(31, 'frailes'), 16))
        sp('RESCATE PAGADO', 40, GREENI, -6, 395, 470, t_pa - 0.05, 0.97 * (1 - ease(prog(t, t_tr - 0.4, t_tr))))
    # vuelta a España
    if t > t_tr - 0.3:
        k = ease(prog(t, t_tr - 0.3, tw(32, 'espana') + 0.4))
        solid(img, rd, BLUE, 0.95, 4, upto=k)
        x, y, _, _ = along(rd, k); galley(img, x, y, 40, -1, t, ease((t - t_tr + 0.3) / 0.3), 'cris')
        maplabel(P, DENIA, 'DENIA · OCT. 1580', t, tw(32, 'espana'), ease((t - tw(32, 'espana') + 0.1) / 0.3), BLUE, 70, -30, 17, 6)
        for k_, (lab, sub, wd) in enumerate((('5 AÑOS', 'CAUTIVO', 'cinco'), ('33 AÑOS', 'DE EDAD', 'treinta'), ('NADA', 'MÁS', 'nada'))):
            tc = tw(32, wd)
            if t > tc - 0.25:
                ac = ease((t - tc + 0.25) / 0.3); x0 = 22 + k_ * 172; yo = 12 * (1 - eo((t - tc + 0.25) / 0.35))
                panel(img, x0, 440 + yo, x0 + 160, 560 + yo, 0.96 * ac)
                ov(lab, x0 + 80, 488 + yo, 36, RED if k_ == 2 else INK, ac, 'c'); ov(sub, x0 + 80, 532 + yo, 22, INK, ac, 'c')
    header(t, '19 DE SEPTIEMBRE DE 1580', t_d - 0.05, t_fr - 0.4, 24)
    header(t, 'EL RESCATE', t_fr, t_tr - 0.4, 16)
    header(t, 'DE VUELTA A ESPAÑA', t_tr, B[6] - 0.5, 20)
    return img


# ===================================================== S6 · recaudador, cárcel y Quijote
def bars_overlay(img, k, a=1.0):
    if k <= 0: return
    m = mk(); n = 7
    for j in range(n):
        x = 40 + j * (460 / (n - 1)); y1 = -20 + (H * 0.75) * k
        _L(m, [(x, -20), (x, y1)], 14)
    _L(m, [(20, (H * 0.75) * k - 160), (520, (H * 0.75) * k - 160)], 12)
    sh = cv2.GaussianBlur(_fm(m, 0.0), (0, 0), 6); img *= (1 - 0.35 * a * np.roll(sh, 8, 1))[..., None]
    paint(img, m, C3(0.12, 0.11, 0.11), a, 0.6); over(img, _fm(m, 0.5) * ((XX % 14) < 3), C3(0.45, 0.45, 0.46), 0.5 * a)

def cell_scene(t, k_bars=0.0, quote=False):
    img = cell_img()
    person(img, 210, 640, 330, 'writer', 1.0, t, 'write'); desk(img, 222, 486, 270, 1.0, t)
    img = Cam(1.0 + 0.04 * math.sin(t * 0.2), 0, 0, 270, 420).apply(img)
    bars_overlay(img, k_bars, 1.0)
    return img

def s6(t):
    t_h = st0(33); t_r = tw(33, 'recaudador'); t_97 = st0(34); t_cu = tw(34, 'cuentas'); t_ca = tw(34, 'carcel'); t_05 = st0(35); t_pu = tw(35, 'publica'); t_ex = st0(36); t_pr = st0(37); t_mu = st0(38)
    img = paper_bg().copy()
    # A · de héroe a recaudador
    aA = 1 - ease(prog(t, t_ca - 0.4, t_ca + 0.1))
    if aA > 0:
        header(t, 'ANDALUCÍA · 1587', t_h - 0.1, t_97 - 0.3, 22)
        header(t, '1597', t_97, t_ca - 0.3, 10)
        a1 = ease((t - tw(33, 'heroe') + 0.2) / 0.3)
        panel(img, 22, 170, 252, 420, 0.96 * a1); icon(img, 'helmet', 137, 260, 1.4, a1, t)
        ov('HÉROE', 137, 356, 30, INK, a1, 'c'); ov('DE LEPANTO', 137, 394, 22, INK, a1, 'c')
        if t > t_r - 0.4:
            a2 = ease((t - t_r + 0.4) / 0.3); arrow(img, (230, 300), (310, 300), RED, a2, 6, 0.4)
            panel(img, 288, 170, 518, 420, 0.96 * a2); icon(img, 'wheat', 360, 270, 1.0, a2, t); icon(img, 'ledger', 452, 280, 0.75, a2, t)
            ov('RECAUDADOR', 403, 356, 26, RED, a2, 'c', n=tn('RECAUDADOR', t, t_r, 14)); ov('DE IMPUESTOS', 403, 394, 22, INK, a2, 'c')
        if t > t_97 - 0.2:
            a3 = ease((t - t_97 + 0.2) / 0.3); panel(img, 90, 446, 450, 636, 0.96 * a3); icon(img, 'ledger', 170, 540, 1.1, a3, t)
            ov('CUENTAS', 330, 506, 32, INK, a3, 'c', n=tn('CUENTAS', t, t_cu, 12))
            if t > t_cu: x_mark(img, 170, 540, 40, RED, ease((t - t_cu) / 0.5), 6)
            if t < t_ca: sp('DESCUADRE', 34, RED, -6, 330, 570, t_cu + 0.25, 0.95 * (1 - ease(prog(t, t_ca - 0.4, t_ca - 0.05))))
    if aA < 1 and t < t_pr:
        img = img * aA + cell_scene(t, ease(prog(t, t_ca - 0.1, t_ca + 0.5))) * (1 - aA)
    if aA < 1 and t < t_05 - 0.2:
        header(t, 'CÁRCEL REAL DE SEVILLA · 1597', t_ca, t_05 - 0.4, 24); recre(t, 0.7, CREAM)
    # B · 1605
    aB = win(t, t_05 - 0.4, t_pr - 0.3, 0.4, 0.4)
    if aB > 0:
        sub = desk_bg(t); img = img * (1 - aB) + sub * aB
        header(t, 'MADRID · 1605', t_05, t_pr - 0.5, 22)
        photo('portada.jpg', 270, 362, 244, -3.0, t_pu - 0.1, t_pr - 0.35, 'PRIMERA EDICIÓN · 1605')
        if t < t_pr - 0.2: sp('ÉXITO INMEDIATO', 56, RED, -6, 270, 612, tw(36, 'exito') - 0.05, 0.97 * (1 - ease(prog(t, t_pr - 0.6, t_pr - 0.25))))
    # C · el prólogo
    aC = ease(prog(t, t_pr - 0.4, t_pr))
    if aC > 0:
        sub = cell_scene(t, 1.0) * 0.55
        a = ease((t - t_pr + 0.2) / 0.4)
        panel(sub, 30, 170, 510, 470, 0.95 * a)
        ov('EN EL PRÓLOGO DEL QUIJOTE:', 270, 206, 20, INK, a, 'c', n=tn('EN EL PRÓLOGO DEL QUIJOTE:', t, t_pr, 20))
        L1 = '«SE ENGENDRÓ'; L2 = 'EN UNA CÁRCEL»'
        ov(L1, 270, 270, 42, INK, a, 'c', n=tn(L1, t, tw(37, 'se', 1) if False else tw(37, 'engendro') - 0.25, 13))
        ov(L2, 270, 340, 42, RED, a, 'c', n=tn(L2, t, tw(37, 'carcel') - 0.35, 13))
        ov('CERVANTES · QUIJOTE I, PRÓLOGO (1605)', 270, 420, 15, INK, a * ease((t - tw(37, 'carcel')) / 0.4), 'c')
        header(t, 'EL PRÓLOGO', t_pr, B[7] - 0.5, 14)
        if t > t_mu - 0.2: tag(270, 540, '¿LA DE SEVILLA? · TEORÍA', t, tw(38, 'sevilla') - 0.4, ease((t - t_mu + 0.2) / 0.3), RED, 20)
        img = img * (1 - aC) + sub * aC
    return img


# ===================================================== S7 · cierre
def s7(t):
    t_c = st0(39); t_es = tw(39, 'escrito'); t_m = st0(40); t_ma = tw(40, 'manco'); t_no = tw(40, 'novela'); t_q = st0(41); t_su = tw(42, 'suscribete'); t_pa = tw(42, 'descubrir')
    # A · caballero y molinos
    aA = 1 - ease(prog(t, t_es - 0.4, t_es + 0.1))
    img = None
    if aA > 0:
        sub = field_img(520, 0.85)
        windmill(sub, 300, 520, 1.25, t); windmill(sub, 430, 506, 0.85, t + 1.3); windmill(sub, 505, 498, 0.6, t + 2.1)
        kx = lerp(20, 170, ease(prog(t, B[7], t_es)))
        knight(sub, kx, 600, 1.4, t)
        sub = Cam(1.0 + 0.04 * prog(t, B[7], t_es), 0, 0, 270, 520).apply(sub)
        header(t, 'GIGANTES IMAGINARIOS', t_c, t_es - 0.4, 18)
        img = sub
    aB = win(t, t_es - 0.4, t_m - 0.2, 0.4, 0.4)
    if aB > 0:
        sub = sea_battle(t, 1.0, 0.45)
        header(t, 'LEPANTO · 1571', t_es, t_m - 0.4, 18)
        img = sub if img is None else img * (1 - aB) + sub * aB
    if t > t_es - 0.4 or img is None: pass
    aC = ease(prog(t, t_m - 0.4, t_m))
    if aC > 0:
        sub = desk_bg(t)
        a = 1 - ease(prog(t, t_q - 0.3, t_q + 0.2))
        photo('retrato.png', 270, 330, 330, -2.0, t_m - 0.05, t_q - 0.1, 'MIGUEL DE CERVANTES (1547-1616)')
        if t < t_q + 0.2:
            sp('EL MANCO DE LEPANTO', 50, RED, -5, 270, 520, t_ma - 0.1, 0.97 * a)
            if t > t_no - 0.2: tag(270, 604, 'LA NOVELA MÁS FAMOSA EN ESPAÑOL', t, t_no, ease((t - t_no + 0.2) / 0.3) * a, INK, 22)
        img = sub if img is None else img * (1 - aC) + sub * aC
    if t > t_q - 0.2:
        a = ease((t - t_q + 0.2) / 0.3) * (1 - ease((t - t_su + 0.4) / 0.4))
        if a > 0.003:
            rect(30, 170, 510, 300, None, 0.95 * a, 0.3)
            ov('¿QUÉ OTRO GENIO', 270, 214, 32, INK, a, 'c', n=tn('¿QUÉ OTRO GENIO', t, t_q, 14)); ov('ESCONDÍA UNA VIDA ASÍ?', 270, 262, 32, RED, a, 'c', n=tn('ESCONDÍA UNA VIDA ASÍ?', t, tw(41, 'escondia'), 16))
            ov('?', 270, 470 + 8 * math.sin(t * 2), 260, RED, a * 0.9, 'c', sh=0.4)
    if t > t_su - 0.1:
        a = ease((t - t_su + 0.1) / 0.4)
        rect(26, 150, 514, 226, RED, 0.96 * a, 0.35)
        ov('SUSCRÍBETE', 270, 188, 44, CREAM, a, 'c', n=tn('SUSCRÍBETE', t, t_su, 12))
        if t > t_pa - 0.1:
            a2 = ease((t - t_pa + 0.1) / 0.4); rect(26, 240, 514, 322, None, 0.95 * a2, 0.3)
            ov('PARA DESCUBRIR MÁS HISTORIAS', 270, 268, 20, INK, a2, 'c', n=tn('PARA DESCUBRIR MÁS HISTORIAS', t, t_pa, 18)); ov('COMO ESTA', 270, 302, 28, RED, a2, 'c', n=tn('COMO ESTA', t, tw(42, 'como'), 12))
    if t < t_m: recre(t, 0.75, CREAM)
    return img

SC = [s0, s1, s2, s3, s4, s5, s6, s7]
