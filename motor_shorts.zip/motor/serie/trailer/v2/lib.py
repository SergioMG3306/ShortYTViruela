import numpy as np, cv2, math
from PIL import Image, ImageDraw, ImageFont
W,H=540,960; FW,FH=1080,1920
YY,XX=np.mgrid[0:H,0:W].astype(np.float32)
def cl(x,a=0.0,b=1.0): return min(b,max(a,x))
def prog(t,a,b): return cl((t-a)/(b-a))
def ease(x): x=cl(x); return x*x*(3-2*x)
def eo(x): x=cl(x); return 1-(1-x)**3
def ei(x): x=cl(x); return x**3
def hs(i,s): return np.abs(np.modf(np.sin(np.asarray(i,np.float64)*127.1+s*311.7)*43758.5453)[0]).astype(np.float32)
def vgrad(stops):
    ys=np.linspace(0,1,H); ps=[s[0] for s in stops]; cols=np.array([s[1] for s in stops],np.float32)
    out=np.stack([np.interp(ys,ps,cols[:,c]) for c in range(3)],1).astype(np.float32)/255
    return np.repeat(out[:,None,:],W,1).copy()
def radial(cx,cy,r,power=2.0,sy=1.0):
    d=np.sqrt((XX-cx)**2+((YY-cy)/sy)**2)/max(r,1e-3); return np.clip(1-d,0,1)**power
def glow(img,cx,cy,r,col,k=1.0,power=2.0,sy=1.0): img+=radial(cx,cy,r,power,sy)[...,None]*(np.array(col,np.float32)/255*k)
def splat(img,xs,ys,cols,sig,k=1.0):
    if len(xs)==0: return
    A=np.zeros((H,W,3),np.float32); xi=np.clip(np.asarray(xs).astype(int),0,W-1); yi=np.clip(np.asarray(ys).astype(int),0,H-1)
    np.add.at(A,(yi,xi),np.asarray(cols,np.float32)); img+=np.minimum(cv2.GaussianBlur(A,(0,0),sig)*(2*math.pi*sig*sig*k),1.6)
def fractal(seed,scales=(4,8,16,32,64),w=None):
    rs=np.random.RandomState(seed); out=np.zeros((H,W),np.float32); amp=1.0; tot=0
    for s in scales:
        a=rs.rand(max(2,H//s),max(2,W//s)).astype(np.float32); out+=cv2.resize(a,(W,H),interpolation=cv2.INTER_CUBIC)*amp; tot+=amp; amp*=0.55
    return out/tot
def paste_rgba(img,spr,mask,cx,cy,alpha=1.0):
    h,w=mask.shape; x0=int(cx-w/2); y0=int(cy-h/2); xa=max(0,x0); ya=max(0,y0); xb=min(W,x0+w); yb=min(H,y0+h)
    if xa>=xb or ya>=yb: return
    s=spr[ya-y0:yb-y0,xa-x0:xb-x0]; m=(mask[ya-y0:yb-y0,xa-x0:xb-x0]*alpha)[...,None]
    img[ya:yb,xa:xb]=img[ya:yb,xa:xb]*(1-m)+s*m
_rc={}
def rock(R,seed,base):
    k=(R,seed,base)
    if k in _rc: return _rc[k]
    rs=np.random.RandomState(seed); n=2*R+10; ang=np.linspace(0,2*np.pi,90,endpoint=False)
    rad=R*(0.8+0.10*np.sin(3*ang+rs.rand()*6)+0.07*np.sin(5*ang+rs.rand()*6)+0.025*rs.randn(90))
    pts=np.stack([R+5+rad*np.cos(ang),R+5+rad*np.sin(ang)],1).astype(np.int32); m=np.zeros((n,n),np.uint8); cv2.fillPoly(m,[pts],255)
    d=cv2.distanceTransform(m,cv2.DIST_L2,5); h=np.sqrt(np.clip(d/max(d.max(),1),0,1))*R*0.7
    h+=cv2.GaussianBlur(rs.randn(n,n).astype(np.float32),(0,0),R/14)*R*0.16+cv2.GaussianBlur(rs.randn(n,n).astype(np.float32),(0,0),1.3)*R*0.035
    gy,gx=np.gradient(cv2.GaussianBlur(h,(0,0),1.0)); nz=1/np.sqrt(1+gx**2+gy**2); nx=-gx*nz; ny=-gy*nz
    L=np.array([-0.45,-0.65,0.6]); L/=np.linalg.norm(L); lam=np.clip(nx*L[0]+ny*L[1]+nz*L[2],0,1)
    col=np.array(base,np.float32)/255; img=col[None,None,:]*(0.18+1.0*lam[...,None]**1.2); img+=0.12*np.clip(1-nz*1.3,0,1)[...,None]*np.array([0.5,0.6,0.9],np.float32)
    _rc[k]=(np.clip(img,0,1.2).astype(np.float32),cv2.GaussianBlur(m.astype(np.float32)/255,(0,0),0.9)); return _rc[k]
def hand_mask(S,flip=False):
    m=np.zeros((S,S),np.uint8); c=S//2
    cv2.ellipse(m,(c,int(S*0.62)),(int(S*0.19),int(S*0.20)),0,0,360,255,-1); cv2.rectangle(m,(int(c-S*0.13),int(S*0.7)),(int(c+S*0.13),S-1),255,-1)
    top=int(S*0.50)
    for dx,ang,ln,th in ((-0.125,-8,0.36,0.072),(-0.042,-2,0.41,0.075),(0.042,3,0.37,0.072),(0.12,10,0.29,0.066)):
        x0=c+dx*S; a=math.radians(ang); x1=x0+math.sin(a)*ln*S; y1=top-math.cos(a)*ln*S
        cv2.line(m,(int(x0),top),(int(x1),int(y1)),255,int(th*S),cv2.LINE_AA); cv2.circle(m,(int(x1),int(y1)),int(th*S/2),255,-1,cv2.LINE_AA)
    x0=c-0.16*S; y0=S*0.62; a=math.radians(-62); x1=x0+math.sin(a)*0.27*S; y1=y0-math.cos(a)*0.27*S
    cv2.line(m,(int(x0),int(y0)),(int(x1),int(y1)),255,int(0.085*S),cv2.LINE_AA); cv2.circle(m,(int(x1),int(y1)),int(0.0425*S),255,-1,cv2.LINE_AA)
    if flip: m=m[:,::-1].copy()
    return cv2.GaussianBlur(m.astype(np.float32)/255,(0,0),0.8)
# ---------- texto a pantalla completa
FB='/usr/share/fonts/truetype/google-fonts/Poppins-Bold.ttf'
_fc={}; _tc={}
def font(sz):
    if sz not in _fc: _fc[sz]=ImageFont.truetype(FB,sz)
    return _fc[sz]
def text_sprite(text,sz,top,bot,glowc=None,stroke=0,track=0,strokec=(10,8,20)):
    k=(text,sz,top,bot,glowc,stroke,track)
    if k in _tc: return _tc[k]
    f=font(sz); widths=[f.getlength(ch)+track for ch in text]; tw=int(sum(widths)); pad=int(sz*0.6)+stroke
    th=int(sz*1.5); im=Image.new('L',(tw+2*pad,th+2*pad),0); d=ImageDraw.Draw(im); x=pad
    for ch,w_ in zip(text,widths): d.text((x,pad),ch,font=f,fill=255); x+=w_
    a=np.asarray(im,np.float32)/255; ys=np.linspace(0,1,a.shape[0])[:,None,None]
    col=np.array(top,np.float32)/255*(1-ys)+np.array(bot,np.float32)/255*ys; rgb=np.repeat(col,a.shape[1],1)
    alpha=a
    if stroke:
        im2=Image.new('L',im.size,0); d2=ImageDraw.Draw(im2); x=pad
        for ch,w_ in zip(text,widths): d2.text((x,pad),ch,font=f,fill=255,stroke_width=stroke,stroke_fill=255); x+=w_
        s=np.asarray(im2,np.float32)/255; rgb=rgb*a[...,None]+np.array(strokec,np.float32)/255*(1-a[...,None]); alpha=s
    g=None
    if glowc: g=cv2.GaussianBlur(alpha,(0,0),sz*0.16)[...,None]*np.array(glowc,np.float32)/255
    _tc[k]=(rgb.astype(np.float32),alpha.astype(np.float32),g); return _tc[k]
def blit(fr,spr,cx,cy,alpha=1.0,scale=1.0,glowk=1.0):
    rgb,a,g=spr
    if scale!=1.0:
        nw=max(2,int(rgb.shape[1]*scale)); nh=max(2,int(rgb.shape[0]*scale)); rgb=cv2.resize(rgb,(nw,nh),interpolation=cv2.INTER_LINEAR); a=cv2.resize(a,(nw,nh),interpolation=cv2.INTER_LINEAR)
        if g is not None: g=cv2.resize(g,(nw,nh),interpolation=cv2.INTER_LINEAR)
    h,w=a.shape; x0=int(cx-w/2); y0=int(cy-h/2); xa=max(0,x0); ya=max(0,y0); xb=min(FW,x0+w); yb=min(FH,y0+h)
    if xa>=xb or ya>=yb: return
    sl=(slice(ya,yb),slice(xa,xb)); ss=(slice(ya-y0,yb-y0),slice(xa-x0,xb-x0))
    if g is not None: fr[sl]+=g[ss]*(alpha*glowk*0.9)
    m=(a[ss]*alpha)[...,None]; fr[sl]=fr[sl]*(1-m)+rgb[ss]*m
