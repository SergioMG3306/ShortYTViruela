import os, sys
os.environ['PAL_DIR'] = '/home/claude/serie/vascos'
sys.path.insert(0, '/home/claude/serie/vascos'); sys.path.insert(0, '/home/claude/serie/cervantes')
from cv_lib import *
from cv_lib import _f, _d
import cv_lib as L
L.FOTOS = '/home/claude/serie/vascos/fotos/'
from cv_scenes import tn, fadeio, win, panel, paper_bg, vignette, white_flash, header, recre, tag, shake, ring, arrow, desk_bg
from cv_art import mk, paint, outline, person, x_mark, sea_img, icon, _R, WHITE, DARK, STEEL
from cv_art import waves as sea_waves
from cv_artbase import _L, _P, _C, _E, _fm, WOOD, OCHRE, BONE, SKIN, STONE
from cv_geo import level, EQ, route
from cv_geomap import dashed, along, pin, pulse
from vs_art import SIL, silhouette, embers, smoke_puffs, grass_fg, flag, gull, moving_map, woodcut_kb, room_candles, candle_s
from cv_art import desk

GREEN_ = C3(0.16, 0.42, 0.30)
BASQUE = (-2.0, 43.35); WESTF = (-22.6, 65.9); ISL_C = (-18.5, 64.9)

def lerpk(t, keys):
    if t <= keys[0][0]: return keys[0][1]
    for (t0, v0), (t1, v1) in zip(keys[:-1], keys[1:]):
        if t <= t1: return v0 + (v1 - v0) * ease((t - t0) / max(1e-6, t1 - t0))
    return keys[-1][1]

def flash(img, t, t0, dur=0.5, k=1.0):
    d = t - t0
    if 0 <= d < dur: white_flash(img, k * (1 - d / dur) ** 2)

def counter(x, y, w, big, small, a, col=RED):
    if a <= 0.003: return
    rect(x - w / 2, y - 52, x + w / 2, y + 52, None, 0.95 * a, 0.35); ov(big, x, y - 10, 62, col, a, 'c'); ov(small, x, y + 34, 18, INK, a, 'c')

# ---------------------------------------------------------------- dibujo propio
def nao(img, x, y, L_, t, a=1.0, roll=0.0, broken=0.0, facing=1, sails=1.0):
    """nao ballenera vasca (casco redondeado, castillos y tres palos con velas cuadras)."""
    u = L_ / 100.0
    def P(px, py):
        ca, sa = math.cos(roll), math.sin(roll); qx, qy = px * u * facing, py * u
        return (x + qx * ca - qy * sa, y + qx * sa + qy * ca)
    def PP(pts): return [P(*q) for q in pts]
    hull = [(-50, -16), (-38, -12), (30, -12), (48, -20), (52, -14), (42, 2), (28, 9), (-30, 9), (-46, 0)]
    m = mk(); _P(m, PP(hull)); shadow(img, _fm(m), 0.2 * a, (2, 3), 2.0); paint(img, m, WOOD * 0.95, a)
    cs = mk(); _P(cs, PP([(-50, -16), (-50, -30), (-28, -28), (-28, -12)])); _P(cs, PP([(30, -12), (30, -24), (48, -26), (48, -20)])); paint(img, cs, WOOD * 1.2, a)
    bd = mk(); _L(bd, PP([(-46, -4), (44, -4)]), max(1, 2 * u)); paint(img, bd, C3(0.55, 0.18, 0.12), a)
    masts = [(-16, 66), (8, 78), (34, 52)]
    for k, (mx, mh) in enumerate(masts):
        if broken > 0 and k == 1: mh = mh * (1 - 0.6 * broken)
        mm = mk(); tilt = (0.5 * broken if k == 1 else 0) * 40
        _L(mm, PP([(mx, -12), (mx + tilt, -12 - mh)]), max(1, 1.6 * u)); paint(img, mm, WOOD * 0.7, a)
        if sails > 0 and not (broken > 0.3 and k == 1):
            sm = mk(); bw = 14 + 3 * k
            for (y0, y1, s) in ((-12 - mh * 0.85, -12 - mh * 0.55, 0.8), (-12 - mh * 0.5, -12 - mh * 0.12, 1.0)):
                bul = 3 * math.sin(t * 2 + k)
                _P(sm, PP([(mx - bw * s, y0), (mx + bw * s, y0), (mx + bw * s + bul, y1), (mx - bw * s + bul, y1)]))
            paint(img, sm, BONE, a * sails); outline(img, sm, a * sails, 0.5, 0.8)
            cr = mk(); _L(cr, PP([(mx, -12 - mh * 0.45), (mx, -12 - mh * 0.18)]), max(1, 2.5 * u)); _L(cr, PP([(mx - 8, -12 - mh * 0.32), (mx + 8, -12 - mh * 0.32)]), max(1, 2.5 * u)); paint(img, cr, RED, a * sails * 0.85)
        fl = mk(); _P(fl, PP([(mx + tilt, -12 - mh), (mx + tilt + 10 + math.sin(t * 6) * 2, -12 - mh + 2), (mx + tilt, -12 - mh + 5)])); paint(img, fl, RED, a)
    outline(img, cv2.max(m, cs), a, 0.8, 0.9)


def storm_sea(t, wild=1.0, dark=0.7):
    img = sea_img(330, 0.0)
    g = np.clip(YY / 330.0, 0, 1)[..., None]
    sky = C3(0.16, 0.18, 0.24) * (1 - g) + C3(0.36, 0.38, 0.42) * g
    m = (YY < 330).astype(F32)[..., None]
    img = img * (1 - m * dark) + sky * m * dark
    img[330:] *= C3(0.55, 0.62, 0.68)
    sea_waves(img, t * (1 + wild), 330, 1.0, int(70 + 80 * wild), 5)
    # crestas grandes
    xs = np.arange(W, dtype=F32)
    for k in range(4):
        yb = 380 + k * 70; amp = (10 + 12 * k) * wild
        yy = yb + amp * np.sin(xs * (0.018 - 0.002 * k) + t * (1.6 + 0.3 * k) + k)
        mm = np.clip(YY - yy[None, :], 0, 1) * np.clip(yy[None, :] + 60 - YY, 0, 1)
        over(img, mm, C3(0.20, 0.30, 0.36), 0.5)
        crest = np.clip(1 - np.abs(YY - yy[None, :]) / 2.5, 0, 1) * (np.sin(xs * 0.05 + t * 3 + k)[None, :] > 0.2)
        over(img, crest, C3(0.85, 0.90, 0.92), 0.7)
    # lluvia
    rs = np.random.RandomState(int(t * 24) % 997); rm = mk()
    for j in range(int(140 * wild)):
        x0 = rs.rand() * (W + 100) - 50; y0 = rs.rand() * H
        _L(rm, [(x0, y0), (x0 - 9, y0 + 26)], 1)
    paint(img, rm, C3(0.80, 0.85, 0.90), 0.35 * wild, 0.4)
    return img


def rocks(img, a=1.0):
    m = mk(); _P(m, [(400, 600), (430, 420), (470, 380), (520, 360), (560, 380), (560, 600)]); _P(m, [(330, 600), (350, 520), (390, 500), (420, 600)])
    paint(img, m, C3(0.14, 0.13, 0.13), a); over(img, _fm(m) * (((XX + YY * 0.5) % 9) < 1.4), C3(0.3, 0.3, 0.32), 0.3 * a)


_FC = {}
def fjord_night(t):
    if 'f' not in _FC:
        g = np.clip(YY / 420.0, 0, 1)[..., None]
        img = (C3(0.03, 0.05, 0.12) * (1 - g) + C3(0.10, 0.14, 0.24) * g).astype(F32)
        rs = np.random.RandomState(4)
        for j in range(160):
            x, y = rs.rand() * W, rs.rand() * 300; glow_roi(img, x, y, 2.5, C3(1, 1, 1), 0.6 * rs.rand(), 1.0)
        m1 = mk(); _P(m1, [(-20, 420), (60, 300), (140, 250), (230, 320), (300, 260), (380, 210), (470, 300), (560, 260), (560, 470), (-20, 470)]); paint(img, m1, C3(0.08, 0.10, 0.16), 1.0)
        sn = mk(); _P(sn, [(120, 262), (140, 250), (160, 262), (150, 270)]); _P(sn, [(360, 222), (380, 210), (400, 225), (385, 232)]); paint(img, sn, C3(0.55, 0.60, 0.70), 0.8)
        wat = (YY > 470).astype(F32); over(img, wat, C3(0.05, 0.08, 0.14), 1.0)
        over(img, wat * (np.sin(YY * 0.6 + XX * 0.02) > 0.9), C3(0.3, 0.35, 0.5), 0.3)
        sh = mk(); _P(sh, [(-20, 470), (560, 455), (560, 520), (-20, 540)]); paint(img, sh, C3(0.12, 0.11, 0.10), 1.0)
        # cabaña de turba
        hu = mk(); _P(hu, [(300, 480), (430, 480), (430, 430), (365, 395), (300, 430)]); paint(img, hu, C3(0.20, 0.17, 0.12), 1.0)
        rf = mk(); _P(rf, [(290, 433), (365, 388), (440, 433), (430, 440), (365, 402), (300, 440)]); paint(img, rf, C3(0.22, 0.30, 0.16), 1.0)
        dr = mk(); _P(dr, [(355, 480), (378, 480), (378, 448), (355, 448)]); paint(img, dr, C3(0.06, 0.05, 0.04), 1.0)
        _FC['f'] = np.clip(img, 0, 1).astype(F32)
    return _FC['f'].copy()


def torch(img, x, y, t, a=1.0, k=0):
    m = mk(); _L(m, [(x, y), (x + 4, y - 34)], 3); paint(img, m, WOOD, a)
    fk = 1 + 0.2 * math.sin(t * 17 + k) * math.sin(t * 7 + k * 2)
    f = mk(); _E(f, x + 4, y - 42, 5, 10 * fk); paint(img, f, C3(1.0, 0.70, 0.25), a)
    glow_roi(img, x + 4, y - 42, 70, C3(1.0, 0.55, 0.2), 0.55 * a * fk, 2.0)


def parchment(img, x0, y0, x1, y1, a=1.0):
    m = mk(); rs = np.random.RandomState(3)
    pts = [(x0 + rs.rand() * 6, y0 + rs.rand() * 6), (x1 - rs.rand() * 6, y0 + rs.rand() * 6), (x1 - rs.rand() * 6, y1 - rs.rand() * 6), (x0 + rs.rand() * 6, y1 - rs.rand() * 6)]
    _P(m, pts); shadow(img, _fm(m), 0.35 * a, (5, 7), 6.0); paint(img, m, C3(0.86, 0.78, 0.60), a)
    over(img, _fm(m) * (fractal(8, (10, 30, 80)) > 0.55), C3(0.70, 0.58, 0.40), 0.35 * a)
    e = mk(); _P(e, pts); outline(img, e, a, 0.5, 2.0)


def stele(img, x, y, s, a=1.0):
    m = mk(); _P(m, [(x - 40 * s, y), (x + 40 * s, y), (x + 34 * s, y - 150 * s), (x, y - 170 * s), (x - 34 * s, y - 150 * s)]); paint(img, m, C3(0.52, 0.52, 0.55), a)
    over(img, _fm(m) * (fractal(9, (6, 14)) > 0.6), C3(0.4, 0.4, 0.44), 0.4 * a); outline(img, m, a, 0.7, 1.0)
    p = mk(); _P(p, [(x - 24 * s, y - 120 * s), (x + 24 * s, y - 120 * s), (x + 24 * s, y - 70 * s), (x - 24 * s, y - 70 * s)]); paint(img, p, C3(0.78, 0.66, 0.30), a)


# ===================================================== S0 · gancho
def decree_card(img, t, t0, a, stamp_t, x0=60, y0=170, x1=480, y1=560):
    parchment(img, x0, y0, x1, y1, a)
    ls = ['DECRETO · SÚÐAVÍK · 1615', 'LOS VASCOS QUEDAN', 'PROSCRITOS']
    ov(ls[0], (x0 + x1) / 2, y0 + 56, 20, INK, a, 'c', n=tn(ls[0], t, t0, 24))
    for k in range(5):
        yy = y0 + 110 + k * 26; m = mk(); _L(m, [(x0 + 40, yy), (x1 - 40 - 30 * (k % 2), yy)], 2); paint(img, m, INK, 0.35 * a * ease((t - t0 - 0.3 - 0.08 * k) / 0.3))
    ov(ls[1], (x0 + x1) / 2, y0 + 260, 24, INK, a, 'c', n=tn(ls[1], t, t0 + 0.5, 22))


def s0(t):
    t_ha = st0(0); t_ma = tw(0, 'matar'); t_na = st0(1); t_cu = tw(1, 'cuatrocientos')
    img = room_candles(t)
    desk(img, 270, 640, 520, 1.0, t, False)
    candle_s(img, 470, 600, 1.4, t); candle_s(img, 70, 610, 1.1, t + 2)
    cam = Cam(1.0 + 0.10 * ease(prog(t, 0, B[1])), 0, 8 * math.sin(t * 0.4), 270, 380)
    a = ease((t - 0.1) / 0.35)
    decree_card(img, t, 0.3, a, 1.3, 60, 150, 480, 580)
    # pluma escribiendo
    if t < 1.2:
        qx = 120 + 280 * ((t * 1.8) % 1.0); qy = 260 + 26 * int(t * 1.8); m = mk(); _L(m, [(qx, qy), (qx + 40, qy - 90)], 3); paint(img, m, C3(0.95, 0.93, 0.85), 1.0)
    img = cam.apply(img)
    header(t, 'ISLANDIA · 1615', 0.1, B[1] - 0.6, 18)
    sp('PROSCRITOS', 70, RED, -8, 270, 470, 1.25, 0.97)
    flash(img, t, 1.3, 0.2, 0.25)
    if t > t_ma - 0.3 and t < t_na: tag(270, 620, 'SE PERMITÍA MATAR VASCOS', t, t_ma - 0.2, win(t, t_ma - 0.3, t_na - 0.2), RED, 24)
    if t > t_ha + 0.5 and t < t_na: tag(270, 150, 'VIGENTE HASTA 2015', t, tw(0, '2015'), win(t, tw(0, '2015') - 0.1, t_na - 0.1), INK, 22)
    if t > t_na - 0.2:
        aa = ease((t - t_na + 0.2) / 0.3); yr = int(lerp(1615, 2015, ease(prog(t, t_cu - 0.4, t_cu + 1.2))))
        counter(270, 600, 300, str(yr), '400 AÑOS SIN ANULAR', aa)
    return img


# ===================================================== S1 · balleneros
ROUTE = [BASQUE, (-6.5, 45.2), (-11.0, 49.0), (-14.5, 54.5), (-17.5, 60.0), (-20.5, 63.6), WESTF]
def s1(t):
    t_y = st0(2); t_bl = tw(3, 'balleneros'); t_is = tw(3, 'islandia'); t_ac = tw(3, 'acuerdo')
    if t < t_bl - 0.15:
        # cámara que sigue a la nao desde el País Vasco hasta Islandia
        k = ease(prog(t, B[1] + 0.2, t_bl - 0.2))
        P0 = EQ(-12.0, 55.0, 1.0); pr = route(P0, ROUTE); x, y, tx, ty = along(pr, k)
        lon = -12.0 + (x - 270) / (np.radians(1) * math.cos(math.radians(38.0))); lat = 55.0 - (y - 330) / np.radians(1)
        R = 1500.0 - 300 * math.sin(math.pi * k)
        img, P = moving_map((lon, lat + 1.5), R)
        rt = route(P, ROUTE)
        dashed(img, rt, RED, 0.9, 3, 9, 6, upto=k)
        sx, sy, tx, ty = along(rt, k)
        wk = mk(); _L(wk, [(sx - tx * 30, sy - ty * 30 + 6), (sx, sy + 6)], 3); paint(img, wk, C3(0.95, 0.97, 0.98), 0.7)
        nao(img, sx, sy, 60, t, 1.0, 0.06 * math.sin(t * 2.4), facing=1 if tx >= 0 else -1)
        for (ll, lab, dy) in ((BASQUE, 'PAÍS VASCO', 32), (ISL_C, 'ISLANDIA', -36)):
            xx, yy = P.pt(*ll)
            if -60 < xx < 600 and -60 < yy < 1000: pin(img, xx, yy, RED, 1.0, 6); tag(xx, yy + dy, lab, t, B[1] + 0.3, ease((t - B[1] - 0.2) / 0.3), RED, 18)
        header(t, '1615', t_y - 0.1, t_bl - 0.5, 8)
        return img
    if t < t_is - 0.15:
        img = woodcut_kb('/home/claude/serie/vascos/fotos/ballenas.png', t, t_bl - 0.15, t_is, 2.3, 1.75, (0.28, 0.32), (0.52, 0.52))
        header(t, 'BALLENEROS VASCOS', t_bl, t_is - 0.4, 18)
        tag(270, 610, 'CAZA DE BALLENAS · GRABADO DE 1574', t, t_bl + 0.3, ease((t - t_bl - 0.2) / 0.3), INK, 18)
        return img
    a = ease((t - t_is + 0.15) / 0.3)
    if 'ort' not in _FC: _FC['ort'] = cv2.imread('/home/claude/serie/vascos/fotos/ortelius.jpg')[:, :, ::-1].astype(F32) / 255
    s_ = lerp(0.95, 1.35, ease(prog(t, t_is, B[2] + 0.7)))
    cxm, cym = lerp(330, 240, ease(prog(t, t_is, B[2])), ), lerp(320, 255, ease(prog(t, t_is, B[2])))
    M = np.float32([[s_, 0, 270 - s_ * cxm], [0, s_, 390 - s_ * cym]])
    img = cv2.warpAffine(_FC['ort'], M, (W, H), borderMode=cv2.BORDER_CONSTANT, borderValue=(0.85, 0.80, 0.68))
    hm = mk(); pts = [(60, 130), (300, 110), (430, 190), (420, 320), (330, 380), (160, 400), (60, 340)]
    _P(hm, [(270 + s_ * (x - cxm), 390 + s_ * (y - cym)) for x, y in pts]); over(img, _fm(hm, 4.0), RED, 0.40 * (0.7 + 0.3 * math.sin(t * 4)))
    sea_waves(img, t, 0, 0.0)
    header(t, 'FIORDOS DEL OESTE', t_is, B[2] - 0.4, 18)
    ov('MAPA DE ISLANDIA · ORTELIUS, 1590', 270, 640, 15, INK, 0.85, 'c')
    if t > t_ac - 0.2: tag(270, 600, 'ACUERDO CON LOS VECINOS', t, t_ac, ease((t - t_ac + 0.2) / 0.3), GREEN_, 22)
    return img


# ===================================================== S2 · tormenta
def big_wave_fg(img, t, k=1.0, y0=640):
    xs = np.arange(W, dtype=F32)
    top = y0 - 70 * k - 40 * k * np.sin(xs * 0.012 - t * 2.2) - 15 * np.sin(xs * 0.05 + t * 3.1)
    m = np.clip(YY - top[None, :], 0, 1)
    g = np.clip((YY - top[None, :]) / 160, 0, 1)
    col = C3(0.16, 0.25, 0.30) * (1 - g[..., None]) + C3(0.06, 0.10, 0.13) * g[..., None]
    img[:] = img * (1 - m[..., None]) + col * m[..., None]
    crest = np.clip(1 - np.abs(YY - top[None, :] - 3) / 4.0, 0, 1) * (np.sin(xs * 0.08 + t * 5)[None, :] > -0.3)
    over(img, crest, C3(0.85, 0.90, 0.92), 0.85)

def s2(t):
    t_se = st0(4); t_es = tw(4, 'estrella'); t_ro = tw(4, 'rocas'); t_oc = st0(5)
    wild = lerp(0.6, 1.5, ease(prog(t, B[2], t_es)))
    img = storm_sea(t, wild)
    ltn = [t_se + 0.2, t_es - 0.15, t_ro + 0.1, t_oc + 0.8]
    for lt in ltn: flash(img, t, lt, 0.22, 0.85)
    rocks(img)
    k = ease(prog(t, B[2], t_es))
    pieces = []
    for j, (x0, y0, L_) in enumerate(((150, 370, 110), (-10, 420, 160), (60, 500, 220))):
        x = x0 + (190 - 30 * j) * k; y = y0 + 14 * math.sin(t * 2.2 + j) * wild
        roll = 0.25 * math.sin(t * 1.9 + j) * wild
        tb = t_es + 0.25 * j; br = ease(prog(t, tb, tb + 0.7)); sink = 60 * ease(prog(t, tb + 0.4, t_oc + 1.0))
        nao(img, x + shake(t, tb, 7), y + sink, L_, t, 1.0 - 0.5 * ease(prog(t, tb + 0.5, t_oc + 1.5)), roll + 0.7 * br * (1 if j % 2 else -1), br)
        if t > tb: pieces.append((x + L_ * 0.4, y - L_ * 0.2, t - tb, j))
    # tablones y espuma en el choque
    rs = np.random.RandomState(5)
    for (px, py, d, j) in pieces:
        if d > 2.5: continue
        for q in range(10):
            vx = (rs.rand() - 0.2) * 260; vy = -120 - 220 * rs.rand(); xx = px + vx * d; yy = py + vy * d + 300 * d * d
            m = mk(); ang = d * 6 + q; L2 = 12 + 14 * rs.rand(); _L(m, [(xx - L2 * math.cos(ang), yy - L2 * math.sin(ang)), (xx + L2 * math.cos(ang), yy + L2 * math.sin(ang))], 4); paint(img, m, WOOD, 1.0)
        sp_ = [(px + 30 + (rs.rand() - 0.5) * 80 * (0.5 + d), py - 120 * d * rs.rand(), 3 + 4 * rs.rand()) for _ in range(30)]
        over(img, mcirc(sp_, 1.0), C3(0.9, 0.93, 0.95), 0.8 * max(0, 1 - d / 1.5))
    big_wave_fg(img, t, wild)
    ang = 2.5 * math.sin(t * 0.9) * wild
    Mr = cv2.getRotationMatrix2D((270, 420), ang, 1.06); Mr[0, 2] += shake(t, t_es, 12) + shake(t, t_es + 0.5, 8)
    img = cv2.warpAffine(img, Mr, (W, H), borderMode=cv2.BORDER_REFLECT)
    header(t, 'SEPTIEMBRE DE 1615', t_se - 0.1, t_oc - 0.4, 22)
    sp('¡CONTRA LAS ROCAS!', 46, RED, -6, 270, 210, t_ro + 0.35, 0.97 * (1 - ease(prog(t, t_oc - 0.2, t_oc + 0.2))))
    if t > t_oc - 0.2:
        aa = ease((t - t_oc + 0.2) / 0.3); counter(270, 220, 300, 'UNOS 80', 'NÁUFRAGOS ATRAPADOS', aa)
        bm = mk(); _P(bm, [(-10, 610), (320, 590), (360, 680), (-10, 680)]); paint(img, bm, C3(0.22, 0.20, 0.18), aa)
        for j in range(10): person(img, 26 + j * 30, 650, 72, 'captive', aa, t + j * 0.3, 'walk' if j % 3 == 0 else 'stand')
    recre(t, 0.7, CREAM)
    return img


# ===================================================== S3 · la matanza
def s3(t):
    t_pe = st0(6); t_oc = st0(7); t_at = tw(7, 'atacan'); t_ca = tw(7, 'catorce'); t_so = st0(8); t_di = st0(9); t_ar = tw(9, 'ari'); t_do = tw(9, 'doce'); t_pr = tw(9, 'proscritos'); t_ma = tw(9, 'matar'); t_un = st0(10); t_ve = tw(10, 'veinte')
    if t < t_di - 0.3:
        img = fjord_night(t)
        img = Cam(1.0 + 0.12 * ease(prog(t, B[3], t_di)), 0, 0, 365, 470).apply(img)
        if t < t_oc - 0.2:
            header(t, 'ÞINGEYRI · OTOÑO DE 1615', B[3] + 0.3, t_oc - 0.5, 22)
            rk = mk()
            for j in range(4): _L(rk, [(120 + j * 30, 480), (120 + j * 30, 420)], 3)
            _L(rk, [(110, 428), (220, 428)], 3); paint(img, rk, WOOD, 1.0)
            for j in range(6): f_ = mk(); _E(f_, 125 + j * 17, 442 + 5 * (j % 2), 5, 13); paint(img, f_, C3(0.75, 0.70, 0.55), 1.0)
            if t > tw(6, 'pescado') - 0.3: tag(170, 370, 'PESCADO SECO', t, tw(6, 'pescado'), ease((t - tw(6, 'pescado') + 0.3) / 0.3), INK, 20)
            for j in range(3): person(img, 330 - j * 34 - 120 * prog(t, t_pe, t_oc), 530, 80, 'captive', 1.0, t + j, 'walk')
            grass_fg(img, t, 600)
            return img
        header(t, '5 DE OCTUBRE DE 1615', t_oc - 0.1, t_di - 0.6, 22)
        k = ease(prog(t, t_oc - 0.3, t_ca))
        fl = []
        for j in range(7):
            p = silhouette(img, lerp(-80 - j * 60, 40 + j * 42, k), 545 + 12 * (j % 2), 88 + 10 * (j % 3), t + j * 0.37, ease((t - t_oc + 0.3) / 0.4), True, True, None, j)
            if p: fl.append(p)
        smoke_puffs(img, fl, t); embers(img, fl, t, 1.0, 4)
        grass_fg(img, t, 610)
        if t > t_ca - 0.2:
            d = t - t_ca; img = img * (1 - 0.25 * math.exp(-max(0, d) * 3)) + C3(0.5, 0, 0) * 0.25 * math.exp(-max(0, d) * 3)
            counter(270, 220, 280, '14', 'VASCOS MUERTOS', ease((t - t_ca + 0.2) / 0.3))
        if t > t_so - 0.2:
            kk = prog(t, t_so - 0.2, t_di); person(img, lerp(330, 620, kk), 700, 190, 'captive', 1.0, t * 1.8, 'walk')
            tag(400, 420, 'UN SUPERVIVIENTE', t, t_so, ease((t - t_so + 0.2) / 0.3), RED, 22)
        return img
    if t < t_un - 0.3:
        img = room_candles(t)
        a = ease((t - t_di + 0.3) / 0.35)
        # mesa del consejo con 12 jueces sentados
        tbl = mk(); _P(tbl, [(20, 470), (520, 470), (540, 520), (0, 520)]); paint(img, tbl, WOOD * 0.8, a)
        for j in range(12):
            aa = ease((t - t_do + 0.2 - 0.05 * j) / 0.25) * a if t > t_do - 0.3 else 0.0
            x = 40 + j * 42; m = mk(); _C(m, x, 402, 12); _P(m, [(x - 17, 470), (x + 17, 470), (x + 13, 418), (x - 13, 418)]); paint(img, m, C3(0.34, 0.27, 0.22), aa); outline(img, m, aa, 0.8, 1.0)
            hm_ = mk(); _E(hm_, x, 396, 12, 7, 0, 180, 360); paint(img, hm_, C3(0.20, 0.15, 0.12), aa)
        for x in (110, 270, 430): candle_s(img, x, 470, 1.0, t, a)
        if t > t_ar - 0.3:
            aa = ease((t - t_ar + 0.3) / 0.3); person(img, 445, 470, 175, 'rodrigo', aa, t)
            tag(270, 196, 'ARI MAGNÚSSON', t, t_ar, aa, INK, 22)
        if t > t_do - 0.2: tag(270, 250, '12 JUECES', t, t_do, ease((t - t_do + 0.2) / 0.3), INK, 20)
        img = Cam(1.0 + 0.08 * prog(t, t_di, t_un), 0, 0, 270, 420).apply(img)
        header(t, 'SÚÐAVÍK · OCTUBRE DE 1615', t_di, t_un - 0.5, 24)
        if t > t_pr - 0.3:
            pa = ease((t - t_pr + 0.3) / 0.3); parchment(img, 110, 490, 430, 640, pa)
            ov('LOS VASCOS QUEDAN', 270, 530, 20, INK, pa, 'c')
        sp('PROSCRITOS', 58, RED, -7, 270, 590, t_pr + 0.15, 0.97)
        if t > t_ma - 0.3: tag(205, 316, 'SE LES PUEDE MATAR', t, t_ma - 0.2, ease((t - t_ma + 0.3) / 0.3), RED, 22); tag(205, 360, 'DONDE SE LES ENCUENTRE', t, t_ma + 0.3, ease((t - t_ma - 0.2) / 0.3), RED, 18)
        return img
    a = ease((t - t_un + 0.3) / 0.35)
    img = fjord_night(t)
    bt = mk()
    for j in range(3):
        bx = 120 + j * 120 + 8 * math.sin(t + j); by = 500 + 4 * math.sin(t * 1.6 + j)
        _P(bt, [(bx - 34, by), (bx + 34, by), (bx + 24, by + 14), (bx - 24, by + 14)])
    paint(img, bt, C3(0.20, 0.15, 0.10), 1.0)
    img = Cam(1.05 + 0.08 * prog(t, t_un, B[4]), 0, 0, 270, 480).apply(img)
    fl = []
    k = ease(prog(t, t_un - 0.3, t_ve))
    for j in range(8):
        p = silhouette(img, lerp(620 + j * 55, 180 + j * 48, k), 560 + 10 * (j % 2), 84 + 8 * (j % 3), t + j * 0.41, 1.0, True, True, SIL, j + 3)
        if p: fl.append(p)
    smoke_puffs(img, fl, t); embers(img, fl, t, 1.0, 4); grass_fg(img, t, 615)
    img = img * a + room_candles(t) * (1 - a)
    header(t, '13 DE OCTUBRE DE 1615', t_un, B[4] - 0.4, 22)
    if t > t_ve - 0.2: counter(270, 220, 280, 'CASI 20', 'MUERTOS MÁS', ease((t - t_ve + 0.2) / 0.3))
    if t > t_ve + 0.9: tag(270, 330, 'MÁS DE 30 EN TOTAL', t, t_ve + 0.9, ease((t - t_ve - 0.9) / 0.3), RED, 24)
    return img


# ===================================================== S4 · el testigo y la vuelta
def s4(t):
    t_jo = tw(11, 'jon'); t_ne = tw(11, 'nego'); t_pa = tw(11, 'paganos'); t_cr = tw(11, 'cristianos'); t_lo = st0(12); t_vu = tw(12, 'volvieron')
    if t < t_lo - 0.3:
        img = room_candles(t)
        person(img, 230, 690, 330, 'writer', 1.0, t, 'write'); desk(img, 245, 520, 300, 1.0, t, True)
        img = Cam(1.0 + 0.10 * prog(t, B[4], t_lo), 0, 0, 260, 480).apply(img)
        header(t, 'UN TESTIGO', B[4] + 0.2, t_lo - 0.5, 12)
        if t > t_jo - 0.3: tag(270, 196, 'JÓN GUÐMUNDSSON, ERUDITO', t, t_jo - 0.1, ease((t - t_jo + 0.3) / 0.3), INK, 20)
        if t > t_ne - 0.2: tag(270, 250, 'SE NEGÓ A PARTICIPAR', t, t_ne, win(t, t_ne - 0.2, t_pa - 1.4), RED, 20)
        if t > t_pa - 1.5:
            a = ease((t - t_pa + 1.5) / 0.35); parchment(img, 40, 230, 500, 420, a)
            L1 = '«COMO A LOS PEORES'; L2 = 'PAGANOS, Y NO A'; L3 = 'CRISTIANOS INOCENTES»'
            ov(L1, 270, 270, 26, INK, a, 'c', n=tn(L1, t, t_pa - 1.2, 14)); ov(L2, 270, 318, 26, INK, a, 'c', n=tn(L2, t, t_pa - 0.2, 14)); ov(L3, 270, 366, 26, RED, a, 'c', n=tn(L3, t, t_cr - 0.4, 14))
        return img
    img = sea_img(320, 0.25); sea_waves(img, t, 320, 0.8)
    glow_roi(img, 420, 320, 300, C3(1.0, 0.75, 0.45), 0.35, 1.6)
    for j in range(5): gull(img, 80 + j * 70 + 30 * math.sin(t * 0.5 + j), 160 + 25 * math.sin(t * 0.8 + j * 2), 1.0 + 0.2 * (j % 2), t, 0.9, j)
    k = ease(prog(t, t_lo - 0.3, B[5] + 0.5))
    nao(img, 270 + 20 * math.sin(t * 0.6), 470 + 8 * math.sin(t * 1.5), 260, t, 1.0, 0.05 * math.sin(t * 1.3))
    img = Cam(1.0 + 0.06 * k, -40 * k, 0, 270, 420).apply(img)
    a = ease((t - t_lo + 0.3) / 0.35); img = img * a + room_candles(t) * (1 - a)
    header(t, 'PRIMAVERA DE 1616', t_lo, B[5] - 0.4, 18)
    if t > t_vu - 0.2: tag(270, 610, 'LOS SUPERVIVIENTES VUELVEN A CASA', t, t_vu, ease((t - t_vu + 0.2) / 0.3), GREEN_, 18)
    recre(t, 0.7)
    return img


# ===================================================== S5 · 2015
def s5(t):
    t_20 = st0(14); t_ac = tw(14, 'acto'); t_de = tw(14, 'descendientes'); t_at = tw(14, 'atacantes'); t_dr = tw(14, 'derogo'); t_si = st0(15); t_pa = st0(16)
    if t < t_20 - 0.3:
        img = room_candles(t); desk(img, 270, 640, 520, 1.0, t, False); candle_s(img, 470, 600, 1.4, t)
        decree_card(img, t, B[5] - 3, 1.0, 0, 60, 150, 480, 580)
        img = Cam(1.0 + 0.06 * prog(t, B[5], t_20), 0, 0, 270, 380).apply(img)
        sp('NUNCA ANULADO', 46, RED, -6, 270, 470, tw(13, 'anulo') + 0.1, 0.95)
        yr = int(lerp(1615, 2015, ease(prog(t, tw(13, 'anulo') + 0.3, t_20 + 0.1))))
        counter(270, 620, 260, str(yr), 'AÑOS PASANDO', ease((t - tw(13, 'anulo')) / 0.3))
        return img
    if t < t_si - 0.3:
        a = ease((t - t_20 + 0.3) / 0.35)
        g = np.clip(YY / 520.0, 0, 1)[..., None]
        sub = (C3(0.62, 0.72, 0.84) * (1 - g) + C3(0.86, 0.88, 0.90) * g).astype(F32)
        mt = mk(); _P(mt, [(-10, 420), (90, 330), (180, 380), (290, 300), (400, 370), (550, 320), (550, 520), (-10, 520)]); paint(sub, mt, C3(0.42, 0.48, 0.55), 1.0)
        over(sub, (YY > 520).astype(F32), C3(0.40, 0.44, 0.36), 1.0)
        flag(sub, 70, 250, 110, 76, 'islandia', t); flag(sub, 360, 250, 110, 76, 'ikurrina', t + 1)
        cloth = ease(prog(t, t_ac - 0.1, t_ac + 0.9))
        stele(sub, 270, 560, 1.4, 1.0)
        if cloth < 1:
            cm = mk(); top = 560 - 240 * (1 - cloth) - 20; _P(cm, [(215, 560), (325, 560), (330, top), (210, top)]); paint(sub, cm, C3(0.75, 0.75, 0.80), 1.0 - cloth)
        for j in range(9): person(sub, 30 + j * 60 + (20 if j > 4 else 0), 700, 120, ('captive', 'rodrigo', 'cervantes')[j % 3], 0.85, t)
        km = ease(prog(t, t_at + 0.3, t_dr))
        if t > t_de - 0.2: person(sub, lerp(120, 205, km), 620, 190, 'rodrigo', ease((t - t_de + 0.2) / 0.3), t, 'walk' if 0 < km < 1 else 'stand')
        if t > t_at - 0.2: person(sub, lerp(420, 335, km), 620, 190, 'cervantes', ease((t - t_at + 0.2) / 0.3), t, 'walk' if 0 < km < 1 else 'stand')
        sub = Cam(1.0 + 0.06 * prog(t, t_20, t_si), 0, 0, 270, 450).apply(sub)
        img = room_candles(t) * (1 - a) + sub * a
        header(t, 'HÓLMAVÍK · 22 DE ABRIL DE 2015', t_20, t_si - 0.5, 26)
        if t > t_de - 0.2: tag(130, 396, 'DESCENDIENTE DE VÍCTIMA', t, t_de, ease((t - t_de + 0.2) / 0.3) * (1 - ease(prog(t, t_dr - 0.3, t_dr))), INK, 14)
        if t > t_at - 0.2: tag(410, 396, 'DESCENDIENTE DE ATACANTE', t, t_at, ease((t - t_at + 0.2) / 0.3) * (1 - ease(prog(t, t_dr - 0.3, t_dr))), INK, 14)
        sp('DEROGADO', 64, GREEN_, -6, 270, 250, t_dr + 0.15, 0.97)
        return img
    img = room_candles(t); desk(img, 270, 640, 520, 1.0, t, False); candle_s(img, 470, 600, 1.4, t)
    decree_card(img, t, t_si - 5, 1.0, 0, 60, 150, 480, 580)
    img = Cam(1.0 + 0.06 * prog(t, t_si, B[6]), 0, 0, 270, 380).apply(img)
    sp('DEROGADO · 2015', 52, GREEN_, -6, 270, 490, t_si - 0.25, 0.97)
    if t > t_si - 0.2: tag(270, 620, 'SIMBÓLICO: MATAR YA ERA DELITO', t, t_si, ease((t - t_si + 0.2) / 0.3), INK, 20)
    if t > t_pa - 0.2: tag(270, 150, 'PERO SOBRE EL PAPEL, SEGUÍA AHÍ', t, t_pa, ease((t - t_pa + 0.2) / 0.3), RED, 20)
    return img


# ===================================================== S6 · cierre
def s6(t):
    t_q = st0(17); t_su = tw(18, 'suscribete'); t_pa = tw(18, 'descubrir')
    if 'ort' not in _FC: _FC['ort'] = cv2.imread('/home/claude/serie/vascos/fotos/ortelius.jpg')[:, :, ::-1].astype(F32) / 255
    s_ = 0.62 + 0.18 * prog(t, B[6], TEND)
    cxm = lerp(420, 300, prog(t, B[6], TEND)); M = np.float32([[s_, 0, 270 - s_ * cxm], [0, s_, 400 - s_ * 520]])
    img = cv2.warpAffine(_FC['ort'], M, (W, H), borderMode=cv2.BORDER_CONSTANT, borderValue=(0.12, 0.09, 0.08)) * 0.45
    a = ease((t - t_q + 0.2) / 0.3) * (1 - ease((t - t_su + 0.4) / 0.4))
    if a > 0.003:
        rect(30, 170, 510, 300, None, 0.95 * a, 0.3)
        ov('¿QUÉ OTRAS LEYES', 270, 214, 32, INK, a, 'c', n=tn('¿QUÉ OTRAS LEYES', t, t_q, 14)); ov('OLVIDADAS SIGUEN AHÍ?', 270, 262, 30, RED, a, 'c', n=tn('OLVIDADAS SIGUEN AHÍ?', t, tw(17, 'olvidadas'), 16))
        ov('?', 270, 470 + 8 * math.sin(t * 2), 260, RED, a * 0.9, 'c', sh=0.4)
    if t > t_su - 0.1:
        a = ease((t - t_su + 0.1) / 0.4)
        rect(26, 150, 514, 226, RED, 0.96 * a, 0.35); ov('SUSCRÍBETE', 270, 188, 44, CREAM, a, 'c', n=tn('SUSCRÍBETE', t, t_su, 12))
        if t > t_pa - 0.1:
            a2 = ease((t - t_pa + 0.1) / 0.4); rect(26, 240, 514, 322, None, 0.95 * a2, 0.3)
            ov('PARA DESCUBRIR MÁS HISTORIAS', 270, 268, 20, INK, a2, 'c', n=tn('PARA DESCUBRIR MÁS HISTORIAS', t, t_pa, 18)); ov('COMO ESTA', 270, 302, 28, RED, a2, 'c', n=tn('COMO ESTA', t, tw(18, 'como'), 12))
    return img

SC = [s0, s1, s2, s3, s4, s5, s6]
