"""Piezas nuevas para dar inmersión al Short de los balleneros vascos."""
import os, sys
os.environ.setdefault('PAL_DIR', '/home/claude/serie/vascos')
sys.path.insert(0, '/home/claude/serie/vascos'); sys.path.insert(0, '/home/claude/serie/cervantes')
from cv_lib import *
from cv_lib import _f, _d
from cv_art import mk, paint, outline, person, sea_img, desk, _R, WHITE, DARK
from cv_art import waves as sea_waves
from cv_artbase import _L, _P, _C, _E, _fm, WOOD, OCHRE, BONE, SKIN, STONE
from cv_geomap import render_map, _MC
from cv_geo import EQ, WIN

SIL = C3(0.05, 0.05, 0.07)


def silhouette(img, x, y, h, t, a=1.0, walk=True, torch_=True, col=None, k=0):
    """figura en silueta (de perfil, caminando hacia la derecha) con antorcha alzada."""
    col = SIL if col is None else col
    u = h / 10.0; ph = t * 2 * math.pi * 1.3 + k
    m = mk()
    _E(m, x, y - 9.0 * u, 0.85 * u, 0.9 * u)                                  # cabeza
    _P(m, [(x - 1.1 * u, y - 7.9 * u), (x + 1.0 * u, y - 7.9 * u), (x + 1.3 * u, y - 4.2 * u), (x - 1.3 * u, y - 4.2 * u)])   # torso / capa
    _P(m, [(x - 1.5 * u, y - 4.4 * u), (x + 1.5 * u, y - 4.4 * u), (x + 1.9 * u, y - 2.6 * u), (x - 1.8 * u, y - 2.6 * u)])
    for sg in (-1, 1):
        sw = 0.9 * u * math.sin(ph) * sg if walk else 0
        _L(m, [(x, y - 3.0 * u), (x + sw * 0.5, y - 1.5 * u), (x + sw, y)], max(2, 0.8 * u))
    hand = (x + 1.6 * u, y - 8.6 * u)
    _L(m, [(x + 0.6 * u, y - 7.4 * u), (x + 1.4 * u, y - 7.4 * u + 0.2 * u * math.sin(ph)), hand], max(2, 0.6 * u))
    paint(img, m, col, a, 0.6)
    if torch_:
        tm = mk(); _L(tm, [hand, (hand[0] + 0.3 * u, hand[1] - 2.2 * u)], max(2, 0.35 * u)); paint(img, tm, WOOD * 0.6, a)
        fk = 1 + 0.22 * math.sin(t * 17 + k) * math.sin(t * 6.3 + k * 2)
        fx, fy = hand[0] + 0.35 * u, hand[1] - 2.9 * u
        f = mk(); _E(f, fx, fy, 0.55 * u, 1.1 * u * fk); paint(img, f, C3(1.0, 0.72, 0.28), a)
        f2 = mk(); _E(f2, fx, fy + 0.2 * u, 0.3 * u, 0.6 * u * fk); paint(img, f2, C3(1.0, 0.95, 0.75), a)
        glow_roi(img, fx, fy, 9 * u, C3(1.0, 0.52, 0.18), 0.55 * a * fk, 2.0)
        return (fx, fy)
    return None


def embers(img, pts, t, a=1.0, n=10):
    rs = np.random.RandomState(7); items = []
    for (fx, fy) in pts:
        for j in range(n):
            ph = (t * (0.5 + rs.rand()) + rs.rand()) % 1.0
            items.append((fx + (rs.rand() - 0.5) * 30 + 14 * math.sin(t * 3 + j) * ph, fy - 90 * ph, 1.2 + 1.2 * rs.rand()))
    if items: over(img, mcirc(items, 0.6), C3(1.0, 0.65, 0.25), 0.8 * a)


def smoke_puffs(img, pts, t, a=1.0):
    items = []
    for (fx, fy) in pts:
        for j in range(4):
            ph = (t * 0.25 + j / 4) % 1.0; items.append((fx + 20 * ph, fy - 30 - 120 * ph, 8 + 26 * ph))
    over(img, mcirc(items, 6.0), C3(0.25, 0.24, 0.26), 0.35 * a)


def grass_fg(img, t, y0=600, a=1.0, col=C3(0.03, 0.04, 0.05)):
    m = mk(); rs = np.random.RandomState(12)
    _P(m, [(-10, y0 + 30), (550, y0 + 20), (550, H), (-10, H)])
    for j in range(140):
        x = rs.rand() * 560 - 10; hh = 20 + 50 * rs.rand(); sw = 6 * math.sin(t * 1.5 + x * 0.05)
        _P(m, [(x - 3, y0 + 30), (x + 3, y0 + 30), (x + sw + 1, y0 + 30 - hh)])
    paint(img, m, col, a, 0.7)


def flag(img, x, y, w, h, kind, t, a=1.0):
    """bandera ondeando con el asta en (x,y) arriba-izquierda. kind: 'islandia' | 'ikurrina'."""
    fw, fh = int(w), int(h)
    yy, xx = np.mgrid[0:fh, 0:fw].astype(F32); u = xx / fw; v = yy / fh
    pat = np.empty((fh, fw, 3), F32)
    if kind == 'islandia':
        pat[:] = C3(0.02, 0.32, 0.64)
        wc = (np.abs(u - 0.39) < 0.11) | (np.abs(v - 0.5) < 0.16); pat[wc] = C3(0.97, 0.97, 0.97)
        rc = (np.abs(u - 0.39) < 0.055) | (np.abs(v - 0.5) < 0.08); pat[rc] = C3(0.84, 0.10, 0.12)
    else:
        pat[:] = C3(0.82, 0.10, 0.12)
        d1 = np.abs((u - 0.5) * fw - (v - 0.5) * fh * (fw / fh) * (fh / fw)) / (fw * 0.06)
        g = (np.abs((u - 0.5) * fw / fh - (v - 0.5)) < 0.09) | (np.abs((u - 0.5) * fw / fh + (v - 0.5)) < 0.09)
        pat[g] = C3(0.0, 0.50, 0.25)
        wc = (np.abs(u - 0.5) < 0.045) | (np.abs(v - 0.5) < 0.075); pat[wc] = C3(0.97, 0.97, 0.97)
    shade = 0.85 + 0.15 * np.sin(u * 9 - t * 6)
    pat = pat * shade[..., None]
    x0 = int(x); y0 = int(y); dyc = (np.sin(np.arange(fw) / fw * 9 - t * 6) * 6 * (np.arange(fw) / fw)).astype(F32)
    for c in range(fw):
        X = x0 + c; Y = y0 + int(dyc[c])
        if X < 0 or X >= W: continue
        ya, yb = max(0, Y), min(H, Y + fh)
        if ya >= yb: continue
        img[ya:yb, X] = img[ya:yb, X] * (1 - a) + pat[ya - Y:yb - Y, c] * a
    m = mk(); _L(m, [(x - 3, y - 6), (x - 3, y + h * 3.2)], 4); paint(img, m, C3(0.25, 0.22, 0.20), a)


def gull(img, x, y, s, t, a=1.0, k=0):
    fl = math.sin(t * 7 + k) * 0.6
    m = mk(); _L(m, [(x - 14 * s, y - 6 * s * fl), (x - 6 * s, y - 2 * s), (x, y), (x + 6 * s, y - 2 * s), (x + 14 * s, y - 6 * s * fl)], max(1, 2 * s)); paint(img, m, C3(0.15, 0.15, 0.18), a)


_WM = {}
def moving_map(center, R):
    """mapa (sin caché persistente) para cámaras que se desplazan."""
    key = ('mv', round(center[0], 2), round(center[1], 2), int(R))
    P = EQ(center[0], center[1], R)
    img = render_map(key, P, ['LAND'], WIN, (), contour=0.5, grat=0.8, step=5, borders=0.0)
    _MC.pop(key, None)
    return img, P


def woodcut_kb(path, t, t0, t1, z0=1.55, z1=1.05, c0=(0.30, 0.25), c1=(0.5, 0.48)):
    """grabado a pantalla completa con movimiento de cámara (Ken Burns), en papel sepia."""
    if path not in _WM:
        a = cv2.imread(path)[:, :, ::-1].astype(F32) / 255
        a = a[:int(a.shape[0] * 0.89)]
        g = a.mean(2, keepdims=True); a = g * C3(0.96, 0.88, 0.70) + 0.04
        _WM[path] = a
    src = _WM[path]; hh, ww = src.shape[:2]
    k = ease(prog(t, t0, t1)); z = lerp(z0, z1, k); cx = lerp(c0[0], c1[0], k) * ww; cy = lerp(c0[1], c1[1], k) * hh
    s = (W / ww) * z * 1.15
    M = np.float32([[s, 0, 270 - s * cx], [0, s, 380 - s * cy]])
    img = cv2.warpAffine(src, M, (W, H), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_CONSTANT, borderValue=(0.18, 0.14, 0.10))
    img *= np.clip(1.15 - 0.55 * _d ** 1.8, 0.4, 1)[..., None]
    return img


def room_candles(t):
    """sala oscura iluminada con velas (para el consejo y el erudito)."""
    if 'room' not in _WM:
        g = np.clip(YY / H, 0, 1)[..., None]
        img = (C3(0.10, 0.08, 0.07) * (1 - g) + C3(0.05, 0.04, 0.035) * g).astype(F32)
        over(img, ((XX % 60) < 2).astype(F32) * (YY < 520), C3(0.04, 0.03, 0.03), 0.6)
        _WM['room'] = img
    return _WM['room'].copy()


def candle_s(img, x, y, s, t, a=1.0):
    m = mk(); _P(m, [(x - 5 * s, y), (x + 5 * s, y), (x + 5 * s, y - 34 * s), (x - 5 * s, y - 34 * s)]); paint(img, m, BONE, a)
    fk = 1 + 0.12 * math.sin(t * 13 + x) * math.sin(t * 5.1 + y)
    f = mk(); _E(f, x, y - 43 * s, 4 * s, 9 * s * fk); paint(img, f, C3(1.0, 0.82, 0.36), a)
    glow_roi(img, x, y - 43 * s, 160 * s, C3(1.0, 0.66, 0.30), 0.42 * a * fk, 1.8)
