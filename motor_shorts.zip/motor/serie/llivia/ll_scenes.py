import os, sys
os.environ['PAL_DIR'] = '/home/claude/serie/llivia'
sys.path.insert(0, '/home/claude/serie/llivia'); sys.path.insert(0, '/home/claude/serie/vascos'); sys.path.insert(0, '/home/claude/serie/cervantes')
from cv_lib import *
from cv_lib import _f, _d
import cv_lib as L
L.FOTOS = '/home/claude/serie/llivia/fotos/'
from cv_scenes import tn, fadeio, win, white_flash, header, recre, tag, shake
from cv_art import mk, paint, outline, _R
from cv_artbase import _L, _P, _C, _E, _fm, WOOD, BONE, GOLD
from cv_geomap import pulse, along
from vs_art import room_candles, candle_s, silhouette
import ll_map as M

# fronteras de escena ajustadas para que los sellos respiren antes de cada transición
B[3] = st0(9) - 0.48; B[4] = st0(13) - 0.4
BLUE_T = C3(0.13, 0.30, 0.62)
FOT = '/home/claude/serie/llivia/fotos/'

# ------------------------------------------------------------------ utilidades
LN = []          # líneas sobre el texto (tachones), en coordenadas de arte
def oline(x0, y0, x1, y1, col, a=1.0, th=4): LN.append((x0, y0, x1, y1, col, a, th))
def draw_lines(fr):
    for (x0, y0, x1, y1, col, a, th) in LN:
        if a <= 0.01: continue
        m = np.zeros(fr.shape[:2], F32)
        cv2.line(m, (int(x0 * 32), int(y0 * 32)), (int(x1 * 32), int(y1 * 32)), 1.0, int(th * 2), cv2.LINE_AA, shift=4)
        m = cv2.GaussianBlur(m, (0, 0), 0.8)[..., None] * a
        fr[:] = fr * (1 - m) + np.asarray(col, F32) * m
    LN.clear()

def lerpk(t, keys):
    if t <= keys[0][0]: return keys[0][1]
    for (t0, v0), (t1, v1) in zip(keys[:-1], keys[1:]):
        if t <= t1: return v0 + (v1 - v0) * ease((t - t0) / max(1e-6, t1 - t0))
    return keys[-1][1]

def logk(t, keys):
    if t <= keys[0][0]: return keys[0][1]
    for (t0, v0), (t1, v1) in zip(keys[:-1], keys[1:]):
        if t <= t1: return math.exp(lerp(math.log(v0), math.log(v1), ease((t - t0) / max(1e-6, t1 - t0))))
    return keys[-1][1]

def flash(img, t, t0, dur=0.4, k=0.6):
    d = t - t0
    if 0 <= d < dur: white_flash(img, k * (1 - d / dur) ** 2)

_PC = {}
def photo_kb(path, t, t0, t1, z0, z1, c0, c1, sat=0.88):
    if path not in _PC: _PC[path] = cv2.imread(path)[:, :, ::-1].astype(F32) / 255
    src = _PC[path]; hh, ww = src.shape[:2]
    k = ease(prog(t, t0, t1)); z = lerp(z0, z1, k); cx = lerp(c0[0], c1[0], k) * ww; cy = lerp(c0[1], c1[1], k) * hh
    s = max(W / ww, H / hh) * z
    M_ = np.float32([[s, 0, 270 - s * cx], [0, s, 400 - s * cy]])
    img = cv2.warpAffine(src, M_, (W, H), flags=cv2.INTER_AREA if s < 0.5 else cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    g = img.mean(2, keepdims=True); img = g + (img - g) * sat
    img *= np.clip(1.12 - 0.5 * _d ** 1.8, 0.45, 1)[..., None]
    return img

_AT = {}
def art_text(img, text, x, y, sz, col, a=1.0, ang=0.0, bold=True):
    """texto pintado en la capa de arte (se mueve con la cámara / la lupa)."""
    k = (text, round(sz, 1), bold)
    if k not in _AT:
        m = tsp(text, max(6, int(sz * 2)), bold)
        _AT[k] = cv2.resize(m, (m.shape[1] // 2, m.shape[0] // 2), interpolation=cv2.INTER_AREA)
    m = _AT[k]; h, w = m.shape
    if ang:
        D = int(math.hypot(w, h)) + 4; pad = np.zeros((D, D), F32); pad[(D - h) // 2:(D - h) // 2 + h, (D - w) // 2:(D - w) // 2 + w] = m
        R_ = cv2.getRotationMatrix2D((D / 2, D / 2), -ang, 1.0); m = cv2.warpAffine(pad, R_, (D, D)); h, w = m.shape
    x0 = int(round(x - w / 2)); y0 = int(round(y - h / 2))
    xa, ya, xb, yb = max(0, x0), max(0, y0), min(W, x0 + w), min(H, y0 + h)
    if xa >= xb or ya >= yb: return
    mm = (m[ya - y0:yb - y0, xa - x0:xb - x0] * a)[..., None]
    img[ya:yb, xa:xb] = img[ya:yb, xa:xb] * (1 - mm) + np.asarray(col, F32) * mm

def hook_header(t, text, t0, t1, cps=40):
    if t0 - 0.05 < t < t1 + 0.6:
        al = fadeio(t, t0 - 0.06, t1, 0.01, 0.45); rect(16, 30, 524, 142, None, 0.95 * al, 0.4)
        ov(text, 270, 86, 50, RED, al, 'c', n=tn(text, t, t0, cps))

def zoom_center(T, C0, s0, s, drift):
    k = (s0 / s) * (1 - drift)
    return (T[0] + (C0[0] - T[0]) * k, T[1] + (C0[1] - T[1]) * k)

def crown(img, cx, cy, s, a=1.0, t=0.0):
    m = mk(); _P(m, [(cx - 30 * s, cy + 18 * s), (cx + 30 * s, cy + 18 * s), (cx + 34 * s, cy - 20 * s), (cx + 16 * s, cy - 2 * s), (cx, cy - 30 * s), (cx - 16 * s, cy - 2 * s), (cx - 34 * s, cy - 20 * s)])
    glow_roi(img, cx, cy, 70 * s, C3(1.0, 0.8, 0.35), 0.35 * a, 2.0)
    paint(img, m, GOLD, a); outline(img, m, a, 0.8, 1.2)
    over(img, mcirc([(cx - 34 * s, cy - 22 * s, 4.5 * s), (cx, cy - 32 * s, 5 * s), (cx + 34 * s, cy - 22 * s, 4.5 * s)], 0.6), GOLD * 1.05, a)
    over(img, mcirc([(cx, cy + 6 * s, 5 * s)], 0.6), RED, a)
    sh = mk(); _P(sh, [(cx - 30 * s, cy + 10 * s), (cx + 30 * s, cy + 10 * s), (cx + 30 * s, cy + 18 * s), (cx - 30 * s, cy + 18 * s)]); paint(img, sh, GOLD * 0.75, a)


# ===================================================== S0 · ¿sabías que...?
def s0_map(t):
    t_pu, t_es, t_fr, t_pi = tw(0, 'pueblo'), tw(0, 'espanol'), tw(0, 'francia'), tw(1, 'pirineo')
    s = logk(t, [(0.0, 0.27), (0.8, 0.29), (4.6, 40.0), (t_pi + 0.5, 47.0)])
    c = zoom_center(M.LLV_C, (2.6, 43.7), 0.27, s, ease(prog(t, 0.8, 4.6)))
    g = M.Geo(c[0], c[1], s)
    spn = 0.22 + 0.36 * ease(prog(t, t_es - 0.15, t_es + 0.35)); frn = 0.12 + 0.46 * ease(prog(t, t_fr - 0.25, t_fr + 0.3))
    img = M.geomap(g, spain=spn, france=frn, llv=ease(prog(t, 2.4, 3.2)), relief=lerp(1.0, 0.75, prog(s, 10, 40)))
    x, y = g.p(*M.LLV_C)
    a_dot = ease(prog(t, t_pu - 0.25, t_pu + 0.1)) * (1 - ease(prog(s, 5, 12)))
    if a_dot > 0: over(img, mcirc([(x, y, 6.5)], 0.6), CREAM, a_dot); over(img, mcirc([(x, y, 4.5)], 0.6), RED, a_dot)
    if t > t_pu - 0.2: pulse(img, x, y, t, RED, ease(prog(t, t_pu - 0.2, t_pu + 0.2)), 6 + s * 0.4, 48 + s * 2.2, 1.0, 3, 2)
    return img, g

def s0(t):
    t_es, t_fr, t_ll, t_pi = tw(0, 'espanol'), tw(0, 'francia'), tw(1, 'llivia'), tw(1, 'pirineo')
    img, g = s0_map(t)
    hook_header(t, '¿SABÍAS QUE...?', 0.0, t_pi - 0.4)
    if t < t_pi:
        if t_es - 0.2 < t < t_fr - 0.4:
            q = g.p(-1.2, 41.3); tag(q[0], q[1], 'ESPAÑA', t, t_es - 0.1, ease((t - t_es + 0.2) / 0.25) * (1 - ease((t - t_fr + 0.7) / 0.3)), RED, 26)
        if t > t_fr - 0.3:
            a = ease((t - t_fr + 0.3) / 0.3) * (1 - ease((t - t_pi + 0.3) / 0.3))
            ov('FRANCIA', 270, 200, 40, BLUE_T, a, 'c', sh=0.0)
            a2 = a * ease(prog(g.s, 22, 32))
            if a2 > 0.01:
                q = g.p(2.03, 42.45); ov('FRANCIA', q[0], q[1], 26, BLUE_T, a2, 'c')
                q = g.p(1.905, 42.43); ov('ESPAÑA', q[0], q[1], 28, RED * 0.85, a2, 'c')
        if t > t_ll - 0.25:
            a = ease((t - t_ll + 0.25) / 0.3) * (1 - ease((t - t_pi + 0.3) / 0.3))
            q = g.p(1.975, 42.434); tag(q[0], q[1], 'LLÍVIA', t, t_ll - 0.15, a, RED, 34, 230, 20)
    if t > t_pi - 0.35:
        a = ease((t - t_pi + 0.35) / 0.35)
        ph = photo_kb(FOT + 'llivia.jpg', t, t_pi - 0.35, B[1] + 0.8, 1.05, 1.18, (0.47, 0.47), (0.47, 0.42))
        img = img * (1 - a) + ph * a
        flash(img, t, t_pi - 0.05, 0.3, 0.35)
        tag(270, 560, 'LLÍVIA · PIRINEO CATALÁN', t, t_pi, a, INK, 20)
        ov('FOTO: WIKIMEDIA COMMONS', 270, 150, 11, CREAM, a * 0.85, 'c', sh=0.6)
    return img


# ===================================================== S1 · el tratado
def s1_map(t):
    t_qu, t_ro, t_33, t_ce = tw(4, 'queda'), tw(4, 'rosellon'), tw(4, 'treinta'), tw(4, 'cerdana')
    tz0, tz1 = t_ro + 0.55, t_33 + 0.75
    s = logk(t, [(t_qu - 0.8, 3.4), (tz0, 3.9), (tz1, 12.0), (B[2] + 1.0, 13.5)])
    if t < tz0: c = (2.42 - 0.05 * prog(t, t_qu - 0.8, tz0), 42.64)
    else: c = zoom_center(M.LLV_C, (2.37, 42.64), 3.9, s, ease(prog(t, tz0, tz1)))
    g = M.Geo(c[0], c[1], s)
    k = ease(prog(t, t_qu - 0.05, t_ro + 0.55))
    img = M.geomap(g, spain=0.62, france=0.58, ceded=k, old_b=1 - ease(prog(t, t_ro + 0.4, t_ro + 0.9)), border_hl=ease(prog(t, t_ro + 0.2, t_ro + 0.7)), relief=0.65)
    tf = [lerp(t_33 - 0.05, t_ce + 0.25, (32 - j) / 32.0) for j in range(33)]
    if t > t_33 - 0.4: M.villages(img, g, tf, t, ease((t - t_33 + 0.4) / 0.3))
    if t > tz1:
        x, y = g.p(*M.LLV_C); pulse(img, x, y, t, RED, ease(prog(t, tz1, tz1 + 0.4)), 30, 120, 1.1, 3, 2)
    return img, g, tf

def s1(t):
    t_59 = st0(2); t_fr = st0(4); t_pz = tw(3, 'paz'); t_ro = tw(4, 'rosellon'); t_33 = tw(4, 'treinta'); t_ce = tw(4, 'cerdana')
    T_MAP = t_fr - 0.25
    pimg = None
    if t < T_MAP + 0.35:
        pimg = photo_kb(FOT + 'faisanes.jpg', t, B[1] - 0.7, T_MAP + 0.4, 1.75, 1.22, (0.28, 0.60), (0.58, 0.58), 0.95)
        flash(pimg, t, t_59 - 0.05, 0.35, 0.3)
    if t < T_MAP - 0.35:
        header(t, '1659 · TRATADO DE LOS PIRINEOS', t_59 - 0.05, T_MAP - 0.5, 30)
        if t > t_pz - 0.3:
            ov('ISLA DE LOS FAISANES · LUIS XIV Y FELIPE IV (1660)', 270, 150, 11, CREAM, 0.85 * ease((t - t_pz + 0.3) / 0.3), 'c', sh=0.6)
            tag(270, 575, 'PAZ ENTRE ESPAÑA Y FRANCIA', t, t_pz - 0.1, ease((t - t_pz + 0.3) / 0.3), INK, 20)
        return pimg
    img, g, tf = s1_map(t)
    a = ease((t - T_MAP + 0.35) / 0.35)
    if a < 1: img = img * a + pimg * (1 - a)
    header(t, 'LA NUEVA FRONTERA', t_fr, B[2] - 0.4, 22)
    am = a * (1 - ease(prog(t, t_ro + 0.5, t_ro + 0.9)))
    ov('FRANCIA', 270, 205, 36, BLUE_T, a, 'c')
    ov('ESPAÑA', 270, 612, 32, RED * 0.85, a, 'c')
    if t > t_ro - 0.3 and am > 0.01:
        x, y = M.dot(img, g, *M.PERP, INK, 4, am); ov('PERPIÑÁN', x, y + 18, 12, INK, am, 'c')
        q = g.p(2.72, 42.57); tag(q[0], q[1], 'ROSELLÓN', t, t_ro - 0.1, am * ease((t - t_ro + 0.3) / 0.3), BLUE_T, 24)
    if t > t_33 - 0.3:
        aa = ease((t - t_33 + 0.3) / 0.3); n = sum(1 for x_ in tf if t >= x_)
        rect(352, 498, 520, 612, None, 0.95 * aa, 0.35); ov('%d' % n, 436, 540, 46, BLUE_T, aa, 'c'); ov('PUEBLOS', 436, 586, 15, INK, aa, 'c')
    if t > t_ce - 0.3:
        q = g.p(1.99, 42.545); tag(q[0], max(175, q[1]), 'CERDAÑA', t, t_ce - 0.15, ease((t - t_ce + 0.3) / 0.3), INK, 22)
    return img


# ===================================================== S2 · villa
_DOC = {}
WORD_P = (300, 345); WORD_V = (215, 495)
def _doc_static():
    if 'img' in _DOC: return _DOC['img']
    img = room_candles(0).copy()
    rs = np.random.RandomState(3); x0, y0, x1, y1 = 48, 160, 492, 628
    pts = [(x0 + rs.rand() * 6, y0 + rs.rand() * 6), (x1 - rs.rand() * 6, y0 + rs.rand() * 6), (x1 - rs.rand() * 6, y1 - rs.rand() * 6), (x0 + rs.rand() * 6, y1 - rs.rand() * 6)]
    m = mk(); _P(m, pts); shadow(img, _fm(m), 0.45, (6, 8), 7.0); paint(img, m, C3(0.86, 0.78, 0.60), 1.0)
    over(img, _fm(m) * (fractal(8, (10, 30, 80)) > 0.55), C3(0.70, 0.58, 0.40), 0.35)
    over(img, _fm(m) * np.clip(_d * 1.4 - 0.3, 0, 1), C3(0.55, 0.40, 0.25), 0.35)
    e = mk(); _P(e, pts); outline(img, e, 1.0, 0.5, 2.0)
    INKB = C3(0.20, 0.13, 0.08)
    art_text(img, 'TRATADO DE LOS PIRINEOS', 270, 212, 17, INKB, 0.95)
    sc = mk(); rs = np.random.RandomState(9)
    def scrib(xa, xb, y):
        x = xa
        while x < xb - 12:
            w = min(xb - x, rs.randint(14, 46)); xs = np.arange(x, x + w, 1.0)
            ys = y + 2.4 * np.sin(xs * 1.25 + rs.rand() * 6) + 1.1 * np.sin(xs * 0.41 + rs.rand() * 6)
            _L(sc, list(zip(xs, ys)), 1)
            if rs.rand() < 0.35: xa_ = x + rs.rand() * w; _L(sc, [(xa_, y + 2), (xa_ + 2, y - 8)], 1)
            x += w + rs.randint(7, 12)
    for i in range(12):
        y = 255 + 30 * i; xa, xb = 78, 462 - (40 if i % 4 == 3 else 0)
        if abs(y - WORD_P[1]) < 5: scrib(xa, WORD_P[0] - 42, y); scrib(WORD_P[0] + 42, xb, y); art_text(img, 'PUEBLOS', WORD_P[0], y - 2, 15, INKB, 0.92)
        elif abs(y - WORD_V[1]) < 5: scrib(xa, WORD_V[0] - 30, y); scrib(WORD_V[0] + 30, xb, y); art_text(img, 'VILLA', WORD_V[0], y - 2, 15, INKB, 0.92)
        else: scrib(xa, xb, y)
    paint(img, sc, INKB, 0.75, 0.4)
    w_ = mk(); _C(w_, 420, 590, 20); paint(img, w_, C3(0.55, 0.08, 0.06), 1.0); outline(img, w_, 0.6, 0.6, 1.0)
    _DOC['img'] = img
    return img

def doc_scene(t, t0, t_pa):
    img = _doc_static().copy()
    for (cx, cy, k) in ((30, 662, 0), (512, 655, 1)): candle_s(img, cx, cy, 1.25, t + k * 1.7, 1.0)
    if t > t_pa:
        k = ease((t - t_pa) / 0.35)
        art_text(img, 'VILLA', WORD_V[0], WORD_V[1] - 2, 15, RED, k)
        m = mk(); _L(m, [(WORD_V[0] - 28, WORD_V[1] + 10), (WORD_V[0] - 28 + 56 * k, WORD_V[1] + 10 + 1.5 * math.sin(k * 6))], 3); paint(img, m, RED, 0.9)
        glow_roi(img, WORD_V[0], WORD_V[1], 60, C3(1.0, 0.45, 0.25), 0.25 * k, 2.0)
    lx = lerpk(t, [(t0 - 0.3, 140), (t0 + 0.55, WORD_P[0]), (t0 + 0.95, WORD_P[0] + 4), (t_pa - 0.2, WORD_V[0])]); ly = lerpk(t, [(t0 - 0.3, 285), (t0 + 0.55, WORD_P[1]), (t0 + 0.95, WORD_P[1] + 2), (t_pa - 0.2, WORD_V[1])])
    R_ = 70; Z = 1.9
    Mz = np.float32([[Z, 0, lx - Z * lx], [0, Z, ly - Z * ly]]); zz = cv2.warpAffine(img, Mz, (W, H), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REFLECT)
    lens = mcirc([(lx, ly, R_)], 0.8); img[:] = img * (1 - lens[..., None]) + zz * 1.06 * lens[..., None]
    rg = mk(); _E(rg, lx, ly, R_ + 7, R_ + 7); cv2.circle(rg, (int(lx * 16), int(ly * 16)), int(R_ * 16), 0, -1, cv2.LINE_AA, shift=4)
    paint(img, rg, C3(0.30, 0.22, 0.14), 1.0); outline(img, rg, 0.7, 0.6, 1.0)
    hd = mk(); _L(hd, [(lx + (R_ + 5) * 0.72, ly + (R_ + 5) * 0.72), (lx + (R_ + 70) * 0.72, ly + (R_ + 70) * 0.72)], 13); paint(img, hd, WOOD * 0.7, 1.0); outline(img, hd, 0.8, 0.6, 1.0)
    hl = mk(); _E(hl, lx - R_ * 0.35, ly - R_ * 0.4, R_ * 0.35, R_ * 0.16, -35); paint(img, hl, C3(1, 1, 1), 0.18, 3.0)
    z = lerp(1.0, 1.12, ease(prog(t, t0, t_pa + 0.8)))
    return Cam(z, 0, 0, WORD_V[0] + 40, WORD_V[1] - 60).apply(img)

def s2_map(t, s, c, llv_pulse=1.0):
    g = M.Geo(c[0], c[1], s)
    img = M.geomap(g, spain=0.55, france=0.5, border_hl=1.0, relief=0.75)
    x, y = g.p(*M.LLV_C)
    if llv_pulse > 0: pulse(img, x, y, t, RED, llv_pulse, 40, 150, 1.2, 3, 2)
    return img, g

def s2(t):
    t_pe = st0(5); t_pu = tw(5, 'pueblo'); t_ca = tw(6, 'carlos'); t_ti = tw(6, 'titulo'); t_ne = st0(7); t_pa = tw(7, 'palabra'); t_60 = st0(8)
    T_DOC0 = t_ne + 0.35; T_DOC1 = t_60 - 0.3
    out = None
    if t < T_DOC0 + 0.35:
        s = logk(t, [(B[2] - 0.7, 13.5), (t_pe + 0.9, 34.0), (T_DOC0 + 0.4, 37.0)])
        c = zoom_center(M.LLV_C, (1.985, 42.47), 13.5, s, ease(prog(t, B[2] - 0.7, t_pe + 0.9)))
        img, g = s2_map(t, s, c)
        x, y = g.p(*M.LLV_C)
        crn = ease(prog(t, t_ca - 0.3, t_ca)) * (1 - ease(prog(t, T_DOC0 - 0.2, T_DOC0 + 0.2)))
        al0 = ease(prog(g.s, 20, 28)) * (1 - ease(prog(t, T_DOC0 - 0.3, T_DOC0 + 0.1)))
        if al0 > 0.01:
            q = g.p(2.03, 42.45); ov('FRANCIA', q[0], q[1], 26, BLUE_T, al0, 'c')
            q = g.p(1.925, 42.478); ov('FRANCIA', q[0], q[1], 26, BLUE_T, al0, 'c')
        if crn > 0: crown(img, 92, 562, 0.95 + 0.06 * math.sin(t * 3), crn, t)
        if t < T_DOC0 + 0.1:
            al = 1 - ease(prog(t, T_DOC0 - 0.3, T_DOC0 + 0.1))
            a1 = ease((t - t_pe + 0.1) / 0.3) * al
            if a1 > 0.01:
                rect(80, 158, 460, 272, None, 0.95 * a1, 0.35); ov('UN PUEBLO', 270, 214, 44, INK, a1, 'c', n=tn('UN PUEBLO', t, t_pe + 0.25, 14))
                if t > t_pu + 0.05:
                    k = ease(prog(t, t_pu + 0.05, t_pu + 0.35)); oline(108, 216, 108 + 324 * k, 210, RED, a1 * 0.95, 5)
                    if k >= 1: ov('NO ERA', 270, 254, 20, RED, a1, 'c')
            a2 = ease((t - t_ca + 0.3) / 0.3) * al
            if a2 > 0.01:
                rect(150, 505, 470, 622, None, 0.95 * a2, 0.35)
                ov('CARLOS V', 310, 540, 34, INK, a2, 'c', n=tn('CARLOS V', t, t_ca - 0.05, 14))
                ov('TÍTULO DE VILLA', 310, 588, 18, INK, a2, 'c', n=tn('TÍTULO DE VILLA', t, t_ti, 16))
            sp('VILLA', 66, RED, -7, x, y, st1(6) + 0.05, 0.97 * al)
        out = img
    if T_DOC0 - 0.35 < t < T_DOC1 + 0.35:
        d = doc_scene(t, T_DOC0, t_pa)
        a = ease(prog(t, T_DOC0 - 0.35, T_DOC0 + 0.35)) * (1 - ease(prog(t, T_DOC1 - 0.35, T_DOC1 + 0.35)))
        out = d if out is None else out * (1 - a) + d * a
        if T_DOC0 < t < T_DOC1:
            header(t, 'LA LETRA PEQUEÑA', T_DOC0 + 0.1, T_DOC1 - 0.4, 22)
            recre(t, 0.8 * ease(prog(t, T_DOC0, T_DOC0 + 0.4)) * (1 - ease(prog(t, T_DOC1 - 0.4, T_DOC1))), CREAM)
    if t > T_DOC1 - 0.35:
        s = logk(t, [(T_DOC1 - 0.35, 24.0), (B[3] + 0.5, 30.0)])
        img, g = s2_map(t, s, (M.LLV_C[0] + 0.005, M.LLV_C[1] - 0.02))
        x, y = g.p(*M.LLV_C)
        a = ease(prog(t, T_DOC1 - 0.35, T_DOC1 + 0.35))
        out = img if out is None or a >= 1 else out * (1 - a) + img * a
        if t > T_DOC1:
            header(t, '1660', t_60 + 0.15, B[3] - 0.3, 14)
            tag(x, y - g.s * 2.7 - 30, 'LLÍVIA', t, t_60 + 0.3, ease((t - t_60 - 0.2) / 0.3), RED, 26, 170)
            q = g.p(2.035, 42.47); ov('FRANCIA', q[0], q[1], 28, BLUE_T, a, 'c')
            q = g.p(1.915, 42.49); ov('FRANCIA', q[0], q[1], 28, BLUE_T, a, 'c')
            q = g.p(1.905, 42.425); ov('ESPAÑA', q[0], q[1], 28, RED * 0.85, a, 'c')
            sp('ESPAÑA', 64, RED, -6, x, y + 8, st1(8) + 0.05, 0.97)
    return out


# ===================================================== S3 · hoy
CORR = ((1.947509, 42.451234), (1.927458, 42.436894))   # puntos más cercanos Llívia ↔ resto de España
CLOSE_C = (1.952, 42.452); CLOSE_S = 55.0

def car_top(img, x, y, ang, a=1.0, s=1.0):
    ca, sa = math.cos(ang), math.sin(ang)
    def T(pts): return [(x + px * ca - py * sa, y + px * sa + py * ca) for px, py in pts]
    b = mk(); _P(b, T([(-15 * s, -8 * s), (13 * s, -8 * s), (16 * s, -5 * s), (16 * s, 5 * s), (13 * s, 8 * s), (-15 * s, 8 * s)]))
    shadow(img, _fm(b), 0.45 * a, (2, 3), 2.0); paint(img, b, C3(0.85, 0.14, 0.12), a); outline(img, b, a, 0.7, 1.0)
    w = mk(); _P(w, T([(3 * s, -6 * s), (9 * s, -5 * s), (9 * s, 5 * s), (3 * s, 6 * s)])); _P(w, T([(-11 * s, -6 * s), (-7 * s, -6 * s), (-7 * s, 6 * s), (-11 * s, 6 * s)])); paint(img, w, C3(0.18, 0.22, 0.28), a)
    for py in (-5, 5):
        hx, hy = T([(18 * s, py * s)])[0]; glow_roi(img, hx + 10 * ca, hy + 10 * sa, 16 * s, C3(1.0, 0.95, 0.7), 0.45 * a, 2.0)

def close_map(t, extra_s=0.0, dc=(0.0, 0.0), road_a=0.6):
    g = M.Geo(CLOSE_C[0] + dc[0], CLOSE_C[1] + dc[1], CLOSE_S + extra_s)
    img = M.geomap(g, spain=0.55, france=0.5, border_hl=1.0, relief=0.7)
    rq = g.P(M.ROAD)
    m = mk(); _L(m, rq, 9); paint(img, m, C3(0.97, 0.95, 0.88), road_a); m = mk(); _L(m, rq, 6); paint(img, m, C3(0.36, 0.36, 0.38), road_a)
    return img, g, rq

def stop_layers():
    if 'k' in _DOC: return _DOC['k']
    xs = np.arange(-10, 556, 5, dtype=np.float64)
    far = [(x, 330 - 78 * abs(math.sin(x * 0.010 + 1.1)) - 26 * math.sin(x * 0.031 + 0.4) - 9 * math.sin(x * 0.09)) for x in xs]
    mid = [(x, 382 - 34 * abs(math.sin(x * 0.016 + 0.3)) - 10 * math.sin(x * 0.05 + 1.0)) for x in xs]
    hill = [(x, 402 - 8 * math.sin(x * 0.02 + 2)) for x in xs]
    def poly_m(top):
        m = mk(); _P(m, top + [(556, 960), (-10, 960)]); return _fm(m, 0.7)
    Ff, Fm, Fh = poly_m(far), poly_m(mid), poly_m(hill)
    ty = np.interp(np.arange(W), [p[0] for p in far], [p[1] for p in far]).astype(F32)
    snow = Ff * np.clip((ty[None, :] + 22 + 6 * np.sin(XX * 0.21) - YY) / 4.0, 0, 1)
    road = mk(); _P(road, [(262, 404), (278, 404), (520, 960), (20, 960)]); Fr = _fm(road, 0.6)
    cross = mk(); _P(cross, [(-10, 512), (550, 512), (550, 540), (-10, 540)]); Fc = _fm(cross, 0.6)
    dash = mk()
    for i in range(9):
        z0 = 1.0 / (1.6 + i * 1.0); z1 = 1.0 / (1.6 + i * 1.0 + 0.5); y0 = 404 + 556 * z0; y1 = 404 + 556 * z1
        _P(dash, [(270 - 5 * z0, y0), (270 + 5 * z0, y0), (270 + 5 * z1, y1), (270 - 5 * z1, y1)])
    stopl = mk(); _P(stopl, [(272, 556), (445, 556), (450, 566), (274, 566)])
    houses = mk(); rs = np.random.RandomState(4)
    for j in range(14):
        hx = 318 + j * 8 + rs.rand() * 4; hh = 6 + rs.rand() * 7; _P(houses, [(hx, 404), (hx + 8, 404), (hx + 8, 404 - hh), (hx + 4, 404 - hh - 4), (hx, 404 - hh)])
    _P(houses, [(372, 404), (380, 404), (380, 372), (376, 362), (372, 372)])
    rs = np.random.RandomState(8); stars = [(rs.rand() * W, 150 + rs.rand() * 230, 0.6 + rs.rand() * 1.0) for _ in range(90)]
    sky_g = np.clip((YY - 140) / 270.0, 0, 1)[..., None].astype(F32)
    _DOC['k'] = dict(Ff=Ff, Fm=Fm, Fh=Fh, snow=snow, Fr=Fr, Fc=Fc, dash=_fm(dash, 0.5), stopl=_fm(stopl, 0.5), houses=_fm(houses, 0.5), stars=mcirc(stars, 0.5), sky_g=sky_g)
    return _DOC['k']

def mix(a, b, k): return a * (1 - k) + b * k

def stop_sign(img, xb, yb, sc, tilt, a, night):
    if a <= 0.01 or sc <= 0.01: return
    P_ = lambda pts: rot([(xb + px * sc, yb + py * sc) for px, py in pts], tilt, (xb, yb))
    lit = 1 - 0.55 * night
    p = mk(); _P(p, P_([(-3, 0), (3, 0), (3, -150), (-3, -150)])); paint(img, p, C3(0.62, 0.62, 0.64) * lit, a); outline(img, p, a, 0.6, 1.0)
    cx, cy = 0, -150
    oc = [(cx + 42 * math.cos(math.pi / 8 + j * math.pi / 4), cy + 42 * math.sin(math.pi / 8 + j * math.pi / 4)) for j in range(8)]
    oi = [(cx + 36 * math.cos(math.pi / 8 + j * math.pi / 4), cy + 36 * math.sin(math.pi / 8 + j * math.pi / 4)) for j in range(8)]
    o = mk(); _P(o, P_(oc)); shadow(img, _fm(o), 0.35 * a, (3, 4), 2.5); paint(img, o, C3(0.96, 0.96, 0.96) * lit, a)
    i = mk(); _P(i, P_(oi)); paint(img, i, C3(0.80, 0.06, 0.06) * (lit + 0.15 * night), a); outline(img, o, a, 0.7, 1.0)
    tx, ty = rot([(xb, yb - 150 * sc)], tilt, (xb, yb))[0]
    art_text(img, 'STOP', tx, ty, 13 * sc, C3(1, 1, 1) * lit, a, tilt)

def stop_state(t):
    t_st = tw(11, 'stop'); T0 = t_st + 0.32; P = 1.5
    cyc = (t - T0) / P; ci = int(math.floor(cyc)); ph = cyc - ci
    return t_st, T0, P, ci, ph

def stop_scene(t):
    t_st, T0, P, ci, ph = stop_state(t)
    K = stop_layers()
    lapse = T0 <= t and ci < 2
    day = 1.0 if not lapse else (1 - ease(prog(ph, 0.12, 0.32)) + ease(prog(ph, 0.62, 0.80)))
    night = 1 - day; warm = 4 * day * (1 - day)
    top = mix(C3(0.36, 0.58, 0.84), C3(0.02, 0.03, 0.09), night); bot = mix(C3(0.80, 0.86, 0.90), C3(0.08, 0.09, 0.19), night)
    img = top * (1 - K['sky_g']) + bot * K['sky_g']
    img += C3(0.85, 0.40, 0.15) * (0.55 * warm) * np.clip(1 - np.abs(YY - 390) / 160.0, 0, 1)[..., None]
    over(img, K['stars'], C3(1, 1, 1), night ** 2)
    if night > 0.05: over(img, mcirc([(118, 205, 15)], 0.8), C3(0.95, 0.95, 0.88), night); glow_roi(img, 118, 205, 70, C3(0.6, 0.7, 1.0), 0.18 * night, 2.0)
    if day > 0.05: glow_roi(img, 430, 205, 90, C3(1.0, 0.92, 0.7), 0.35 * day, 2.0)
    v = 150.0 if lapse else 18.0
    cl = []
    for j in range(5):
        cx = ((j * 137 + t * v * (0.7 + 0.15 * j)) % 760) - 110; cy = 185 + 32 * (j % 3)
        cl += [(cx, cy, 22), (cx + 26, cy - 8, 26), (cx + 54, cy, 20)]
    over(img, mcirc(cl, 7.0), mix(C3(0.98, 0.98, 0.98), C3(0.20, 0.22, 0.30), night), 0.55)
    over(img, K['Ff'], mix(C3(0.52, 0.58, 0.70), C3(0.07, 0.08, 0.14), night), 1.0)
    over(img, K['snow'], mix(C3(0.97, 0.97, 0.99), C3(0.26, 0.29, 0.38), night), 1.0)
    over(img, K['Fm'], mix(C3(0.34, 0.44, 0.34), C3(0.05, 0.06, 0.09), night), 1.0)
    over(img, K['houses'], mix(C3(0.72, 0.62, 0.52), C3(0.08, 0.07, 0.08), night), 1.0)
    over(img, K['Fh'], mix(C3(0.50, 0.60, 0.30), C3(0.05, 0.07, 0.07), night), 1.0)
    if night > 0.3:
        rs = np.random.RandomState(2); win_ = [(318 + rs.rand() * 112, 396 - rs.rand() * 8, 1.0) for _ in range(9)]
        over(img, mcirc(win_, 0.4), C3(1.0, 0.85, 0.45), night)
    img *= (0.94 + 0.08 * _f[..., None])
    over(img, K['Fr'], mix(C3(0.38, 0.38, 0.40), C3(0.06, 0.06, 0.08), night), 1.0)
    over(img, K['Fc'], mix(C3(0.42, 0.41, 0.42), C3(0.07, 0.07, 0.09), night), 1.0)
    over(img, K['dash'], mix(C3(0.95, 0.93, 0.80), C3(0.25, 0.25, 0.22), night), 1.0)
    over(img, K['stopl'], mix(C3(0.95, 0.95, 0.95), C3(0.28, 0.28, 0.28), night), ease(prog(t, t_st, t_st + 0.3)))
    if night > 0.2:
        m = mk(); _L(m, [(150, 960), (262, 410)], 3); _L(m, [(-10, 520), (550, 520)], 3); paint(img, m, C3(1.0, 0.25, 0.15), 0.45 * night, 1.6)
        m = mk(); _L(m, [(390, 960), (276, 410)], 3); _L(m, [(-10, 532), (550, 532)], 3); paint(img, m, C3(1.0, 0.95, 0.80), 0.40 * night, 1.6)
    # coche que pasa antes de las señales
    if t < t_st:
        k = prog(t, st0(11) - 0.3, t_st - 0.1)
        if 0 < k < 1:
            z = 1.0 / (1.0 + 6.0 * k); y = 404 + 556 * z * 0.85; x = 270 + 60 * z; s = 1.6 * z
            b = mk(); _P(b, [(x - 22 * s, y), (x + 22 * s, y), (x + 20 * s, y - 16 * s), (x + 14 * s, y - 28 * s), (x - 14 * s, y - 28 * s), (x - 20 * s, y - 16 * s)]); paint(img, b, C3(0.82, 0.15, 0.12), 1.0); outline(img, b, 1.0, 0.7, 1.0)
            w = mk(); _P(w, [(x - 12 * s, y - 18 * s), (x + 12 * s, y - 18 * s), (x + 10 * s, y - 26 * s), (x - 10 * s, y - 26 * s)]); paint(img, w, C3(0.15, 0.18, 0.22), 1.0)
            for dx in (-15, 15): glow_roi(img, x + dx * s, y - 10 * s, 10 * s + 2, C3(1.0, 0.2, 0.1), 0.6, 2.0)
    # señal: aparece, la arrancan de noche, reaparece al día siguiente
    xb, yb = 452, 600
    sc, tilt, sa = 0.0, 0.0, 0.0
    if t >= t_st:
        if not lapse:
            tp = t_st if t < T0 else T0 + 2 * P
            d = t - tp; sa = 1.0
            sc = (1.0 + 0.18 * math.sin(math.pi * d / 0.3) if d < 0.3 else 1.0) * min(1.0, d / 0.1)
        else:
            if ph < 0.50: sc, sa = 1.0, 1.0
            elif ph < 0.56: sc, sa, tilt = 1.0, 1.0, 85 * ease((ph - 0.50) / 0.06)
            elif ph < 0.60: sc, sa, tilt = 1.0, 1 - (ph - 0.56) / 0.04, 85
            if ci >= 1 and ph < 0.04: sc = (ph / 0.04) * 1.12
            elif ci >= 1 and ph < 0.08: sc = 1.12 - 0.12 * (ph - 0.04) / 0.04
    if t >= t_st and (sa < 0.5 or sc < 0.3):
        mnd = mk(); _E(mnd, xb, yb + 2, 24, 7); paint(img, mnd, mix(C3(0.38, 0.27, 0.16), C3(0.08, 0.06, 0.05), night), 1.0)
    stop_sign(img, xb, yb, sc, tilt, sa, night)
    # figura nocturna con linterna
    if lapse and 0.34 <= ph <= 0.66:
        if ph < 0.48: fx = lerp(250, xb - 40, ease((ph - 0.34) / 0.14)); walk = True
        elif ph < 0.53: fx = xb - 40; walk = False
        else: fx = lerp(xb - 40, 620, ease((ph - 0.53) / 0.13)); walk = True
        hand = (fx + 1.6 * 13, 612 - 8.6 * 13)
        if ph < 0.55:
            bm = mk(); _P(bm, [hand, (xb - 30, yb - 190), (xb + 40, yb - 120)]); paint(img, bm, C3(1.0, 0.95, 0.7), 0.22 * night, 3.0)
            glow_roi(img, xb, yb - 150, 60, C3(1.0, 0.92, 0.65), 0.35 * night, 2.0)
        silhouette(img, fx, 612, 130, t, 1.0, walk, False, C3(0.02, 0.02, 0.03), ci)
        if 0.50 <= ph < 0.58:
            rs = np.random.RandomState(ci); k = (ph - 0.50) / 0.08
            over(img, mcirc([(xb + (rs.rand() - 0.5) * 60 * k, yb - 30 * k + 40 * k * k + rs.rand() * 6, 2.0) for _ in range(14)], 0.5), C3(0.30, 0.22, 0.14), 1 - k)
    img = Cam(1.02 + 0.03 * prog(t, st0(11) - 0.3, B[4]), 0, 0, 300, 470).apply(img)
    return img

def s3(t):
    t_ho = st0(9); t_tr = tw(9, 'trece'); t_se = tw(9, 'separado'); t_pa = tw(9, 'pasillo'); t_ki = tw(9, 'kilometro', 1); t_ll = st0(10); t_cr = tw(10, 'cruzar'); t_80 = st0(11); t_st = tw(11, 'stop')
    T_MAP = t_se - 0.3; T_STOP = t_80 - 0.25
    out = None
    if t < T_MAP + 0.35:
        out = photo_kb(FOT + 'llivia.jpg', t, B[3] - 0.5, T_MAP + 0.4, 1.0, 1.32, (0.50, 0.50), (0.48, 0.44))
        if t < T_MAP:
            header(t, 'LLÍVIA HOY', t_ho - 0.05, T_MAP - 0.4, 18)
            ov('FOTO: WIKIMEDIA COMMONS', 270, 150, 11, CREAM, 0.85, 'c', sh=0.6)
            if t > t_tr - 0.3:
                aa = ease((t - t_tr + 0.3) / 0.3) * (1 - ease((t - T_MAP + 0.4) / 0.3)); n = int(round(lerp(0, 13, ease(prog(t, t_tr - 0.1, t_tr + 0.9)))))
                rect(120, 470, 420, 600, None, 0.95 * aa, 0.35); ov('%d KM²' % n, 270, 518, 48, RED, aa, 'c'); ov('UN TROZO DE ESPAÑA', 270, 570, 15, INK, aa, 'c')
    if T_MAP - 0.35 < t < T_STOP + 0.35:
        dc = (lerpk(t, [(t_ll, 0.0), (t_80, 0.006)]), lerpk(t, [(t_ll, 0.0), (t_80, 0.003)]))
        img, g, rq = close_map(t, lerp(-6, 0, ease(prog(t, T_MAP - 0.3, T_MAP + 1.5))) + lerp(0, 6, ease(prog(t, t_ll, T_STOP))), dc, lerp(0.45, 1.0, ease(prog(t, t_ll - 0.3, t_ll))))
        a = ease(prog(t, T_MAP - 0.35, T_MAP + 0.35))
        if t < T_STOP:
            lx, ly = g.p(*M.LLV_C); px, py = g.p(*M.PUIG)
            over(img, mcirc([(px, py, 8)], 0.6), CREAM, 1.0); over(img, mcirc([(px, py, 5.5)], 0.6), INK, 1.0)
            p0 = g.p(*CORR[0]); p1 = g.p(*CORR[1])
            if t > t_pa - 0.3:
                ka = ease(prog(t, t_pa - 0.3, t_pa + 0.1)) * (1 - ease(prog(t, t_ll + 0.6, t_ll + 1.0)))
                m = mk(); _L(m, [p0, p1], 16); paint(img, m, C3(0.35, 0.55, 1.0), 0.35 * ka * (0.75 + 0.25 * math.sin(t * 9)), 3.0)
                kk = ease(prog(t, t_pa - 0.1, t_pa + 0.35)); q1 = (lerp(p0[0], p1[0], kk), lerp(p0[1], p1[1], kk))
                m = mk(); _L(m, [p0, q1], 4)
                nx, ny = -(p1[1] - p0[1]), (p1[0] - p0[0]); nl = math.hypot(nx, ny); nx, ny = nx / nl * 11, ny / nl * 11
                _L(m, [(p0[0] - nx, p0[1] - ny), (p0[0] + nx, p0[1] + ny)], 4)
                if kk >= 1: _L(m, [(p1[0] - nx, p1[1] - ny), (p1[0] + nx, p1[1] + ny)], 4)
                paint(img, m, BLUE_T, ka)
                mx, my = (p0[0] + p1[0]) / 2, (p0[1] + p1[1]) / 2
                tag(mx - 95, my - 75, 'PASILLO FRANCÉS', t, t_pa - 0.1, ka * a, BLUE_T, 17)
                if t > t_ki - 0.25: tag(mx - 95, my - 27, '1,5 KM', t, t_ki - 0.15, ka * a * ease((t - t_ki + 0.25) / 0.25), INK, 28, 150, 30)
            if t > t_ll - 0.3:
                k = ease(prog(t, t_ll - 0.1, T_STOP - 0.1)); x, y, tx_, ty_ = along(np.array(rq), k)
                car_top(img, x, y, math.atan2(ty_, tx_), ease(prog(t, t_ll - 0.3, t_ll)), 1.15)
                if t > t_cr - 0.3: tag(330, 190, 'CRUZANDO FRANCIA', t, t_cr - 0.15, ease((t - t_cr + 0.3) / 0.3), BLUE_T, 20)
            for (lo_, la_, nm, col, sz) in ((1.925, 42.475, 'FRANCIA', BLUE_T, 28), (1.99, 42.431, 'FRANCIA', BLUE_T, 26), (1.9055, 42.4323, 'ESPAÑA', RED * 0.85, 28)):
                q = g.p(lo_, la_); ov(nm, q[0], q[1], sz, col, a, 'c')
            tag(lx + 55, ly - 75, 'LLÍVIA', t, T_MAP + 0.1, a, RED, 26, 160)
            ov('PUIGCERDÀ', px - 4, py + 26, 17, INK, a, 'c', sh=0.0)
        out = img if out is None else out * (1 - a) + img * a
    if t > T_STOP - 0.35:
        img = stop_scene(t)
        a = ease(prog(t, T_STOP - 0.35, T_STOP + 0.35))
        out = img if out is None or a >= 1 else out * (1 - a) + img * a
        if t > T_STOP:
            t_st, T0, P, ci, ph = stop_state(t)
            header(t, 'AÑOS 70', t_80 - 0.05, B[4] - 0.5, 12)
            recre(t, 0.8, CREAM)
            if t > t_st - 0.1:
                dn = 1 + (0 if t < T0 else min(2, int((t - T0) / P + 0.38)))
                rect(26, 150, 186, 204, None, 0.92, 0.3); ov('DÍA %d' % dn, 106, 177, 26, INK, 1.0, 'c')
            if t >= T0 and ci < 2 and 0.64 < ph < 0.98:
                tag(420, 462, '¡ARRANCADA!', t, T0 + ci * P + 0.62 * P, ease((ph - 0.64) / 0.06) * (1 - ease((ph - 0.93) / 0.05)), RED, 24, None, 40)
            sp('LA GUERRA DE LOS STOPS', 52, RED, -5, 270, 268, st1(12) + 0.05, 0.97)
    return out


# ===================================================== S4 · cierre
def s4(t):
    t_to = st0(13); t_q = st0(14); t_su = tw(15, 'suscribete'); t_de = tw(15, 'descubrir')
    T_MAP = t_q + 0.45
    out = None
    if t < T_MAP + 0.35:
        out = photo_kb(FOT + 'llivia.jpg', t, B[4] - 0.7, T_MAP + 0.4, 1.18, 1.0, (0.47, 0.42), (0.50, 0.50)) * 0.7
        a = ease((t - t_to + 0.2) / 0.3) * (1 - ease((t - t_q + 0.45) / 0.3))
        if a > 0.003:
            rect(60, 180, 480, 290, None, 0.95 * a, 0.35); ov('TODO, POR UNA', 270, 215, 30, INK, a, 'c', n=tn('TODO, POR UNA', t, t_to, 16)); ov('SOLA PALABRA', 270, 258, 30, INK, a, 'c', n=tn('SOLA PALABRA', t, tw(13, 'sola'), 16))
        if t > st1(13) - 0.05:
            ap = ease((t - st1(13) + 0.05) / 0.12) * (1 - ease((t - T_MAP + 0.3) / 0.3))
            rect(70, 368, 470, 512, None, 0.95 * ap, 0.4)
        sp('«VILLA»', 84, RED, -6, 270, 440, st1(13) + 0.05, 0.97 * (1 - ease((t - T_MAP + 0.3) / 0.3)))
    if t > T_MAP - 0.35:
        s = logk(t, [(T_MAP - 0.35, 42.0), (T_MAP + 3.6, 0.42), (TEND, 0.38)])
        u = ease(prog(t, T_MAP, T_MAP + 3.6))
        g = M.Geo(M.LLV_C[0] + 14 * u / (s * M.KX), M.LLV_C[1] + 51 * u / (s * M.KY), s)
        img = M.geomap(g, spain=0.55, france=0.5, relief=lerp(0.75, 1.0, u))
        x, y = g.p(*M.LLV_C)
        if s < 8: over(img, mcirc([(x, y, 7)], 0.6), CREAM, 1.0); over(img, mcirc([(x, y, 5)], 0.6), RED, 1.0)
        pulse(img, x, y, t, RED, 1.0, 8, 70, 1.1, 3, 2)
        a = ease(prog(t, T_MAP - 0.35, T_MAP + 0.35))
        out = img if out is None or a >= 1 else out * (1 - a) + img * a
        aq = ease((t - t_q + 0.2) / 0.3) * (1 - ease((t - t_su + 0.4) / 0.4))
        if aq > 0.003:
            rect(30, 200, 510, 300, None, 0.95 * aq, 0.3); ov('¿CONOCÍAS LLÍVIA?', 270, 250, 38, RED, aq, 'c', n=tn('¿CONOCÍAS LLÍVIA?', t, t_q, 16))
        if t > t_su - 0.1:
            a = ease((t - t_su + 0.1) / 0.4)
            rect(26, 150, 514, 226, RED, 0.96 * a, 0.35); ov('SUSCRÍBETE', 270, 188, 44, CREAM, a, 'c', n=tn('SUSCRÍBETE', t, t_su, 12))
            if t > t_de - 0.1:
                a2 = ease((t - t_de + 0.1) / 0.4); rect(26, 240, 514, 322, None, 0.95 * a2, 0.3)
                ov('PARA DESCUBRIR MÁS HISTORIAS', 270, 268, 20, INK, a2, 'c', n=tn('PARA DESCUBRIR MÁS HISTORIAS', t, t_de, 18)); ov('COMO ESTA', 270, 302, 28, RED, a2, 'c', n=tn('COMO ESTA', t, tw(15, 'como'), 12))
    return out

SC = [s0, s1, s2, s3, s4]
