import sys, json
sys.path.insert(0, '/home/claude/serie/llivia')
from ll_audio_lib import *
import ll_audio_lib as AL
EV = json.load(open('/home/claude/serie/llivia/events.json'))
def _e(x): x = np.clip(x, 0, 1); return x * x * (3 - 2 * x)

# ---------- piezas nuevas
def riser(t0, t1, g=0.2, f0=60, f1=420, noise=0.35):
    n = int((t1 - t0) * SR); t = tt(n); x = np.linspace(0, 1, n) ** 2.2; f = f0 + (f1 - f0) * x; ph = 2 * np.pi * np.cumsum(f) / SR
    s = (np.sin(ph) + 0.5 * np.sin(1.5 * ph + 1)) * 0.6 + noise * bp(nz(n), 300, 5000) * x
    add((s * x ** 0.6 * g).astype(np.float32), t0, 0.0, 1.0, 0.25, True)
def reverse_hit(t_hit, dur=0.9, g=0.3):
    n = int(dur * SR); t = tt(n); s = bp(nz(n), 400, 7000) * (np.linspace(0, 1, n) ** 2.5); add((s * g).astype(np.float32), t_hit - dur, 0.0, 1.0, 0.3)
def glitch(t0, t1, g=0.3, dens=60):
    n = int(dens * (t1 - t0))
    for j in range(n):
        tj = t0 + (t1 - t0) * (j / max(n, 1)) ** 0.8 + rng.rand() * 0.01
        add(click(600 + rng.rand() * 5000, 0.004 + 0.01 * rng.rand(), g * (0.5 + 0.5 * rng.rand())), tj, rng.rand() * 1.6 - 0.8)
def sonar(t0, f=1050, g=0.3, dec=2.4, pan=0.0):
    n = int(dec * SR); t = tt(n); s = np.sin(2 * np.pi * f * t) * np.exp(-t * 3.0) * np.minimum(1, t / 0.01) + 0.35 * np.sin(2 * np.pi * f * 1.5 * t) * np.exp(-t * 5.5)
    add((s * g).astype(np.float32), t0, pan, 1.0, 0.7)
def chirp(t0, f0=1200, f1=3200, dur=0.07, g=0.2, pan=0.0):
    n = int(dur * SR); t = tt(n); f = f0 + (f1 - f0) * t / dur; s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.minimum(1, t / 0.004) * np.minimum(1, (dur - t) / 0.01)
    add((s * g).astype(np.float32), t0, pan, 1.0, 0.2)
def step_snd(g=1.0, f=85):
    n = int(0.17 * SR); t = tt(n); s = np.sin(2 * np.pi * np.cumsum(f * (1 + 0.6 * np.exp(-t * 30))) / SR) * np.exp(-t * 22) + 0.45 * bp(nz(n), 300, 2400) * np.exp(-t * 55) + 0.2 * lp(nz(n), 600) * np.exp(-t * 25)
    return (s * g).astype(np.float32)
def stomps(t0, t1, hz, g_fn, v_fn, spread=1.4):
    t = t0
    while t < t1:
        g = g_fn(t); nv = int(max(1, round(v_fn(t))))
        for v in range(nv): add(step_snd(g * (0.55 + 0.45 * rng.rand()), 65 + rng.rand() * 45), t + rng.randn() * 0.014, (rng.rand() - 0.5) * spread, 1.0, 0.10)
        t += 1.0 / hz
def tom(t0, f=95, g=0.5, pan=0.0):
    n = int(0.45 * SR); t = tt(n); s = np.sin(2 * np.pi * np.cumsum(f * (1 + 0.8 * np.exp(-t * 20))) / SR) * np.exp(-t * 9) + 0.3 * bp(nz(n), 400, 2500) * np.exp(-t * 40)
    add((s * g).astype(np.float32), t0, pan, 1.0, 0.3)
def pluck(t0, f, g=0.18, dur=0.5, pan=0.0):
    n = int(dur * SR); t = tt(n); s = (2 * np.abs(2 * ((f * t) % 1) - 1) - 1) * 0.6 + 0.3 * np.sin(2 * np.pi * f * 2 * t); s = lp(s, 2200) * np.exp(-t * 7) * np.minimum(1, t / 0.003)
    add((s * g).astype(np.float32), t0, pan, 1.0, 0.35)
def drip(t0, g=0.14):
    n = int(0.14 * SR); t = tt(n); f = rng.uniform(1100, 2200) * np.exp(-t * rng.uniform(6, 14)); s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 28)
    add((s * g).astype(np.float32), t0, rng.rand() * 1.6 - 0.8, 1.0, 0.3)
def clop(t0, g=0.22, pan=0.0):
    n = int(0.12 * SR); t = tt(n); s = (np.sin(2 * np.pi * 720 * t) * 0.5 + bp(nz(n), 500, 3500) * 0.8) * np.exp(-t * 50)
    add((s * g).astype(np.float32), t0, pan, 1.0, 0.18)
def bird(t0, g=0.06):
    k = rng.randint(2, 5); t_ = t0
    for j in range(k): chirp(t_, rng.uniform(2800, 4200), rng.uniform(3200, 5200), rng.uniform(0.05, 0.10), g, rng.rand() * 1.4 - 0.7); t_ += rng.uniform(0.08, 0.16)

# ---------- máquina de escribir, fotos y sellos
for (text, t0, cps) in EV['tn']:
    typing(t0, len(text), cps, 0.42 if cps >= 14 else 0.38)
for (name, t0, t1) in EV['ph']:
    pan = 0.0
    shutter(t0, 0.7, pan); n_ = int(0.17 * SR); add(bp(nz(n_), 500, 6000) * (np.linspace(0, 1, n_) ** 2) * 0.22, t0, pan, 1.0, 0.1)
    add(thud(0.75, 0.5), t0 + 0.16, pan, 1.0, 0.2); add(bp(nz(int(0.07 * SR)), 700, 6000) * np.exp(-tt(int(0.07 * SR)) * 45) * 0.6, t0 + 0.16, pan, 1.0)
for (text, t0) in EV['sp']:
    stampthud(t0 + 0.14, 0.8)


# ================= piezas nuevas para Cervantes
def boom(t0, g=0.4, pan=0.0, dist=0.0):
    n = int(2.2 * SR); t = tt(n); f = 38 + 50 * np.exp(-t * 9)
    s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 3.2) + 0.9 * lp(nz(n), 420 - 220 * dist) * np.exp(-t * (4.5 - 2 * dist)) + (1 - dist) * 0.5 * bp(nz(n), 900, 5000) * np.exp(-t * 40)
    add((s * g).astype(np.float32), t0, pan, 1.0, 0.45 + 0.3 * dist)
def crack(t0, g=0.6, pan=0.0):
    n = int(0.9 * SR); t = tt(n)
    s = 1.2 * bp(nz(n), 1200, 9000) * np.exp(-t * 70) + 0.8 * lp(nz(n), 600) * np.exp(-t * 12) + np.sin(2 * np.pi * np.cumsum(70 + 80 * np.exp(-t * 30)) / SR) * np.exp(-t * 9)
    add((s * g).astype(np.float32), t0, pan, 1.0, 0.5)
def clang(t0, f=380, g=0.3, pan=0.0, dec=2.5):
    n = int(dec * SR); t = tt(n); s = np.zeros(n, np.float32)
    for k, (m, a) in enumerate(((1.0, 1.0), (2.32, 0.6), (3.86, 0.4), (5.41, 0.25), (6.9, 0.15))):
        s += a * np.sin(2 * np.pi * f * m * t + k) * np.exp(-t * (2.2 + 1.6 * k) * 2.5 / dec)
    s = s * np.minimum(1, t / 0.002) + 0.4 * bp(nz(n), 2000, 9000) * np.exp(-t * 80)
    add((s * g * 0.5).astype(np.float32), t0, pan, 1.0, 0.4)
def chains(t0, dur=0.8, g=0.2, pan=0.0):
    k = int(dur * 22)
    for j in range(k): clang(t0 + dur * (j / k) + rng.rand() * 0.03, rng.uniform(1800, 3600), g * rng.uniform(0.4, 1.0), pan + rng.rand() * 0.4 - 0.2, 0.25)
def coins(t0, n=12, g=0.15, dur=0.9):
    for j in range(n): clang(t0 + dur * (j / n) ** 1.4 + rng.rand() * 0.02, rng.uniform(2600, 4800), g * rng.uniform(0.5, 1.0), rng.rand() * 1.0 - 0.5, 0.35)
def wind(t0, t1, g=0.12):
    n = int((t1 - t0) * SR); t = tt(n)
    s = lp(nz(n), 700) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.13 * t) ** 2) + 0.25 * bp(nz(n), 900, 2600) * (0.3 + 0.7 * np.sin(2 * np.pi * 0.09 * t + 1) ** 4)
    add((s * swell(n, 1.0, 1.0) * g).astype(np.float32), t0, 0.0, 1.0, 0.05, True)
def gallop(t0, t1, g=0.22, pan0=-0.6, pan1=0.2):
    t = t0
    while t < t1:
        p = pan0 + (pan1 - pan0) * (t - t0) / max(1e-3, t1 - t0)
        for dt in (0.0, 0.09, 0.19): clop(t + dt, g * rng.uniform(0.7, 1.0), p)
        t += 0.42
def scratch(t0, dur=1.2, g=0.12):
    n = int(dur * SR); t = tt(n); e = np.zeros(n, np.float32); k = 0
    while k < n:
        l = int(rng.uniform(0.05, 0.16) * SR); e[k:k + l] = np.sin(np.linspace(0, np.pi, len(e[k:k + l]))) * rng.uniform(0.5, 1.0); k += l + int(rng.uniform(0.02, 0.08) * SR)
    add((bp(nz(n), 2500, 8000) * e * g).astype(np.float32), t0, 0.15, 1.0, 0.15)
def murmur(t0, t1, g=0.08):
    n = int((t1 - t0) * SR); t = tt(n); s = np.zeros(n, np.float32)
    for k in range(6): s += bp(nz(n), rng.uniform(250, 500), rng.uniform(900, 1500)) * (0.3 + 0.7 * np.abs(np.sin(2 * np.pi * rng.uniform(2, 5) * t + k)))
    add((s / 6 * swell(n, 0.8, 0.8) * g).astype(np.float32), t0, 0.0, 1.0, 0.2, True)
def oars(t0, t1, g=0.10, per=1.6):
    t = t0
    while t < t1:
        n = int(0.7 * SR); tq = tt(n); s = bp(nz(n), 300, 2400) * np.sin(np.pi * tq / tq[-1]) ** 3
        add((s * g).astype(np.float32), t, rng.rand() * 0.6 - 0.3, 1.0, 0.1)
        if rng.rand() < 0.4: creak(t + 0.2, g * 0.6)
        t += per
def steps(t0, n, hz, g=0.22, pan0=0.0, pan1=0.0, f=95):
    for j in range(n): add(step_snd(g * rng.uniform(0.8, 1.0), f + rng.rand() * 20), t0 + j / hz, pan0 + (pan1 - pan0) * j / max(1, n - 1), 1.0, 0.1)
def war_drums(t0, t1, bpm=100, g=0.3):
    t = t0; k = 0; b = 60.0 / bpm
    while t < t1:
        pat = (1.0, 0.0, 0.6, 0.6)[k % 4]
        if pat: tom(t, 90 if k % 4 == 0 else 120, g * pat, -0.2 if k % 2 else 0.2)
        t += b / 2; k += 1
ANDA = [(146.8, 174.6, 220.0), (130.8, 164.8, 196.0), (116.5, 146.8, 174.6), (110.0, 138.6, 164.8)]
def lute(t0, t1, bpm=84, g=0.09):
    b = 60.0 / bpm; t = t0; k = 0
    while t < t1:
        ch = ANDA[(k // 8) % 4]; pat = [0, 1, 2, 1, 0, 2, 1, 2][k % 8]; f = ch[pat] * (2 if k % 8 in (2, 5) else 1)
        fade = min(1.0, (t - t0) / 1.5, (t1 - t) / 1.5)
        pluck(t, f, g * max(0.0, fade), 0.6, -0.25 + 0.5 * (pat / 2)); 
        if k % 8 == 0: pluck(t, ch[0] / 2, g * 0.8 * max(0.0, fade), 1.2, 0.0)
        t += b / 2; k += 1

def W(si, p, n=0): return tw(si, p, n)


# ================= piezas líquidas y de madera
def roar(t0, t1, g=0.3, fc=260, a_in=0.05, a_out=2.5, pan=0.0):
    n = int((t1 - t0) * SR); t = tt(n)
    am = lp(np.abs(nz(n)), 18); am = am / (np.abs(am).max() + 1e-9)
    s = 1.0 * lp(nz(n), fc) + 0.55 * bp(nz(n), 400, 2600) * (0.4 + 0.6 * am) + 0.18 * bp(nz(n), 3000, 8000) * (0.3 + 0.7 * am)
    s = s * swell(n, a_in, a_out)
    add((s * g * 1.3).astype(np.float32), t0, pan, 1.0, 0.2, True)
def gush(t0, g=0.6, dur=1.6, pan=0.0):
    n = int(dur * SR); t = tt(n); fc = 5000 * np.exp(-t * 3) + 200
    s = np.zeros(n, np.float32); x = nz(n)
    for k, (a_, b_) in enumerate(((150, 600), (600, 2000), (2000, 7000))):
        s += bp(x, a_, b_) * np.exp(-t * (1.2 + k * 1.5)) * (1.2 - 0.3 * k)
    s *= np.minimum(1, t / 0.01)
    add((s * g).astype(np.float32), t0, pan, 1.0, 0.4)
def splash(t0, g=0.25, pan=0.0):
    n = int(0.5 * SR); t = tt(n); s = bp(nz(n), 300, 5000) * np.exp(-t * 9) * np.minimum(1, t / 0.005)
    add((s * g).astype(np.float32), t0, pan, 1.0, 0.25)
    for j in range(6): add(click(rng.uniform(1500, 5000), 0.006, g * 0.3), t0 + 0.05 + rng.rand() * 0.4, pan + rng.rand() * 0.4 - 0.2)
def groan(t0, dur=1.4, g=0.3, f0=70, pan=0.0):
    n = int(dur * SR); t = tt(n); f = f0 * (1 + 0.25 * np.sin(2 * np.pi * 0.7 * t) + 0.1 * rng.randn() + 0.4 * t / dur)
    saw = 2 * ((np.cumsum(f) / SR) % 1) - 1
    s = bp(saw * (0.6 + 0.4 * np.abs(np.sin(2 * np.pi * 9 * t))), 80, 900) * np.sin(np.pi * t / dur) ** 1.5
    add((s * g).astype(np.float32), t0, pan, 1.0, 0.3)
def scrape(t0, dur=0.35, g=0.25):
    n = int(dur * SR); t = tt(n); s = bp(nz(n), 1500, 7000) * np.sin(np.pi * t / dur) * (0.5 + 0.5 * np.sin(2 * np.pi * 60 * t))
    add((s * g).astype(np.float32), t0, 0.2, 1.0, 0.2)
def bricks(t0, dur=1.6, g=0.5):
    n = int(dur * SR); t = tt(n); add((lp(nz(n), 900) * np.exp(-t * 2.2) * g * 0.6).astype(np.float32), t0, 0.0, 1.0, 0.3)
    for j in range(26): add(thud(g * rng.uniform(0.25, 0.7), 0.35), t0 + dur * rng.rand() ** 1.6, rng.rand() * 1.4 - 0.7, 1.0, 0.25)
def knock(t0, g=0.3, pan=0.0):
    n = int(0.25 * SR); t = tt(n); s = np.sin(2 * np.pi * 180 * t) * np.exp(-t * 30) + 0.5 * bp(nz(n), 400, 2500) * np.exp(-t * 60)
    add((s * g).astype(np.float32), t0, pan, 1.0, 0.2)
def hiss(t0, g=0.08):
    n = int(0.5 * SR); t = tt(n); add((bp(nz(n), 3000, 9000) * np.exp(-t * 7) * g).astype(np.float32), t0, rng.rand() * 0.6 - 0.3, 1.0, 0.1)
def pour(t0, t1, g=0.2):
    n = int((t1 - t0) * SR); t = tt(n); s = bp(nz(n), 300, 2500) * (0.5 + 0.5 * np.abs(np.sin(2 * np.pi * 6 * t))) * swell(n, 0.3, 0.6)
    add((s * g).astype(np.float32), t0, 0.0, 1.0, 0.2)
    tk = t0
    while tk < t1: bubble(tk, 0.10); tk += rng.uniform(0.06, 0.16)
def bubblewhoosh(tc, g=0.25):
    whoosh(tc - 0.7, 1.4, g * 0.6, 200, 3000)
    for j in range(40): bubble(tc - 0.6 + 1.2 * rng.rand(), g * 0.5)


def W(si, p, n=0): return tw(si, p, n)
def thunder(t0, g=0.4, pan=0.0):
    n = int(3.0 * SR); t = tt(n); s = lp(nz(n), 300) * np.exp(-t * 1.2) * (0.6 + 0.4 * np.abs(np.sin(2 * np.pi * 3 * t))) + 0.6 * bp(nz(n), 600, 4000) * np.exp(-t * 12)
    add((s * g).astype(np.float32), t0, pan, 1.0, 0.5)
def rain(t0, t1, g=0.08):
    n = int((t1 - t0) * SR); add((bp(nz(n), 2000, 9000) * swell(n, 0.8, 0.8) * g).astype(np.float32), t0, 0.0, 1.0, 0.05, True)
def fire(t0, t1, g=0.12):
    tk = t0
    while tk < t1: add(click(rng.uniform(1500, 6000), 0.004, g * rng.uniform(0.3, 1.0)), tk, rng.rand() * 1.0 - 0.5); tk += rng.exponential(0.035)
    n = int((t1 - t0) * SR); add((lp(nz(n), 500) * swell(n, 0.4, 0.4) * g * 0.6).astype(np.float32), t0, 0.0, 1.0, 0.1, True)
# ================= cues de Llívia (se concatena tras ll_audio_head.py)
B[3] = st0(9) - 0.48; B[4] = st0(13) - 0.4
def W(si, p, n=0): return tw(si, p, n)

def engine(t0, t1, g=0.12, f0=48, f1=62, pans=(-0.5, 0.5)):
    n = int((t1 - t0) * SR); t = tt(n); k = t / max(1e-3, t[-1]); f = f0 + (f1 - f0) * k + 3 * np.sin(2 * np.pi * 0.7 * t)
    ph = np.cumsum(f) / SR; saw = 2 * (ph % 1) - 1
    s = lp(saw, 420) * 0.8 + 0.35 * lp(nz(n), 300) + 0.15 * bp(nz(n), 900, 2500) * (0.5 + 0.5 * np.sin(2 * np.pi * f * 2 * t))
    s = s * swell(n, 0.5, 0.6)
    m = 6
    for j in range(m):
        a_, b_ = j * n // m, (j + 1) * n // m; seg = s[a_:b_] * np.hanning(b_ - a_ + 2)[1:-1] ** 0.0
        add((seg * g).astype(np.float32), t0 + a_ / SR, pans[0] + (pans[1] - pans[0]) * (j + 0.5) / m, 1.0, 0.1)
def crickets(t0, t1, g=0.05):
    tk = t0
    while tk < t1:
        f = rng.uniform(4200, 4800); pan = rng.rand() * 1.6 - 0.8
        for p in range(3):
            n = int(0.016 * SR); t = tt(n); s = np.sin(2 * np.pi * f * t) * np.sin(np.pi * t / t[-1])
            add((s * g * rng.uniform(0.5, 1.0)).astype(np.float32), tk + p * 0.035, pan, 1.0, 0.2, True)
        tk += rng.uniform(0.06, 0.16)
def chime(t0, f=880, g=0.12):
    bell(t0, f, g); bell(t0 + 0.02, f * 1.5, g * 0.45)
def pen(t0, dur=0.3, g=0.14):
    n = int(dur * SR); t = tt(n); s = bp(nz(n), 2500, 8000) * np.sin(np.pi * t / dur) ** 0.5 * (0.6 + 0.4 * np.sin(2 * np.pi * 30 * t))
    add((s * g).astype(np.float32), t0, 0.1, 1.0, 0.15)

# ---------- música
subdrone(0.0, B[1] + 1.0, 36.7, 0.18, 0.2, 2); drone([73.4, 110.0, 174.6], 0.0, B[1] + 1.0, 0.05, 700, 0.3, 2)
subdrone(B[1] - 0.5, B[2] + 1.0, 32.7, 0.15, 2, 2); drone([65.4, 98.0, 130.8, 164.8], B[1] - 0.5, B[2] + 1.0, 0.045, 800, 2, 2)
subdrone(B[2] - 0.5, B[3] + 1.0, 30.9, 0.18, 2, 2); drone([61.7, 92.5, 146.8], B[2] - 0.5, B[3] + 1.0, 0.05, 520, 2, 2)
subdrone(B[3] - 0.5, B[4] + 1.0, 36.7, 0.14, 2, 2); drone([73.4, 110.0, 146.8, 185.0], B[3] - 0.5, B[4] + 1.0, 0.04, 900, 2, 2)
subdrone(B[4] - 0.5, TEND + 0.4, 36.7, 0.15, 2, 4); drone([73.4, 110.0, 146.8, 220.0], B[4] - 0.5, TEND + 0.4, 0.045, 900, 2, 4)

# ---------- S0 · gancho: zoom de Europa a Llívia
riser(0.0, 1.2, 0.22, 60, 520, 0.4)
whoosh(0.8, 3.9, 0.14, 180, 2600); riser(1.6, W(0, 'francia'), 0.16, 80, 700, 0.5)
sonar(W(0, 'pueblo') - 0.05, 1050, 0.14, 1.8)
boom(W(0, 'francia') + 0.02, 0.40, 0.0, 0.2); add(thud(0.7, 1.0), W(0, 'francia') + 0.02, 0.0, 1.0, 0.4)
heart(W(0, 'francia') + 0.4, W(1, 'pirineo'), 72, 72, 0.18)
sonar(W(1, 'llivia') - 0.1, 880, 0.14, 2.0)
wind(W(0, 'francia'), B[1] + 0.8, 0.10)
whoosh(W(1, 'pirineo') - 0.5, 0.7, 0.14, 300, 4500); shutter(W(1, 'pirineo') - 0.05, 0.5, 0.0)
for j in range(4): bird(W(1, 'pirineo') + 0.2 + j * 0.25, 0.035)

# ---------- S1 · el tratado
paper(B[1], 1.2, 0.35); whoosh(B[1] - 0.5, 1.0, 0.10, 300, 4000)
boom(st0(2) - 0.02, 0.32, 0.0, 0.4); bell(st0(2) + 0.05, 220, 0.10); bell(st0(2) + 0.05, 330, 0.05)
murmur(st0(2) + 0.4, st0(4) - 0.2, 0.06)
bell(W(3, 'paz') + 0.1, 523, 0.06); bell(W(3, 'paz') + 0.1, 784, 0.04)
whoosh(st0(4) - 0.6, 0.9, 0.12, 200, 3500); paper(st0(4) - 0.3, 1.0, 0.25)
riser(W(4, 'queda') - 0.1, W(4, 'rosellon') + 0.5, 0.12, 90, 500, 0.6); add(thud(0.6, 0.8), W(4, 'rosellon') + 0.5, 0.0, 1.0, 0.3)
whoosh(W(4, 'rosellon') + 0.5, 1.4, 0.10, 200, 3000)
tf = [W(4, 'treinta') - 0.05 + ((W(4, 'cerdana') + 0.25) - (W(4, 'treinta') - 0.05)) * (32 - j) / 32.0 for j in range(33)]
for i_, tk in enumerate(sorted(tf)): add(tick(900 + 18 * i_, 0.11), tk, -0.5 + i_ / 32.0)
sonar(W(4, 'cerdana') + 0.35, 660, 0.16, 2.2)

# ---------- S2 · villa
heart(st0(5) - 0.4, st0(7) - 0.2, 64, 72, 0.16)
pen(W(5, 'pueblo') + 0.05, 0.32, 0.16)
chime(W(6, 'carlos') - 0.2, 660, 0.08); chime(W(6, 'carlos') - 0.05, 990, 0.05)
bell(st1(6) + 0.2, 392, 0.10); bell(st1(6) + 0.2, 587, 0.06)
whoosh(st0(7) + 0.0, 0.8, 0.10, 300, 3500); paper(st0(7) + 0.2, 1.2, 0.35)
fire(st0(7) + 0.1, st0(8) + 0.2, 0.08)
whoosh(st0(7) + 0.5, 0.6, 0.05, 600, 5000); whoosh(st0(7) + 1.3, 0.8, 0.05, 600, 5000)
chime(W(7, 'palabra') - 0.02, 1046, 0.10); pen(W(7, 'palabra') + 0.05, 0.35, 0.12)
whoosh(st0(8) - 0.7, 0.9, 0.12, 200, 3500)
bell(st1(8) + 0.25, 294, 0.12); bell(st1(8) + 0.25, 440, 0.07)

# ---------- S3 · hoy
whoosh(B[3] - 0.4, 0.9, 0.12, 300, 4000); shutter(B[3] + 0.05, 0.45, 0.0)
wind(B[3] - 0.2, W(9, 'separado'), 0.07); for_b = [bird(B[3] + 0.4 + j * 0.6, 0.03) for j in range(4)]
tk = W(9, 'trece') - 0.1; i_ = 0
while tk < W(9, 'trece') + 0.9: add(tick(1000 + 30 * i_, 0.10), tk, 0.0); tk += 0.07; i_ += 1
whoosh(W(9, 'separado') - 0.6, 0.9, 0.12, 200, 3500)
pen(W(9, 'pasillo') - 0.05, 0.4, 0.12); ping(W(9, 'kilometro', 1) - 0.05, 1250, 0.18)
engine(st0(10) - 0.2, st0(11) - 0.1, 0.10, 46, 64, (-0.6, 0.6))
whoosh(st0(11) - 0.6, 0.9, 0.12, 200, 3500)
wind(st0(11) - 0.3, B[4] + 0.4, 0.05)
engine(st0(11) - 0.3, W(11, 'stop') - 0.1, 0.07, 60, 50, (0.1, 0.0))
t_st = W(11, 'stop'); T0 = t_st + 0.32; P = 1.5
clang(t_st + 0.02, 520, 0.22, 0.5, 1.6); add(thud(0.5, 0.6), t_st + 0.02, 0.5, 1.0, 0.2)
for ci in range(2):
    c0 = T0 + ci * P
    whoosh(c0 + 0.12 * P, 0.4 * P, 0.07, 300, 3000)
    crickets(c0 + 0.25 * P, c0 + 0.66 * P, 0.035)
    steps(c0 + 0.36 * P, 5, 6.0, 0.08, -0.2, 0.4)
    crack(c0 + 0.50 * P + 0.02, 0.35, 0.5); add(thud(0.5, 0.5), c0 + 0.56 * P, 0.5, 1.0, 0.2)
    bird(c0 + 0.70 * P, 0.05); bird(c0 + 0.80 * P, 0.04)
    if ci == 0: clang(c0 + P + 0.02, 560, 0.20, 0.5, 1.4)
clang(T0 + 2 * P + 0.02, 600, 0.22, 0.5, 1.6)
for j in range(10): pluck(t_st + 0.3 + j * 0.3, (220, 262, 330, 262, 220, 196, 220, 262, 330, 392)[j], 0.07, 0.4, -0.3 + 0.06 * j)

# ---------- S4 · cierre
whoosh(B[4] - 0.5, 1.0, 0.10, 300, 4000)
boom(st1(13) + 0.18, 0.30, 0.0, 0.3)
whoosh(st0(14) + 0.3, 3.6, 0.12, 150, 2500)
sonar(st0(14) + 0.1, 660, 0.14, 2.4)
t_su = W(15, 'suscribete'); bell(t_su - 0.05, 1568, 0.14); bell(t_su + 0.28, 2093, 0.12); bell(t_su + 0.28, 1046, 0.05)

# ---------- mezcla final
def rev(x):
    n_ir = int(2.6 * SR); ir_ = (rng.randn(n_ir) * np.exp(-np.arange(n_ir) / SR / 0.75)).astype(np.float32); ir_ = lp(ir_, 5200); ir_ = np.concatenate([np.zeros(int(0.03 * SR), np.float32), ir_])
    y = fftconvolve(x, ir_)[:N]; return y / (np.abs(y).max() + 1e-9)
SL, SR_, L, R, AMB, VOZ, DUCK = AL.SL, AL.SR_, AL.L, AL.R, AL.AMB, AL.VOZ, AL.DUCK
wl = rev(SL); wr_ = rev(SR_)
amb = AMB * DUCK[None, :]
HK = 1 + 0.4 * np.clip((2.3 - tt(N)) / 0.3, 0, 1)
fxL = (L * (0.55 + 0.45 * DUCK) + amb[0]) * HK; fxR = (R * (0.55 + 0.45 * DUCK) + amb[1]) * HK
fxL = fxL + 0.30 * wl * np.abs(SL).max() * 6 * DUCK; fxR = fxR + 0.30 * wr_ * np.abs(SR_).max() * 6 * DUCK
mixL = VOZ * 1.2 + np.tanh(fxL * 1.2) / 1.2 * 0.80; mixR = VOZ * 1.2 + np.tanh(fxR * 1.2) / 1.2 * 0.80
mixL = np.tanh(mixL * 1.0) / np.tanh(1.0); mixR = np.tanh(mixR * 1.0) / np.tanh(1.0)
HG = 1 + 0.2 * np.clip((2.35 - tt(N)) / 0.35, 0, 1); mixL *= HG; mixR *= HG
pk = max(np.abs(mixL).max(), np.abs(mixR).max()); mixL *= 0.92 / pk; mixR *= 0.92 / pk
fade = np.clip(tt(N) / 0.25, 0, 1) * np.clip((TEND + 0.4 - tt(N)) / 2.2, 0, 1); mixL *= fade; mixR *= fade
st = np.stack([mixL, mixR], 1)[:int((TEND + 0.1) * SR)]
wv = wave.open('/home/claude/serie/llivia/ll_audio_raw.wav', 'wb'); wv.setnchannels(2); wv.setsampwidth(2); wv.setframerate(SR); wv.writeframes((np.clip(st, -1, 1) * 32767).astype(np.int16).tobytes()); wv.close()
print('ok', round(float(np.sqrt((st ** 2).mean())), 3), 'voz rms', round(float(np.sqrt((VOZ ** 2).mean())), 3))
