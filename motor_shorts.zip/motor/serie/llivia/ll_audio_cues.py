# ================= cues de Llívia (se concatena tras ll_audio_head.py)
B[3] = st0(9) - 0.48; B[4] = st0(13) - 0.4
def W(si, p, n=0): return tw(si, p, n)

def engine(t0, t1, g=0.12, f0=48, f1=62, pans=(-0.5, 0.5)):
    n = int((t1 - t0) * SR); t = tt(n); k = t / max(1e-3, t[-1]); f = f0 + (f1 - f0) * k + 3 * np.sin(2 * np.pi * 0.7 * t)
    ph = np.cumsum(f) / SR; saw = 2 * (ph % 1) - 1
    s = lp(saw, 420) * 0.8 + 0.35 * lp(nz(n), 300) + 0.15 * bp(nz(n), 900, 2500) * (0.5 + 0.5 * np.sin(2 * np.pi * f * 2 * t))
    s = s * swell(n, 0.5, 0.6)
    m = 6
    for j in range(m):
        a_, b_ = j * n // m, (j + 1) * n // m; seg = s[a_:b_] * np.hanning(b_ - a_ + 2)[1:-1] ** 0.0
        add((seg * g).astype(np.float32), t0 + a_ / SR, pans[0] + (pans[1] - pans[0]) * (j + 0.5) / m, 1.0, 0.1)
def crickets(t0, t1, g=0.05):
    tk = t0
    while tk < t1:
        f = rng.uniform(4200, 4800); pan = rng.rand() * 1.6 - 0.8
        for p in range(3):
            n = int(0.016 * SR); t = tt(n); s = np.sin(2 * np.pi * f * t) * np.sin(np.pi * t / t[-1])
            add((s * g * rng.uniform(0.5, 1.0)).astype(np.float32), tk + p * 0.035, pan, 1.0, 0.2, True)
        tk += rng.uniform(0.06, 0.16)
def chime(t0, f=880, g=0.12):
    bell(t0, f, g); bell(t0 + 0.02, f * 1.5, g * 0.45)
def pen(t0, dur=0.3, g=0.14):
    n = int(dur * SR); t = tt(n); s = bp(nz(n), 2500, 8000) * np.sin(np.pi * t / dur) ** 0.5 * (0.6 + 0.4 * np.sin(2 * np.pi * 30 * t))
    add((s * g).astype(np.float32), t0, 0.1, 1.0, 0.15)

# ---------- música
subdrone(0.0, B[1] + 1.0, 36.7, 0.18, 0.2, 2); drone([73.4, 110.0, 174.6], 0.0, B[1] + 1.0, 0.05, 700, 0.3, 2)
subdrone(B[1] - 0.5, B[2] + 1.0, 32.7, 0.15, 2, 2); drone([65.4, 98.0, 130.8, 164.8], B[1] - 0.5, B[2] + 1.0, 0.045, 800, 2, 2)
subdrone(B[2] - 0.5, B[3] + 1.0, 30.9, 0.18, 2, 2); drone([61.7, 92.5, 146.8], B[2] - 0.5, B[3] + 1.0, 0.05, 520, 2, 2)
subdrone(B[3] - 0.5, B[4] + 1.0, 36.7, 0.14, 2, 2); drone([73.4, 110.0, 146.8, 185.0], B[3] - 0.5, B[4] + 1.0, 0.04, 900, 2, 2)
subdrone(B[4] - 0.5, TEND + 0.4, 36.7, 0.15, 2, 4); drone([73.4, 110.0, 146.8, 220.0], B[4] - 0.5, TEND + 0.4, 0.045, 900, 2, 4)

# ---------- S0 · gancho: zoom de Europa a Llívia
riser(0.0, 1.2, 0.22, 60, 520, 0.4)
whoosh(0.8, 3.9, 0.14, 180, 2600); riser(1.6, W(0, 'francia'), 0.16, 80, 700, 0.5)
sonar(W(0, 'pueblo') - 0.05, 1050, 0.14, 1.8)
boom(W(0, 'francia') + 0.02, 0.40, 0.0, 0.2); add(thud(0.7, 1.0), W(0, 'francia') + 0.02, 0.0, 1.0, 0.4)
heart(W(0, 'francia') + 0.4, W(1, 'pirineo'), 72, 72, 0.18)
sonar(W(1, 'llivia') - 0.1, 880, 0.14, 2.0)
wind(W(0, 'francia'), B[1] + 0.8, 0.10)
whoosh(W(1, 'pirineo') - 0.5, 0.7, 0.14, 300, 4500); shutter(W(1, 'pirineo') - 0.05, 0.5, 0.0)
for j in range(4): bird(W(1, 'pirineo') + 0.2 + j * 0.25, 0.035)

# ---------- S1 · el tratado
paper(B[1], 1.2, 0.35); whoosh(B[1] - 0.5, 1.0, 0.10, 300, 4000)
boom(st0(2) - 0.02, 0.32, 0.0, 0.4); bell(st0(2) + 0.05, 220, 0.10); bell(st0(2) + 0.05, 330, 0.05)
murmur(st0(2) + 0.4, st0(4) - 0.2, 0.06)
bell(W(3, 'paz') + 0.1, 523, 0.06); bell(W(3, 'paz') + 0.1, 784, 0.04)
whoosh(st0(4) - 0.6, 0.9, 0.12, 200, 3500); paper(st0(4) - 0.3, 1.0, 0.25)
riser(W(4, 'queda') - 0.1, W(4, 'rosellon') + 0.5, 0.12, 90, 500, 0.6); add(thud(0.6, 0.8), W(4, 'rosellon') + 0.5, 0.0, 1.0, 0.3)
whoosh(W(4, 'rosellon') + 0.5, 1.4, 0.10, 200, 3000)
tf = [W(4, 'treinta') - 0.05 + ((W(4, 'cerdana') + 0.25) - (W(4, 'treinta') - 0.05)) * (32 - j) / 32.0 for j in range(33)]
for i_, tk in enumerate(sorted(tf)): add(tick(900 + 18 * i_, 0.11), tk, -0.5 + i_ / 32.0)
sonar(W(4, 'cerdana') + 0.35, 660, 0.16, 2.2)

# ---------- S2 · villa
heart(st0(5) - 0.4, st0(7) - 0.2, 64, 72, 0.16)
pen(W(5, 'pueblo') + 0.05, 0.32, 0.16)
chime(W(6, 'carlos') - 0.2, 660, 0.08); chime(W(6, 'carlos') - 0.05, 990, 0.05)
bell(st1(6) + 0.2, 392, 0.10); bell(st1(6) + 0.2, 587, 0.06)
whoosh(st0(7) + 0.0, 0.8, 0.10, 300, 3500); paper(st0(7) + 0.2, 1.2, 0.35)
fire(st0(7) + 0.1, st0(8) + 0.2, 0.08)
whoosh(st0(7) + 0.5, 0.6, 0.05, 600, 5000); whoosh(st0(7) + 1.3, 0.8, 0.05, 600, 5000)
chime(W(7, 'palabra') - 0.02, 1046, 0.10); pen(W(7, 'palabra') + 0.05, 0.35, 0.12)
whoosh(st0(8) - 0.7, 0.9, 0.12, 200, 3500)
bell(st1(8) + 0.25, 294, 0.12); bell(st1(8) + 0.25, 440, 0.07)

# ---------- S3 · hoy
whoosh(B[3] - 0.4, 0.9, 0.12, 300, 4000); shutter(B[3] + 0.05, 0.45, 0.0)
wind(B[3] - 0.2, W(9, 'separado'), 0.07); for_b = [bird(B[3] + 0.4 + j * 0.6, 0.03) for j in range(4)]
tk = W(9, 'trece') - 0.1; i_ = 0
while tk < W(9, 'trece') + 0.9: add(tick(1000 + 30 * i_, 0.10), tk, 0.0); tk += 0.07; i_ += 1
whoosh(W(9, 'separado') - 0.6, 0.9, 0.12, 200, 3500)
pen(W(9, 'pasillo') - 0.05, 0.4, 0.12); ping(W(9, 'kilometro', 1) - 0.05, 1250, 0.18)
engine(st0(10) - 0.2, st0(11) - 0.1, 0.10, 46, 64, (-0.6, 0.6))
whoosh(st0(11) - 0.6, 0.9, 0.12, 200, 3500)
wind(st0(11) - 0.3, B[4] + 0.4, 0.05)
engine(st0(11) - 0.3, W(11, 'stop') - 0.1, 0.07, 60, 50, (0.1, 0.0))
t_st = W(11, 'stop'); T0 = t_st + 0.32; P = 1.5
clang(t_st + 0.02, 520, 0.22, 0.5, 1.6); add(thud(0.5, 0.6), t_st + 0.02, 0.5, 1.0, 0.2)
for ci in range(2):
    c0 = T0 + ci * P
    whoosh(c0 + 0.12 * P, 0.4 * P, 0.07, 300, 3000)
    crickets(c0 + 0.25 * P, c0 + 0.66 * P, 0.035)
    steps(c0 + 0.36 * P, 5, 6.0, 0.08, -0.2, 0.4)
    crack(c0 + 0.50 * P + 0.02, 0.35, 0.5); add(thud(0.5, 0.5), c0 + 0.56 * P, 0.5, 1.0, 0.2)
    bird(c0 + 0.70 * P, 0.05); bird(c0 + 0.80 * P, 0.04)
    if ci == 0: clang(c0 + P + 0.02, 560, 0.20, 0.5, 1.4)
clang(T0 + 2 * P + 0.02, 600, 0.22, 0.5, 1.6)
for j in range(10): pluck(t_st + 0.3 + j * 0.3, (220, 262, 330, 262, 220, 196, 220, 262, 330, 392)[j], 0.07, 0.4, -0.3 + 0.06 * j)

# ---------- S4 · cierre
whoosh(B[4] - 0.5, 1.0, 0.10, 300, 4000)
boom(st1(13) + 0.18, 0.30, 0.0, 0.3)
whoosh(st0(14) + 0.3, 3.6, 0.12, 150, 2500)
sonar(st0(14) + 0.1, 660, 0.14, 2.4)
t_su = W(15, 'suscribete'); bell(t_su - 0.05, 1568, 0.14); bell(t_su + 0.28, 2093, 0.12); bell(t_su + 0.28, 1046, 0.05)

